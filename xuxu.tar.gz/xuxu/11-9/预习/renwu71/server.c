#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MSG_FILENAME 1
#define MSG_CONTENT 2
#define MSG_ACK 3
#define MSG_DONE 4
#define MSG_EXPECTION 5
struct msg{
	int type;
	int data_len;
	char data[0];
};

int main(int argc,char *argv[])
{
	time_t timep;
	char buf[100]={0};
	char recv_buffer[100]={0},send_buffer[100]={0};
	int recvlen=0, sendlen=0;
	int client_fd;
	struct sockaddr_in client_addr={0};
	socklen_t addrlen=0;
	pid_t pid;
	char filename[20];
	//socket创建套接字
	int server_fd;
	if((server_fd=socket(AF_INET,SOCK_STREAM,0))<0){
		printf("socket error\n");
		return -1;
	}
	printf("sock_fd=%d\n",server_fd);
	//bind绑定本机端口
	struct sockaddr_in server_addr={0};
	server_addr.sin_family=AF_INET;
	server_addr.sin_port=htons(6000);
	server_addr.sin_addr.s_addr=INADDR_ANY;
	if(bind(server_fd,(struct sockaddr*)&server_addr,sizeof(server_addr))<0)
	{
		printf("bind error\n");
		return -1;
	}
	else
	{
		printf("bind success\n");
	}
	//设置监听
	if(listen(server_fd,10)<0)
	{
		printf("listen error\n");
		return -1;
	}
	//accept响应链接请求
	addrlen=sizeof(client_addr);
    if((client_fd=accept(server_fd,(struct sockaddr *)&client_addr,&addrlen))<0)
     {
		printf("accept error\n");
		return -1;
	}
	printf("accept success\n");
	//receive接受客户端ip以及port
	inet_ntop(AF_INET,&client_addr.sin_addr,buf,sizeof(buf));
	printf("connection from ip is %s,port %d\n",buf,client_addr.sin_port);
			//接受文件名
	struct msg *serv_ms;
	serv_ms=(struct msg*)malloc(4096);
	if(recv(client_fd,(void*)serv_ms,4096,0)<0)
	{
    	printf("recv error\n");
	    exit(1);
	}
	if(serv_ms->type==MSG_FILENAME)
	{
		memset(filename,0,4096);
		memcpy(filename,serv_ms->data,serv_ms->data_len);
	}
	printf("文件名：%s\n",filename);
	//接收文件内容
	FILE *fp;
	char buffer[4096];
	if((fp=fopen("test6","w"))==NULL)
	{
    	printf("fopen error\n");
    	exit(1);
	}
	recv(client_fd,(void*)serv_ms,4096,0);
	if(serv_ms->type==MSG_CONTENT)
	{
    	memset(buffer,0,sizeof(buffer));
    	memcpy(buffer,serv_ms->data,serv_ms->data_len);
    	printf("文件内容%s\n",buffer);
	}
	if(fwrite(buffer,sizeof(buffer),1,fp)<0)
	{
		printf("fwrite error\n");
		return -1;
	}
	//判断传输是否正常
	recv(client_fd,(void*)serv_ms,4096,0);
	if(serv_ms->type==MSG_DONE)
	{
		memset(buffer,0,sizeof(buffer));
		memcpy(buffer,serv_ms->data,serv_ms->data_len);
		printf("%s\n",buffer);
	}
	else if(serv_ms->type==MSG_EXPECTION)
	{
		memset(buffer,0,sizeof(buffer));
		memcpy(buffer,serv_ms->data,serv_ms->data_len);
		printf("%s",buffer);
	}
	fclose(fp);
	free(serv_ms);
	close(client_fd);
	return 0;
}
