#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define MSG_FILENAME 1
#define MSG_CONTENT 2
#define MSG_ACK 3
#define MSG_DONE 4
#define MSG_EXPECTION 5
struct msg
{
	int type;
	int data_len;
	char data[0];
};

int main(int argc,char *argv[])
{
	int sock_fd;
	char send_buffer[100];
    char recv_buffer[100]={0};
	struct sockaddr_in server_addr={0};
	int sendlen=0,recvlen=0;
	char serv_ip[20],clie_ip[20];

	//socket创建套接字
	if((sock_fd=socket(AF_INET,SOCK_STREAM,0))<0)
	{
		printf("创建套接字失败!\n\n");
		exit(1);
	}
	//connect建立连接
	server_addr.sin_family=AF_INET;
	server_addr.sin_port=htons(6000);
	server_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
	connect(sock_fd,(struct sockaddr *)&server_addr,sizeof(server_addr));
	//处理文件名
	char *filename="hello";
	struct msg *clie_ms;
	clie_ms=(struct msg*)malloc(4096);
	clie_ms->type=MSG_FILENAME;
	clie_ms->data_len=strlen(filename);
	memcpy(clie_ms->data,filename,clie_ms->data_len);
	//发送文件名
	if(send(sock_fd,(void*)clie_ms,sizeof(struct msg)+clie_ms->data_len,0)<0)
	{
		printf("发送失败!\n");
		return -1;
	}
	//发送文件内容
	FILE *fp;
	if((fp=fopen("hello","r"))==NULL)
	{
		printf("打开文件失败!\n");
		exit(1);
	}
	fseek(fp,0,SEEK_END);
	clie_ms->type=MSG_CONTENT;
	int len=ftell(fp);
	clie_ms->data_len=len;
	rewind(fp);
	if(fread(send_buffer,len,1,fp)<0)
	{
		printf("读取失败\n");
		exit(1);
	}
	memcpy(clie_ms->data,send_buffer,clie_ms->data_len);
	if((sendlen=send(sock_fd,(void*)clie_ms,sizeof(struct msg)+clie_ms->data_len,0))<0)
	{
		printf("send error\n");
		return -1;
	}
	printf("传输类型：%d\n",clie_ms->type);
	printf("传输内容：%s\n",clie_ms->data);
	//判断是否传输异常
	if(sendlen>0)
	{
		clie_ms->type=MSG_DONE;
		char *buffer="传送正常";
		memcpy(clie_ms->data,buffer,clie_ms->data_len);
		if(send(sock_fd,(void*)clie_ms,sizeof(struct msg)+clie_ms->data_len,0)<0)
		{
			printf("send error\n");
			return -1;
		}
	}
	else
	{
		clie_ms->type=MSG_EXPECTION;
		char *buffer="传送异常";
		memcpy(clie_ms->data,buffer,clie_ms->data_len);
		if(send(sock_fd,(void*)clie_ms,sizeof(struct msg)+clie_ms->data_len,0)<0)
		{
			printf("send error\n");
			return -1;
		}
	}

	fclose(fp);
	free(clie_ms);
	close(sock_fd);
	return 0;
}
