#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 1234
#define LENGTH 10
#define SIZE 100

int main(int argc, char *argv[])
{
	int res;
	int clientfd;
	int sockfd;
	pid_t pid;
	time_t timep;
	char client_ip[SIZE];
	char array[SIZE];
	socklen_t addrlen;
    struct sockaddr_in host_addr;
	struct sockaddr_in client_addr;
	if(argc != 1)
	{
		 printf("参数错误! \n");
		 exit(1);
	}
	/*创建套接字*/
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1)
	{
		 printf("创建套接字失败! \n");
		 exit(1);
	}
	else
	{
		 printf("创建套接字成功! \n");
		 printf("sockfd = %d\n",sockfd);
	}

	bzero(&host_addr,sizeof(host_addr));
    host_addr.sin_family = AF_INET;
	host_addr.sin_port = htons(PORT);
	host_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	bzero(&(host_addr.sin_zero), 8);
	/*绑定套接字*/
    res=bind(sockfd,(struct sockaddr *)&host_addr,sizeof(struct sockaddr));
	if(res == -1)
	{
		 printf("绑定套接字失败! \n");
		 exit(1);
	}
	else
	{
		 printf("绑定套接字成功! \n");
	}

	/*设置监听模式*/
	res = listen(sockfd, LENGTH);
	if(res == -1)
	{
		 printf("设置监听模式失败! \n");
		 exit(1);
	}
	else
	{
		 printf("设置监听模式成功! \n");
	}

	/*实现支持多个client同时连接*/
	while(1)
	{
    	addrlen = sizeof(struct sockaddr_in);
    	clientfd = accept(sockfd, (struct sockaddr *)&client_addr, &addrlen);
    	if(clientfd == -1)
    	{
	    	 printf("接受连接请求失败! \n");
		     exit(1);
     	}
     	else
    	{
	    	 printf("接受连接请求成功! \n");
        }
		if((pid = fork()) == 0)
		{
			close(sockfd);
			time(&timep);
//			printf("当地时间:%s",ctime(&timep));
//			printf("子进程ID是:%d\n",getpid());
        	inet_ntop(AF_INET,&client_addr.sin_addr,client_ip,sizeof(client_ip));
          	printf("Message from %s,port %d\n",client_ip, ntohs(client_addr.sin_port));
			/*接收数据端数据*/
        	res == recv(clientfd, array, SIZE, 0);
         	if(res == -1)
        	{
	        	 printf("接受客户端数据失败! \n");
	        	 exit(1);
        	}
        	else
        	{
	    	     printf("接收到的数据是: %s",array);
        	}

			/*回复客户端*/
			bzero(array, sizeof(array));
			snprintf(array,sizeof(array),"Hi,this is server%s",ctime(&timep));
//        	strcpy(array, "Hi,this is server!");
        	if(send(clientfd, array, SIZE, 0) < 0)
        	{
	        	 printf("传送已接收信息失败! \n");
	         	 exit(1);
        	}
			else
			{
				 printf("回复信息已传达至客户端!\n");
			}
			close(clientfd);
			exit(0);
		}
		close(clientfd);
	}
//	close(sockfd);
	return 0;
}
