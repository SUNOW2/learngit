#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 1234
#define LENGTH 10
#define SIZE 1000

int main(int argc, char *argv[])
{
	int res;
	int sockfd;
	FILE *filp;
	time_t timep;
	char array[SIZE];
	char buf[SIZE];
	socklen_t addrlen;
	struct sockaddr_in host_addr;
	if(argc != 3)
	{
		 printf("参数错误! \n");
		 exit(1);
	}
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1)
	{
		 printf("创建套接字失败! \n");
		 exit(1);
	}
    host_addr.sin_family = AF_INET;
	host_addr.sin_port = htons(PORT);
	host_addr.sin_addr.s_addr = inet_addr(argv[1]);
	bzero(&(host_addr.sin_zero), 8);
	addrlen = sizeof(struct sockaddr);
	res =  connect(sockfd, (struct sockaddr*)&host_addr, addrlen);
	if(res == -1)
	{
		 printf("接受连接请求失败! \n");
		 exit(1);
	}
    filp = fopen(argv[2],"r");
	while(1)
	{
       if(fread(array, 1, SIZE, filp) != SIZE )
	   {
			 if(feof(filp))
			 {
				 printf("到达文件尾!\n");
				 sleep(0.2);
			     break;
			 }
		}
    	res = send(sockfd, array, SIZE, 0);
    	if(res == -1)
    	{
	    	 printf("传送数据失败! \n");
		     exit(1);
    	}
    	bzero(buf, 200);
    	if(recv(sockfd, buf, 200, 0) < 0)
     	{
	    	 printf("数据接收失败! \n");
		     exit(1);
     	}
    	printf("服务器说::%s\n",buf);
	}
	fclose(filp);
	close(sockfd);
	return 0;
}
