#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, char **argv)
{
	 int sockfd = 0;
	 int res;
	 int clientfd;
	 struct sockaddr_in serveraddr;
	 struct sockaddr_in clientaddr;
	 /*创建套接字*/
	 sockfd = socket(AF_INET, SOCK_STREAM,	0);
	 if(sockfd < 0)
	 {
		  perror("创建套接字失败!“);
		  exit(1);
	 }

}
