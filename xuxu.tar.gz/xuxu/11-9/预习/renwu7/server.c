#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 1234
#define LENGTH 10
#define SIZE 4096
#define MSG_FILENAME 1
#define MSG_CONTENT 2
#define MSG_ACK 3
#define MSG_DONE 4
#define MSG_EXECPTION 5

struct msg
{
	int type;
	int data_len;
	char data[SIZE];
};


int main(int argc, char *argv[])
{
	int res;
	int clientfd;
	FILE *filp;
	FILE *filp1;
	int sockfd;
	pid_t pid;
	struct msg *rm;
	char client_ip[SIZE];
	char array[SIZE] = "hello client";
	char buf[1000];
	socklen_t addrlen;
	rm = (struct msg*)malloc(2048);
	char file_name[250];
	struct sockaddr_in host_addr;
	struct sockaddr_in client_addr;
	if(argc != 2)
	{
		printf("参数错误! \n");
		exit(1);
	}
	/*创建套接字*/
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1)
	{
		printf("创建套接字失败! \n");
		exit(1);
	}
	else
	{
		printf("创建套接字成功! \n");
		printf("sockfd = %d\n",sockfd);
	}

	bzero(&host_addr,sizeof(host_addr));
	host_addr.sin_family = AF_INET;
	host_addr.sin_port = htons(PORT);
	host_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	bzero(&(host_addr.sin_zero), 8);
	/*绑定套接字*/
	res=bind(sockfd,(struct sockaddr *)&host_addr,sizeof(struct sockaddr));
	if(res == -1)
	{
		printf("绑定套接字失败! \n");
		exit(1);
	}
	else
	{
		printf("绑定套接字成功! \n");
	}

	/*设置监听模式*/
	res = listen(sockfd, LENGTH);
	if(res == -1)
	{
		printf("设置监听模式失败! \n");
		exit(1);
	}
	else
	{
		printf("设置监听模式成功! \n");
	}

	/*实现支持多个client同时连接*/
	while(1)
	{
		addrlen = sizeof(struct sockaddr_in);
		clientfd = accept(sockfd, (struct sockaddr *)&client_addr, &addrlen);
		if(clientfd == -1)
		{
			printf("接受连接请求失败! \n");
			exit(1);
		}
		if((pid = fork()) == 0)
		{
			close(sockfd);
			printf("子进程ID是:%d\n",getpid());
			inet_ntop(AF_INET,&client_addr.sin_addr,client_ip,sizeof(client_ip));
			printf("Message from %s,port %d\n",client_ip, ntohs(client_addr.sin_port));
			/*接收数据端数据*/
			res == recv(clientfd, (void *)rm, sizeof(struct msg)+20, 0);
			if(res == -1)
			{
				printf("接受客户端数据失败! \n");
				exit(1);
			}
			if(rm->type == MSG_FILENAME)
			{
				memset(file_name,0,250);
				memcpy(file_name,rm->data,rm->data_len);
				printf("文件名:%s\n",file_name);
				if((filp1 = fopen(argv[1],"w+")) != NULL)
				{
					printf("文件%s已经创建!\n",argv[1]);
				}


				if(send(clientfd, array, SIZE, 0) < 0)
				{
					printf("传送已接收信息失败! \n");
					exit(1);
				}
			}
			if(rm->type == MSG_CONTENT)
			{

				res == recv(clientfd, buf, 100, 0);
				if(res == -1)
				{
					printf("接受客户端数据失败! \n");
					exit(1);
				}
				else
				{
					printf("文件内容:%s\n",buf);
				}
				buf[strlen(buf)] = '\0';

				if(fwrite(buf, 1, strlen(buf), filp1)<0)

					if(send(clientfd, array, SIZE, 0) < 0)
					{
						printf("传送已接收信息失败! \n");
						exit(1);
					}
				printf("array = %s",array);
			}
			if(rm->type == MSG_DONE)
			{
				bzero(array, sizeof(array));
				printf("message type = %d\n",MSG_DONE);
				send(clientfd, array, sizeof(array), 0);
			}
			//			if(rm->type == MSG_EXECPTION)
			//			{
			//				 
			//			}
			close(clientfd);
			exit(0);
		}
		close(clientfd);
	}
	//	close(sockfd);
	fclose(filp1);
	//	printf("文件内容为:\n");
	//	system("cat world");
	return 0;
}
