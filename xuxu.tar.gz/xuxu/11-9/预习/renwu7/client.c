#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 1234
#define LENGTH 10
#define SIZE 4096
#define blksize 100
#define MSG_FILENAME 1
#define MSG_CONTENT 2
#define MSG_ACK 3
#define MSG_DONE 4
#define MSG_EXECPTION 5

struct msg
{
	 int type;
	 int data_len;
	 char data[SIZE];
};

int main(int argc, char *argv[])
{
	 int n;
	FILE *filp;
	char *file_name = "hello";
	struct msg *sm,*rm,;
	sm = (struct msg *)malloc(2048);
	sm->type = MSG_FILENAME;
	sm->data_len = strlen(file_name);
	memcpy(sm->data, file_name, sm->data_len);
	long res;
	int sockfd;
	char array[blksize];
	char buf[200] = "hello";
	socklen_t addrlen;
	struct sockaddr_in host_addr;
	if(argc != 3)
	{
		 printf("参数错误! \n");
		 exit(1);
	}
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1)
	{
		 printf("创建套接字失败! \n");
		 exit(1);
	}
	else
	{
		 printf("创建套接字成功! \n");
		 printf("sockfd = %d\n",sockfd);
	}

    host_addr.sin_family = AF_INET;
	host_addr.sin_port = htons(PORT);
	host_addr.sin_addr.s_addr = inet_addr(argv[1]);
	bzero(&(host_addr.sin_zero), 8);

	addrlen = sizeof(struct sockaddr);
	res =  connect(sockfd, (struct sockaddr*)&host_addr, addrlen);
	if(res == -1)
	{
		 printf("接受连接请求失败! \n");
		 exit(1);
	}
	else
	{
		 printf("接受连接请求成功! \n");
	}


	case 1:
    if(send(sockfd, (void *)sm, sizeof(struct msg)+sm->data_len, 0) < 0)
	{
		 printf("数据发送失败!\n");
		 exit(1);
	}


	if(recv(sockfd, buf, 100, 0) < 0)
	{
		 printf("数据接收失败! \n");
		 exit(1);
	}
	printf("%s\n",buf);
	filp = fopen("hello", "r");
	while(1)
	{
	    if(blksize != fread(array, 1, blksize, filp))
		{
//		    send(sockfd, array, blksize, 0);
		    if(feof(filp))
			{
	            array[strlen(array)] = '\0';
		        send(sockfd, array, blksize, 0);
				printf("已经到达文件尾!\n");
				sleep(0.2);
			    break;
			}
	    }
				  

		res = send(sockfd, array, blksize, 0);
		if(res == -1)
		{
			 printf("传送数据失败!\n");
			 exit(1);
		}

	    printf("%s\n",array);

		bzero(buf, sizeof(buf));
	    if(recv(sockfd, buf, 100, 0) < 0)
		{
              printf("数据接收失败! \n");
              exit(1);
		}
		printf("buf = %s\n",buf);
	}

	sm->type = MSG_DONE;
	sm->data_len = strlen(file_name);
	memcpy(sm->data, file_name1, sm->data_len);
	
    if(send(sockfd, (void *)sm, sizeof(struct msg)+sm->data_len, 0) < 0)
	{
		 printf("数据发送失败!\n");
		 exit(1);
	}
	else
	{
		 recv(sockfd, buf, 100, 0);
		 if(buf != NULL)
		     printf("服务器: 已收到DONE!i,传输正常!\n");
	}
	break;
}    
	fclose(filp);
	close(sockfd);
	return 0;
}
