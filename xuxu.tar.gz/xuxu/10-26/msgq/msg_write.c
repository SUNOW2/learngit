#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>

#define PATH_NAME "/home/sunow1"
#define PRO_ID 100


#define MSG_SIZE 128
struct msg_buf {
	long mtype; 
	char mtext[MSG_SIZE]; 
};

void main(int argc, const char *argv[])
{
	key_t key;
	int msgid;
	struct msg_buf buffer;

	key = ftok(PATH_NAME, PRO_ID);

	msgid = msgget(key, IPC_CREAT | 0666);
	if (msgid < 0) {
		perror("msgget");
		exit(EXIT_FAILURE);
	}
	
	buffer.mtype = 1024;
	while(1)
	{
	    printf("请输入传递的字符串：\n");
    	fgets(buffer.mtext, MSG_SIZE, stdin);
	    if(msgsnd(msgid, &buffer, sizeof(struct msg_buf),0) < 0) 
		{
	        perror("msgsnd error!\n");
	        exit(EXIT_FAILURE);
        }
		else
		{
    	    if(strncmp("exit",buffer.mtext,4) == 0)
		    	break;
		}
	}
	if (msgctl(msgid, IPC_RMID, 0) < 0) 
	{
		perror("msgctl");
		exit(EXIT_FAILURE);
	}
    exit(EXIT_SUCCESS);
}
