#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>

#define PATH_NAME "/home/sunow1"
#define PRO_ID 100
#define MSG_SIZE 128

struct msg_buf 
{
	long mtype; 
	char mtext[MSG_SIZE]; 
};

void main(int argc, const char *argv[])
{
	key_t key;
	int msgid;
	struct msg_buf buffer;

	key = ftok(PATH_NAME, PRO_ID);

	msgid = msgget(key, IPC_EXCL | 0666);
	if (msgid < 0) 
	{
		perror("msgget");
		exit(EXIT_FAILURE);
	}
	while(1)
	{
	    printf("接收到的字符串为：\n");
	    if(msgrcv(msgid, &buffer, sizeof(struct msg_buf),0,0) < 0) 
	    {
	        perror("msgrcv error!");
	        exit(EXIT_FAILURE);
        }
		else
		{
    	    if(strncmp("exit",buffer.mtext,4) != 0)
			{
		        printf("%s",buffer.mtext);		
			}
		    else
	    	{
				printf("输入结束！\n");
		    	break;
	    	}
		}
	}
    exit(EXIT_SUCCESS);
}
