#include <stdio.h>
#include <stdlib.h>

unsigned maximum = 0;
int main(int argc, char *argv[])
{
	unsigned blocksize[] = { 1024*1024, 1024, 1};
	int i,count;
	for(i=0; i<3; i++)
	{
		for(count=1;;count++)
		{
			void *boock = malloc( maximum + )
		}
	}
}
