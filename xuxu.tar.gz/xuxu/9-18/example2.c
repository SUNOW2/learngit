#!/bin/bash
s=0
echo "please input two numbers"
read a b 
for index in $a $b
 do
    echo $index
    s=$((++s))
done 
    echo $s
