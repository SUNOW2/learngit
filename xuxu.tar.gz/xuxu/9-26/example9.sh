#!/bin/bash
cat ~/.bash_history | sed 's/|/\n/g' | awk '{print $1}' | sort | uniq -c | sort -nr | head -5
