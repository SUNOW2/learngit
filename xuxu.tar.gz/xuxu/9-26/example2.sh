#!/bin/bash
find . -name example16.c | ls -l example16.c | awk '{print $9}' > example2.sh
a=`cat example2.sh`
echo $a
b=${a%.*}
echo $b
mv example16.c example16.h
