#!/bin/bash
read file
case $file in
   up)
   sudo ifconfig eth0 up
   echo "ifconfig eth0 up"
   ;;
   down)
   sudo ifconfig eth0 down
   echo "ifconfig eth0 down"
   ;;
   *)
   echo "cuowu"
   ;;
esac
