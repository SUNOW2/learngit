#!/bin/bash
for filename in `find . -name "*.txt"`
do
  mv $filename ${filename/%txt/t}
done
