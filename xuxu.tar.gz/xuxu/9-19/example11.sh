#!/bin/bash
echo "please input a username!"
read username
a=$(whoami)
if test $a = $username
then
  echo "running"
else
  echo "not running"
fi
