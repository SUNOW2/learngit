#!/bin/bash
filemax=0
filename=""
for file in `ls`
do 
   a=$(ls -l $file | awk '{print $5}')
   echo $a
if [[ $a -gt $filemax ]]
then
   filemax=$a
   filename=$file
fi
done
echo $filename
