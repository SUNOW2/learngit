#!/bin/bash
#echo "please input the filename"
#read filename
sort -c example20.sh
if [ $? -ne 0 ]
then
   echo "not sort!"&&sort example20.sh
else
   echo "sort before!"
fi
