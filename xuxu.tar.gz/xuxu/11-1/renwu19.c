#include <stdio.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <pwd.h>

#define SIZE 100

void fun(char buf[SIZE])
{
	char array[SIZE];
	struct stat sta;
	char *blk="sunow1";
	struct passwd *pw;
	DIR * pirptr;
	struct dirent *entry;
	pirptr = opendir(buf);
	if(pirptr == NULL)
	{
		printf("打开目录失败! \n");
		exit(1);
	}
	printf("目录下可执行的所有给定文件: \n");
	while(entry = readdir(pirptr))
	{
		if(strcmp(entry->d_name,".")==0||strcmp(entry->d_name,"..") == 0)
			continue;
		sprintf(array,"%s/%s",buf,entry->d_name);
		if(stat(array,&sta) == -1)
		{
			printf("获取文件属性错误! \n");
			exit(EXIT_FAILURE);
		}
		pw = getpwnam(blk);
		{
			if(pw->pw_uid == sta.st_uid)
			{
				printf("%s\n",array);
			}
		}
		if(S_ISDIR(sta.st_mode))
		{
		    fun(array);
		}
	}
	closedir(pirptr);
}

int main(int argc, char *argv[])
{
	if(argc != 2)
	{
		printf("参数错误!\n");
		exit(1);
	}
	fun(argv[1]);
	return 0;
}
