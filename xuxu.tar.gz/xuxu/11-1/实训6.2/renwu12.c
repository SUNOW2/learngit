#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>

#define SIZE 100

void fun(char array[SIZE],char blk[SIZE])
{
	char buf[SIZE];
	DIR *dirptr=NULL;
	struct stat sta;
	struct dirent *entry;

	dirptr = opendir(array);
	if(dirptr == NULL)
	{
		printf("打开目录失败! \n");
		exit(EXIT_FAILURE);
	}
	while((entry = readdir(dirptr)) != NULL)
	{
		if(strcmp(entry->d_name,".")==0||strcmp(entry->d_name,"..")==0)
			continue;
		sprintf(buf,"%s/%s",array,entry->d_name);
	    if(stat(buf, &sta) == -1)
		{
			printf("获取文件属性失败! \n");
			exit(1);
		}
		if(S_ISREG(sta.st_mode))
		{
		    if(strcmp(entry->d_name,blk) == 0)
			{
			    printf("文件%s已经删除!\n",blk);
		        unlink(buf);
			    break;
		    }
		}
        if(S_ISDIR(sta.st_mode))
		{
			fun(buf,blk);
		}
	}
	closedir(dirptr);
}

int main(int argc, char *argv[])
{
    if(argc != 3)
	{
		printf("参数错误! \n");
		exit(EXIT_FAILURE);
	}
	fun(argv[1],argv[2]);
	return 0;
}
