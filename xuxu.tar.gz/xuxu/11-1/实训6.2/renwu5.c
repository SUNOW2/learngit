#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>

#define SIZE 100

int a=0, b=0, c=0, d=0, e=0, f=0,s=0;
int fun(char buf[SIZE])
{
	int res;
	struct dirent *entry;
	DIR *dirptr;
	char array[SIZE];
	struct stat sta;
	stat(buf, &sta);
	if(S_ISDIR(sta.st_mode))
	{
    	dirptr = opendir(buf);
        if(dirptr == NULL)
    	{
	    	printf("打开目录失败! \n");
	    	exit(1);
    	}
    	while((entry = readdir(dirptr)) != NULL)
    	{
			if((strcmp(entry->d_name,".")==0)||(strcmp(entry->d_name,"..")==0))
			{
				continue;
			}
			sprintf(array, "%s/%s", buf,entry->d_name);
			printf("%s\n",array);
	    	res = stat(array, &sta);
	    	if(res == -1)
	    	{
		    	printf("获取文件属性失败! \n");
				exit(1);
	     	}
			s++;
			if(S_ISLNK(sta.st_mode))
			{
				a++;
			}
			if(S_ISREG(sta.st_mode))
			{
				b++;
			}
			if(S_ISDIR(sta.st_mode))
			{
				c++;
				fun(array);
			}
			if(S_ISCHR(sta.st_mode))
			{
				d++;
			}
			if(S_ISBLK(sta.st_mode))
			{
				e++;
			}
	    	if(S_ISSOCK(sta.st_mode))
	    	{
				f++;
	    	}
		}
	}
	closedir(dirptr);
}


int main(int argc, char *argv[])
{
	if(argc != 2)
	{
		printf("参数错误! \n");
		exit(EXIT_FAILURE);
	}
	int i=0;
	fun(argv[1]);
	printf("文件总数:%d\n",s);
	printf("符号连接个数 %d\n",a);
	printf("一般文件个数:%d\n",b);
	printf("目录文件个数:%d\n",c);
	printf("字符装置文件个数:%d\n",d);
	printf("块设备文件个数:%d\n",e);
	printf("socket文件个数:%d\n",f);
	return 0;
}
