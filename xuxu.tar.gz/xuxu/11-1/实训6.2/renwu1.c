#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
	int res;
	struct stat sta;
	res = stat("./hello", &sta);
	if(res == -1)
	{
		printf("获取文件属性晒白! \n");
		exit(EXIT_FAILURE);
	}
	if(S_ISDIR(sta.st_mode))
	{
		printf("目录文件! \n");
	}
	else
	{
		printf("不是目录文件! \n");
	}
	return 0;
}
