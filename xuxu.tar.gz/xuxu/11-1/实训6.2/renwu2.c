#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <dirent.h>

int main(int argc, char *argv[])
{
	DIR *opdir;
	struct dirent *redir;
	if(argc < 2)
	{
		printf("请输入目录! \n");
		exit(1);
	}
	if(argc > 2)
	{
		printf("目录行参数过多! \n");
		exit(1);
	}
	opdir = opendir(argv[1]);
	if(opdir == NULL)
	{
		printf("打开目录失败! \n");
		exit(EXIT_FAILURE);
	}
	else
	{
		while((redir = readdir(opdir)) != NULL)
		{
			if(redir->d_type == DT_DIR)
			{
		         printf("目录为: %s\n", redir->d_name);
			}
			else
			{
				 printf("文件为: %s\n", redir->d_name);
			}
		}
		closedir(opdir);
	}
    return 0;
}	
