#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>

#define SIZE 100
int flag = 0;

void fun(char ack[SIZE],char blk[SIZE])
{
	char buf[SIZE];
	DIR *dirptr=NULL;
	struct stat sta;
	struct dirent *entry;
	dirptr = opendir(ack);
	if(dirptr == NULL)
	{
		printf("打开目录失败! \n");
		exit(EXIT_FAILURE);
	}
	while((entry = readdir(dirptr)) != NULL)
	{
		if(strcmp(entry->d_name,".")==0||strcmp(entry->d_name,"..")==0)
			continue;
		sprintf(buf,"%s/%s",ack,entry->d_name);
		if(strncmp(entry->d_name,blk,3) == 0)
		{
			printf("%s\n",buf);
			flag++;
		}
	    if(stat(buf, &sta) == -1)
		{
			printf("获取文件属性失败! \n");
			exit(1);
		}
        if(S_ISDIR(sta.st_mode))
		{
			fun(buf,blk);
		}
	}
	closedir(dirptr);
}

int main(int argc, char *argv[])
{
	if(argc != 3)
	{
		printf("参数错误! \n");
		exit(EXIT_FAILURE);
	}
	printf("文件名中含有%s的文件主要包括:\n",argv[2]);
	fun(argv[1],argv[2]);
	if(flag == 0)
	{
		printf("此文件不存在! \n");
		exit(EXIT_FAILURE);
	}
	return 0;
}
