#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>

#define SIZE 100
void fun(char buf1[SIZE],char buf2[SIZE])
{
	int res;
	struct dirent *entry;
	DIR *dirptr;
	char array[SIZE];
	struct stat sta;
	stat(buf1, &sta);
	if(S_ISDIR(sta.st_mode))
	{
    	dirptr = opendir(buf1);
        if(dirptr == NULL)
    	{
	    	printf("打开目录失败! \n");
	    	exit(1);
    	}
    	while((entry = readdir(dirptr)) != NULL)
    	{
			if((strcmp(entry->d_name,".")==0)||(strcmp(entry->d_name,"..")==0))
			{
				continue;
			}
			sprintf(array, "%s/%s", buf1,entry->d_name);
	    	res = stat(array, &sta);
	    	if(res == -1)
	    	{
		    	printf("获取文件属性失败! \n");
				exit(1);
	     	}
			if(strcmp(entry->d_name,buf2) == 0)
			{
				printf("找到! \n");
			    printf("%s\n",array);
				exit(1);
			}
	    	if(S_ISDIR(sta.st_mode))
	    	{
		    	fun(array,buf2);
	    	}
		}
	}
	else
	{
		printf("不是目录! \n");
		exit(1);
	}
	closedir(dirptr);
}


int main(int argc, char *argv[])
{
	if(argc != 3)
	{
		printf("参数错误! \n");
		exit(EXIT_FAILURE);
	}
	fun(argv[1],argv[2]);
	return 0;
}
