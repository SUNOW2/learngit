#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>

#define SIZE 100

void fun(char buf[SIZE])
{
	int flag = 0;
	char array[SIZE];
	DIR *dirptr=NULL;
	struct stat sta;
	struct dirent *entry;
	char *blk = "/home/sunow1/xuxu/11-1/预习/hello12";
	dirptr = opendir(buf);
	if(dirptr == NULL)
	{
		printf("打开目录失败! \n");
		exit(EXIT_FAILURE);
	}
	while((entry = readdir(dirptr)) != NULL)
	{
	    if(strcmp(entry->d_name,".")==0 || strcmp(entry->d_name,"..")==0)		
			continue;
		sprintf(array,"%s/%s",buf,entry->d_name);
		if(stat(array,&sta) == -1)
		{
			printf("获取文件属性失败! \n");
			exit(1);
		}
		if(S_ISDIR(sta.st_mode))
		{
			if(strcmp(array, blk) == 0)
			{
				dirptr = opendir(array);
				while((entry = readdir(dirptr)) != NULL)
				{
				   if(strcmp(entry->d_name,".")==0 || strcmp(entry->d_name,"..")==0)		
						  continue;
				   flag++;
				}
				if(flag == 0)
				{
					printf("空目录已经成功删除! \n");
					printf("%s\n", array);
					rmdir(array);
					break;
				}
			}
			fun(array);
		}
	}
	closedir(dirptr);
}

int main(int argc, char *argv[])
{
	if(argc != 2)
	{
		printf("参数错误!\n");
		exit(1);
	}
	fun(argv[1]);
	return 0;
}
