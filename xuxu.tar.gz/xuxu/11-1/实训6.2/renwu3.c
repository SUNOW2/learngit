#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>

#define SIZE 100

int main(int argc, char *argv[])
{
	char buf[SIZE];
	char array[SIZE];
	DIR *dirptr=NULL;
	struct dirent *entry;
	getcwd(array,SIZE);
	dirptr = opendir(array);
//	dirptr = opendir(argv[1]);
	if(dirptr == NULL)
	{
		printf("打开目录失败! \n");
		exit(EXIT_FAILURE);
	}
	printf("目录下文件的绝对路径: \n");
	while((entry = readdir(dirptr)) != NULL)
	{
		sprintf(buf, "%s/%s", array,entry->d_name);
//		sprintf(buf, "%s/%s", argv[1],entry->d_name);
		printf("%s\n",buf);
	}
	closedir(dirptr);
	return 0;
}
