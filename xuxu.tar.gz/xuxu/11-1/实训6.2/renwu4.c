#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/types.h>

#define SIZE 100
void fun(char buf[SIZE])
{
	int res;
	char array[SIZE];
	struct dirent *entry;
	DIR *dirptr;
	struct stat sta;
	stat(buf, &sta);
	if(S_ISDIR(sta.st_mode))
	{
    	dirptr = opendir(buf);
        if(dirptr == NULL)
    	{
	    	printf("打开目录失败! \n");
	    	exit(1);
    	}
    	while((entry = readdir(dirptr)) != NULL)
    	{
			if((strcmp(entry->d_name,".")==0)||(strcmp(entry->d_name,"..")==0))
			{
				continue;
			}
			sprintf(array,"%s/%s",buf,entry->d_name);
			printf("%s\n",array);
	    	res = stat(array, &sta);
	    	if(res == -1)
	    	{
		    	printf("获取文件属性失败! \n");
				exit(1);
	     	}
	    	if(S_ISDIR(sta.st_mode))
	    	{
		    	fun(array);
	    	}
		}
	}
	else
	{
		printf("不是目录! \n");
		exit(1);
	}
	closedir(dirptr);
}


int main(int argc, char *argv[])
{
	if(argc != 2)
	{
		printf("参数错误! \n");
		exit(EXIT_FAILURE);
	}
	fun(argv[1]);
	return 0;
}
