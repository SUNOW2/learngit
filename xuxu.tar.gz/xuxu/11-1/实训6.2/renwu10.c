#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <dirent.h>

#define SIZE 100

int main(int argc, char *argv[])
{
	int flag = 0;
	char buf[SIZE];
	char array[SIZE];
	DIR *dirptr=NULL;
	struct stat sta;
	struct dirent *entry;
	char *blk = "/home/sunow1/xuxu/11-1/预习/hello12";
	getcwd(array,SIZE);
	dirptr = opendir(array);
	if(dirptr == NULL)
	{
		printf("打开目录失败! \n");
		exit(EXIT_FAILURE);
	}
	while((entry = readdir(dirptr)) != NULL)
	{
		sprintf(buf, "%s/%s", array,entry->d_name);
		if(stat(array,&sta) == -1)
		{
			printf("获取文件属性失败! \n");
			exit(1);
		}
		if(S_ISDIR(sta.st_mode))
		{
			if(strcmp(buf, blk) == 0)
			{
				printf("此目录已存在 \n");
		        printf("%s\n",blk);
				flag = 1;
				exit(EXIT_FAILURE);
			}
		}
	}
	if(flag == 0)
	{
		mkdir(blk,0666);
		printf("目录已创建! \n");
		printf("%s\n",blk);
	}
	closedir(dirptr);
	return 0;
}
