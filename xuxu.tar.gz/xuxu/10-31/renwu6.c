#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <utime.h>
#include <time.h>

int main(int argc, char *argv[])
{
	struct stat sta;
	struct utimbuf timebuf;
	if(stat(argv[1], &sta) == -1)
	{
		printf("打开文件属性失败! \n");
		exit(1);
	}
    printf("修改前文件最后访问时间: %s\n", ctime(&sta.st_atime));
    printf("修改前文件最后修改时间: %s\n", ctime(&sta.st_mtime));
	utime(argv[1], NULL);
	if(stat(argv[1], &sta) == -1)
	{
		printf("打开文件属性失败! \n");
		exit(1);
	}
    printf("修改后文件最后访问时间: %s\n", ctime(&sta.st_atime));
    printf("修改后文件最后修改时间: %s\n", ctime(&sta.st_mtime));
	return 0;
}

