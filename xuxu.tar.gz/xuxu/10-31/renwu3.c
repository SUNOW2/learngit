#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

#define SIZE 30

int main(int argc, char *argv[])
{
	char buf[SIZE];
	FILE *fp;
	struct stat sta;
	fp = fopen("./testfile_chg", "r");
	if(fp == NULL)
	{
		printf("文件打开失败! \n");
		exit(1);
	}
	if(stat("./testfile_chg", &sta) == -1)
	{
		printf("打开文件属性失败! \n");
	}
	if(fread(buf, sizeof(char), sizeof(buf), fp) == -1)
	{
		printf("读取文件内容失败!\n");
		exit(1);
	}
	printf("%s\n",buf);
	printf("权限: %o\n",0777&sta.st_mode);
	chmod("./testfile_chg",0711);
	if(stat("./testfile_chg", &sta) == -1)
	{
		printf("打开文件属性失败! \n");
	}
	printf("权限: %o\n",0777&sta.st_mode);
	fclose(fp);
	return 0;
}

