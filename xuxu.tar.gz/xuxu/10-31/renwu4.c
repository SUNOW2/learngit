#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

#define SIZE 30

int main(int argc, char *argv[])
{
	char buf[SIZE];
	FILE *fp1;
	FILE *fp2;
	struct stat sta;
	fp1 = fopen("./testfile_chg", "r");
	if(fp1 == NULL)
	{
		printf("文件打开失败! \n");
		exit(1);
	}
	if(stat("./testfile_chg", &sta) == -1)
	{
		printf("打开文件属性失败! \n");
		exit(1);
	}
	printf("用户ID: %d\n",sta.st_uid);
	printf("组ID: %d\n",sta.st_gid);
	printf("最后访问时间: %s\n",ctime(&sta.st_atime));
	printf("最后修改时间: %s\n",ctime(&sta.st_mtime));
	if(fread(buf, sizeof(char), sizeof(buf), fp1) == -1)
	{
		printf("读取文件内容失败!\n");
		exit(1);
	}
	printf("%s\n",buf);
	fp2 = fopen("./filetest_bak", "wr");
	if(fp2 == NULL)
	{
		printf("打开文件失败! \n");
		exit(1);
	}
    fwrite(buf, sizeof(char), sizeof(buf), fp2);
	fclose(fp1);
	fclose(fp2);
	if(remove("./testfile_chg") == 0)
	{
		printf("文件删除成功! \n");
	}
	return 0;
}

