#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

#define SIZE 100
void Fun1(struct stat buf);
void Fun2(struct stat buf);
void Fun3(struct stat buf);
int main(int argc, char *argv[])
{
	struct stat buf;
	FILE *fp;
	fp = fopen("./testfile", "w+");
	if(fp == NULL)
	{
		printf("文件打开失败! \n");
		exit(1);
	}
	if(stat("./testfile", &buf) == -1)
	{
		printf("打开文件属性失败! \n");
		exit(1);
	}
	Fun1(buf);
	printf("***************************************\n");
	Fun2(buf);
	printf("***************************************\n");
    Fun3(buf);
	fclose(fp);
	return 0;
}

void Fun1(struct stat buf)
{
	if((buf.st_mode&S_IRUSR) == S_IRUSR)
	{
		printf("用户主可读\n");
	}
	if((buf.st_mode&S_IWUSR) == S_IWUSR)
	{
		printf("用户主可写\n");
	}
	if((buf.st_mode&S_IXUSR) == S_IXUSR)
	{
		printf("用户主可执行\n");
	}
	if((buf.st_mode&S_IRGRP) == S_IRGRP)
	{
		printf("用户组可读\n");
	}
	if((buf.st_mode&S_IWGRP) == S_IWGRP)
	{
		printf("用户组可写\n");
	}
	if((buf.st_mode&S_IXGRP) == S_IXGRP)
	{
		printf("用户组可执行\n");
	}
	if((buf.st_mode&S_IROTH) == S_IROTH)
	{
		printf("其他组可读\n");
	}
	if((buf.st_mode&S_IWOTH) == S_IWOTH)
	{
		printf("其他组可写\n");
	}
	if((buf.st_mode&S_IXOTH) == S_IXOTH)
	{
		printf("其他组可执行\n");
	}

}
void Fun2(struct stat buf)
{
	if((buf.st_mode&S_IRUSR) == S_IRUSR)
	{
		printf("r");
	}
	else
	{
		printf("-");
	}
	if((buf.st_mode&S_IWUSR) == S_IWUSR)
	{
		printf("w");
	}
	else
	{
		printf("-");
	}
	if((buf.st_mode&S_IXUSR) == S_IXUSR)
	{
		printf("x");
	}
	else
	{
		printf("-");
	}
	if((buf.st_mode&S_IRGRP) == S_IRGRP)
	{
		printf("r");
	}
	else
	{
		printf("-");
	}
	if((buf.st_mode&S_IWGRP) == S_IWGRP)
	{
		printf("w");
	}
	else
	{
		printf("-");
	}
	if((buf.st_mode&S_IXGRP) == S_IXGRP)
	{
		printf("x");
	}
	else
	{
		printf("-");
	}
	if((buf.st_mode&S_IROTH) == S_IROTH)
	{
		printf("r");
	}
	else
	{
		printf("-");
	}
	if((buf.st_mode&S_IWOTH) == S_IWOTH)
	{
		printf("w");
	}
	else
	{
		printf("-");
	}
	if((buf.st_mode&S_IXOTH) == S_IXOTH)
	{
		printf("x");
	}
	else
	{
		printf("-");
	}
	printf("\n");
}



void Fun3(struct stat buf)
{
	printf("%o\n",0777&buf.st_mode);
}
