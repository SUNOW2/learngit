#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

#define SIZE 30

int main(int argc, char *argv[])
{
	char buf[SIZE]="ABCDEFGHIJKLMNPQRSTWXYZ";
	FILE *fp;
	struct stat sta;
	fp = fopen("./testfile", "w+");
	if(fp == NULL)
	{
		printf("文件打开失败! \n");
		exit(1);
	}
	if(stat("./testfile", &sta) == -1)
	{
		printf("打开文件属性失败! \n");
	}
	fwrite(buf, 1, sizeof(buf), fp);
	rename("./testfile", "./testfile_chg");
	printf("权限: %o\n",0777&sta.st_mode);
	chmod("./testfile_chg",sta.st_mode&0755);
	if(stat("./testfile_chg", &sta) == -1)
	{
		printf("打开文件属性失败! \n");
		exit(1);
	}
	printf("权限: %o\n",0777&sta.st_mode);
	fclose(fp);
	return 0;
}

