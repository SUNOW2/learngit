#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
	struct stat sta;
	if(argc != 3)
	{
		printf("参数太少!\n");
		exit(1);
	}
	if(stat(argv[1], &sta) == -1)
	{
		printf("打开文件属性失败! \n");
		exit(1);
	}
    printf("原有组ID: %d\n", sta.st_gid);

	if(chown(argv[1], -1, atoi(argv[2])) == -1)
	{
		printf("修改原有ID失败! \n");
		exit(1);
	}

	if(stat(argv[1], &sta) == -1)
	{
		printf("打开文件属性失败! \n");
		exit(1);
	}
	printf("新的组ID: %d\n", sta.st_gid);
	return 0;
}

