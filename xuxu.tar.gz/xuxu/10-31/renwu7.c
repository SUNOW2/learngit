#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/select.h>
#include <unistd.h>
#include <fcntl.h>

int main(int argc, char *argv[])
{
	struct timeval tv;      /*非阻塞地读取终端/dev/tty上的输入信息*/
	int fd;
	char ch;
	fd_set readfds;
	int ret;
	fd = open("/dev/tty", O_RDWR | O_NONBLOCK);
	if(fd == -1)
	{
		printf("打开文件失败! \n");
		exit(1);
	}
    while(1)
	{
     	tv.tv_sec = 5;         /* 超时时间设置为5s */
    	tv.tv_usec = 0;
	    FD_ZERO(&readfds);     /* 清空可读的fd集合 */
    	FD_SET(fd, &readfds);  /* 把打开终端的fd加入到可读fd集合中 */
        /* 调用select函数，查看是否有可读的fd */
    	ret = select(fd+1, &readfds, NULL, NULL, &tv);
    	if(ret == -1)    /* 调用select函数失败 */
    	{
	    	printf("选择错误! \n");
	    	exit(1);
    	}
		else if(ret)
		{
		    if(FD_ISSET(fd,&readfds))/*判断终端的fd是否在可读描述符中*/
	    	{
		        read(fd, &ch, 1);     /*读取字符*/
		     	if(ch == '\n')
				    continue;
		     	if(ch == 'q')
		     	{
			    	break;
		    	}
				printf("字符: %c\n",ch);
	     	}
		}
		else if(ret == 0)
		{
			printf("超时! \n");
		}
	}
	return 0;
}
