#include <stdio.h>
#include <mcheck.h>
typedef struct
{
		 char* data;
		 int key;
}item;
item array[]={
		 {"bill",3 },
		 {"neil",4 },
		 {"john",2 },
		 {"rick",5 },
		 {"neil",4 },
		 {"alex",1 }
};
void sort(item* a,int n)
{
		 int i=0,j=0;
		 int s=1;
		 item t;
		 for(;i<n&&s!=0;i++)
		 {
				 s=0;
		 for(j=0;j<n;j++)
		 {
			if(a[j].key>a[j+1].key)	
			{
					 t=a[j];
					 a[j]=a[j+1];
					 a[j+1]=t;
					 s++;
			}
		 }
         //n--;
         }
		 for(i=0;i<n+1;i++)
		 {
				  printf("%s%d\n",a[i].data,a[i].key);
		 }
}
int main()
{
		 mtrace();
		 sort(array,5);
}
