#include <stdio.h>
#include <stdlib.h>
#include <mcheck.h>
void main()
{
		 mtrace();
		 char *p=NULL;
		 p=(char*)malloc(20);
		 printf("%d",*p);
		 free(p);
}
