
#!/bin/bash
for file in `ls`
do
  echo $file
done
