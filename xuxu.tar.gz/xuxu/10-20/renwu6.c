#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>

pthread_attr_t attr;

void start_routine()
{
		pthread_exit(NULL);
}
int main()
{
	pthread_t pth;
	int res;

	res = pthread_create(&pth, NULL, (void *)&start_routine,NULL);
	if(res != 0)
	{
	    printf("fail to create!\n");
		exit(1);
	}

	res = pthread_attr_init(&attr);
	if(res != 0)
	{
	    printf("fail to init!\n");
		exit(1);
	}

    res = pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);
	if(res != 0)
	{
		printf("fail to set!\n");
		exit(1);
	}
    printf("the pthread exit!\n");
    return 0;
}
