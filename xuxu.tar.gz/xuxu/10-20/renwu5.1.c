#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>

int i=10;
pthread_mutex_t mutex;
pthread_cond_t cond;
void start_routine(void *message)
{
		while(i > 0)
		{
	        pthread_mutex_lock(&mutex);
     		sleep(1);
	    	pthread_cond_signal(&cond);
			printf("class2 = %d\n",i);
			i--;
	    	pthread_mutex_unlock(&mutex);
		}

		pthread_exit("thread exit!\n");
}
int main()
{
	void *pthread_result;
	char *message = "hello world";
	pthread_t pth;
	int res;

	res = pthread_mutex_init(&mutex,NULL);
    if(res != 0)
	{
		printf("fail to pthread_mutex_init!\n");
		exit(1);
	}

	res = pthread_cond_init(&cond,NULL);
    if(res != 0)
	{
		printf("fail to pthread_mutex_init!\n");
		exit(1);
	}
	res = pthread_create(&pth, NULL, (void *)&start_routine,(void *)message);
	if(res != 0)
	{
	    printf("fail to create!");
		exit(1);
	}

	while(i > 0)
	{
        pthread_mutex_lock(&mutex);
        pthread_cond_wait(&cond,&mutex);
		sleep(1);
		printf("class1 = %d\n",i);
		i--;
        pthread_mutex_unlock(&mutex);
	}
	sleep(1);

	pthread_join(pth,&pthread_result);
	sleep(abs((int)(3.0*rand()/(RAND_MAX+1.0))));
    printf("exit:%s",(char *)pthread_result);
    pthread_mutex_destroy(&mutex);
    pthread_cond_destroy(&cond);
	return 0;
}
