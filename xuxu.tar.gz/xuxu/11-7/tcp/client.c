#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>

#define SIZE 100

int main(int argc, char *argv[])
{
	int sock_fd;
	char send_array[SIZE] = {0};
	struct sockaddr_in serveraddr = {0};
    ssize_t sendlen = 0;

	/*创建套接字*/
	sock_fd = socket(AF_INET, SOCK_STREAM, 0);
	if(sock_fd < 0)
	{
		 printf("oh,my god,socket error!\n");
		 return -1;
	}

	/*客户端与指定服务器建立连接*/
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(6000);
	serveraddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    if(connect(sock_fd, (struct sockaddr*)&serveraddr, sizeof(serveraddr)) < 0)
	{
		 printf("oh,my god,connect error!\n");
		 return -1;
	}

	/*向一个套接字发送一定字节的数据*/
	strcpy(send_array,"hello server!");
//    if((sendlen = send(sock_fd,send_array, SIZE, 0)) < 0)
    if((sendlen = send(sock_fd,send_array, strlen(send_array), 0)) < 0)
	{
		 printf("oh,my god,send error! \n");
		 return -1;
	}
	printf("sendlen = %d\n",(int)sendlen);
	bzero(&send_array,sizeof(send_array));
	if(recv(sock_fd,send_array,SIZE,0) < 0)
	{
		 printf("receive error!\n");
		 exit(1);
	}
	printf("receive from server: %s\n",send_array);
	close(sock_fd);
    return 0;
}
