#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>

#define SIZE 100

int main(int argc, char *argv[])
{
	int sock_fd;
	int newsock_fd;
	int length;
	char array[SIZE];
	struct sockaddr_in serveraddr = {0};
	struct sockaddr_in clientaddr = {0};
    socklen_t addrlen;

	/*创建套接字*/
	sock_fd = socket(AF_INET, SOCK_STREAM, 0);
	if(sock_fd < 0)
	{
		 printf("oh,my god,socket error!\n");
		 return -1;
	}

	/*将协议，IP地址和端口绑定*/
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(6000);
	serveraddr.sin_addr.s_addr = INADDR_ANY;
    if(bind(sock_fd, (struct sockaddr*)&serveraddr, sizeof(serveraddr)) < 0)
	{
		 printf("oh,my god,bind error!\n");
		 return -1;
	}

	/*进行系统监听，等待客户连接*/
    if(listen(sock_fd, 10) < 0)
	{
		 printf("oh,my god, listen error!\n");
		 return -1;
	}
    while(1)
	{
	/*响应连接请求，建立连接*/
	newsock_fd = accept(sock_fd, (struct sockaddr *)&clientaddr, &addrlen);
	if(newsock_fd < 0)
	{
		 printf("oh,my god,accept error! \n");
		 return -1;
	}

	/*从一个套接字接收一定字节的数据*/
	length = recv(newsock_fd, array, SIZE, 0);
	if(strlen < 0)
	{
		 printf("oh , my god ,recv error!\n");
		 return -1;
	}
	printf("strlen = %d\n",length);
	printf("rceive: %s\n",array);
	strcpy(array,"Don't worry,message have received!哈哈");
	if(send(newsock_fd, array, SIZE, 0) < 0)
	{
		 printf("send error!\n");
		 exit(1);
	}
	}
	close(sock_fd);
	return 0;
}
