#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define SIZE 100

int main(int argc, char *argv[])
{
	 int sockfd;
	 char buf[SIZE];
	 char recv_array[SIZE] = {0};
	 ssize_t length = 0;
     socklen_t addrlen;
	 struct sockaddr_in serveraddr = {0};
	 struct sockaddr_in clientaddr = {0};
	 sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	 if(sockfd < 0)
	 {
		  printf("创建套接字失败! \n");
		  exit(1);
	 }
     serveraddr.sin_family = AF_INET;
	 serveraddr.sin_port = htons(6000);
	 serveraddr.sin_addr.s_addr = INADDR_ANY;
	 if(bind(sockfd, (struct sockaddr *)&serveraddr,sizeof(serveraddr)) < 0)
	 {
		  printf("绑定套接字失败! \n");
		  exit(1);
	 }
	 addrlen = sizeof(clientaddr);
     length=recvfrom(sockfd,recv_array,SIZE,0,(struct sockaddr *)&clientaddr,&addrlen);
	 printf("length = %d\n",(int)length);
	 printf("receive: %s\n",recv_array);
//	 printf("客户端IP: %s\n", inet_ntoa(clientaddr.sin_addr));
//	 printf("客户端IP: %s\n",inet_ntop(AF_INET,&clientaddr.sin_addr,buf,sizeof(buf)));
	 inet_ntop(AF_INET, &clientaddr.sin_addr, buf, sizeof(buf));
	 printf("客户端IP地址: %s\n", buf);
	 printf("端口: %d\n", ntohs(clientaddr.sin_port));
//	 printf("客户端IP: %s\n", clientaddr.sin_addr.sin);
	 close(sockfd);
	 return 0;
}
