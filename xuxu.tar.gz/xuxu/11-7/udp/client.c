#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define SIZE 100

int main(int argc, char *argv[])
{
	 int sockfd;
	 char send_array[SIZE] = {0};
	 struct sockaddr_in serveraddr = {0};
	 /*创建套接字*/
	 sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	 if(sockfd < 0)
	 {
		  printf("创建套接字失败! \n");
		  exit(1);
	 }
	 /*指定IP地址，端口号以及协议类型*/
	 serveraddr.sin_family = AF_INET;
	 serveraddr.sin_port = htons(6000);
//	 serveraddr.sin_addr.s_addr = INADDR_ANY;
	 serveraddr.sin_addr.s_addr = inet_addr("127.0.0.1");
	 /*将传输的内容复制到字符串数组*/
	 strcpy(send_array, "hello server!");
	 sendto(sockfd,send_array,SIZE,0,(struct sockaddr *)&serveraddr,sizeof(serveraddr));
	 close(sockfd);
	 return 0;
}
