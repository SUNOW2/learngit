#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#define Maxsize 100
typedef int datatype;
typedef struct
{
	datatype stack[Maxsize];
    int top;
}SeqStack;

void display(SeqStack *s)
{
	int t;
	t = s->top;
	if(s->top == -1)
	{
		printf("栈是空的： \n");
//		return 0;
	}
	else
		while(t != -1)
		{
			t--;
			printf("%d->",s->stack[t]);
		}
}

int main(int argc, char *argv[])
{
	int a[6] = {3,7,4,12,31,15},i;
	SeqStack *p;
	p =initstack();
	for(i=0; i<6; i++)
	{
		Push(p, a[i]);
	}
	printf("输出栈中的数值： \n");
	display(p);
	printf("\n");
	printf("栈顶元素是: %d\n",GetTop(p));
	Push(p, 100);
    printf("输出栈中的数值： \n");
	display(p);
    printf("\n");
	printf("栈顶元素是： %d\n",GetTop(p));
    Pop(p);Pop(p);
    printf("栈顶元素是： %d\n",GetTop(p));
	while(!StackEmpty(p))
		printf("%4d\n",Pop(p));
	printf("\n");
}
