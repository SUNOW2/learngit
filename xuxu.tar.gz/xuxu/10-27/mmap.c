#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <fcntl.h>

#define COPYSIZE 1024
int main(int argc, char *argv[])
{
	int fdin,fdout;
	void *src,*dst;
	size_t copysz;
	struct sbuf;
	off_t fsz = 0;
	if(argc != 3)
	{
	    printf("please input infile and outfile!\n");
		exit(1);
	}
	if((fdin = open(argv[1], O_RDONLY)) < 0)
	{
		printf("cannot open %s for reading\n",argv[1]);
	}
	if((fdout = open(argv[2], O_RDWR | O_CREAT, 0777)) < 0)
	{
		printf("cannot open %s for writing\n",argv[2]);
	}

	fstat(fdin,&sbuf);
	ftruncate(fdout,sbuf.st_size);

	while(fsz < sbuf.st_size)
	{
		if((sbuf.st_size-fsz) > COPYSIZE)
			copysz = fsz;
		else
			copysz = sbuf.st_size - fsz;
		src = mmap();
	}
}
