#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/types.h>
#include <string.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 1234
#define LENGTH 10
#define SIZE 100


int main(int argc, char *argv[])
{
	int res;
	int clientfd;
	int sockfd;
	pid_t pid;
	time_t timep;
	char buf[50];
	char client_ip[SIZE];
	char array[SIZE];
	socklen_t addrlen;
	struct sockaddr_in host_addr;
	struct sockaddr_in client_addr;
	if(argc != 1)
	{
		printf("参数错误! \n");
		exit(1);
	}
	/*创建套接字*/
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1)
	{
		printf("创建套接字失败! \n");
		exit(1);
	}

	bzero(&host_addr,sizeof(host_addr));
	host_addr.sin_family = AF_INET;
	host_addr.sin_port = htons(PORT);
	host_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	bzero(&(host_addr.sin_zero), 8);

	/*绑定套接字*/
	res=bind(sockfd,(struct sockaddr *)&host_addr,sizeof(struct sockaddr));
	if(res == -1)
	{
		printf("绑定套接字失败! \n");
		exit(1);
	}

	/*设置监听模式*/
	res = listen(sockfd, LENGTH);
	if(res == -1)
	{
		printf("设置监听模式失败! \n");
		exit(1);
	}

	/*实现支持多个client同时连接*/
	while(1)
	{
		addrlen = sizeof(struct sockaddr_in);
		clientfd = accept(sockfd, (struct sockaddr *)&client_addr, &addrlen);
		if(clientfd == -1)
		{
			printf("接受连接请求失败! \n");
			exit(1);
		}
		if((pid = fork()) == 0)
		{
			close(sockfd);
			inet_ntop(AF_INET,&client_addr.sin_addr,client_ip,sizeof(client_ip));
			printf("Message from %s,port %d\n",client_ip, ntohs(client_addr.sin_port));

			/*接收数据端数据*/

			while(1)
			{
				res == recv(clientfd, array, SIZE, 0);
				if(res == -1)
				{
					printf("接受客户端数据失败! \n");
					exit(1);
				}
				else
				{
					sleep(1);
					printf("接收到的数据是: %s",array);
				}
				bzero(array, SIZE);

				/*回复客户端*/
				bzero(buf, sizeof(buf));
				snprintf(buf,sizeof(buf),"%s","Hi,this is server");
				if(send(clientfd, buf, SIZE, 0) < 0)
				{
					exit(1);
				}
			}
			close(clientfd);
			exit(0);
		}
		close(clientfd);
	}
	//	close(sockfd);
	return 0;
}
