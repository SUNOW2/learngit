#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <sys/socket.h>
#include <pthread.h>
#include <semaphore.h>
#include <netinet/in.h>

#define PORT 1234
#define LENGTH 10
#define SIZE 100

sem_t sem;

char array[SIZE];

void thread1(int *sockfd)
{
	FILE *filp;
	filp = fopen("hello","r");
	while(1)
	{
		if(fread(array, 1, SIZE, filp) != SIZE )
		{
			send(*sockfd, array, SIZE, 0);
			if(feof(filp))
			{
				printf("到达文件尾!\n");
				break;
			}
		}
		sem_post(&sem);               /*激活阻塞在信号量上的线程*/
//		sleep(3);
	}
	pthread_exit(NULL);
}

void thread2(int *sockfd)
{
	int res;
	char buf[200];
	while(1)
	{
		sem_wait(&sem);
		res = send(*sockfd, array, SIZE, 0);
		if(res == -1)
		{
			printf("传送数据失败! \n");
			exit(1);
		}
		bzero(buf, 200);
		if(recv(*sockfd, buf, 200, 0) < 0)
		{
			printf("数据接收失败! \n");
			exit(1);
		}
		printf("服务器说::%s\n",buf);
		sem_wait(&sem);
//	    sleep(3);
	}
	pthread_exit(NULL);
}

int main(int argc, char *argv[])
{
	int res;
	int sockfd;
	FILE *filp;
	time_t timep;
	pthread_t pth1;
	pthread_t pth2;
	char array[SIZE];
	char buf[SIZE];
	socklen_t addrlen;
	struct sockaddr_in host_addr;
	if(argc != 2)
	{
		printf("参数错误! \n");
		exit(1);
	}
	/*创建套接字*/
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1)
	{
		printf("创建套接字失败! \n");
		exit(1);
	}

	bzero(&host_addr,sizeof(host_addr));
	host_addr.sin_family = AF_INET;
	host_addr.sin_port = htons(PORT);
	host_addr.sin_addr.s_addr = inet_addr(argv[1]);
	bzero(&(host_addr.sin_zero), 8);

	/*连接*/
	addrlen = sizeof(struct sockaddr);
	res =  connect(sockfd, (struct sockaddr*)&host_addr, addrlen);
	if(res == -1)
	{
		printf("接受连接请求失败! \n");
		exit(1);
	}
	while(1)
	{
		sem_init(&sem,0,0);
		res = pthread_create(&pth1, NULL, (void *)&thread1, &sockfd);
		if(res != 0)
		{
			printf("创建线程失败!\n");
			exit(EXIT_FAILURE);
		}

		res = pthread_create(&pth2, NULL, (void *)&thread2, &sockfd);
		if(res != 0)
		{
			printf("创建线程失败!\n");
			exit(EXIT_FAILURE);
		}

		pthread_join(pth1,NULL);
		pthread_join(pth2,NULL);
		sem_destroy(&sem);

	}
	close(sockfd);
	return 0;
}
