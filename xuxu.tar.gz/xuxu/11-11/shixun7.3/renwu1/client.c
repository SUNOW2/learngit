/* write by: ghost */
#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#define MSG_FILENAME 1
#define MSG_CONTENT 2
#define MSG_ACK 3
#define MSG_DONE 4
#define MSG_EXCEPTION 5
struct msg
{
	int type;
	int data_len;
	char data[1024];
};
int main(int argc,char *argv[])
{
	int sock_fd;
	char buff[1001]="0";
	struct sockaddr_in client_addr={
		0
	};
	FILE *fp;
	fp=fopen(argv[2],"r");
	if((sock_fd=socket(AF_INET,SOCK_STREAM,0))<0)
		printf("socket error\n");
	client_addr.sin_family=AF_INET;
	client_addr.sin_port=htons(2500);
	inet_pton(AF_INET,argv[1],&client_addr.sin_addr);
if(connect(sock_fd,(struct sockaddr*)&client_addr,sizeof(client_addr)))
	printf("error");
struct msg message;
message.type=MSG_FILENAME;
printf("type the name you want to creat\n");
gets(message.data);
message.data_len=strlen(message.data);
send(sock_fd,&message,sizeof(message),0);
recv(sock_fd,&message,sizeof(message),0);
while(1)
{
	fread(buff,1000,1,fp);
message.type=MSG_CONTENT;
strcpy(message.data,buff);
message.data_len=strlen(buff);
send(sock_fd,&message,sizeof(message),0);
recv(sock_fd,&message,sizeof(message),0);
if(feof(fp))
{
	message.type=MSG_DONE;
send(sock_fd,&message,sizeof(message),0);
	close(sock_fd);
	fclose(fp);
	exit(0);
}
if(ferror(fp))
{
	message.type=MSG_EXCEPTION;
send(sock_fd,&message,sizeof(message),0);
	close(sock_fd);
	fclose(fp);
	printf("file error\n");
	exit(0);
}
bzero(&message,sizeof(message));
bzero(buff,1000);
}



return 0;

}
