#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <signal.h>
#define MSG_FILENAME 1
#define MSG_CONTENT 2
#define MSG_ACK 3
#define MSG_DONE 4
#define MSG_EXCEPTION 5
#define BUF_SIZE 4
#define SIZE 100
#define BUF 1024


struct msg
{
	int type;
	int data_len;
	char data[1024];
};

char *buffer[BUF_SIZE];
int rear = 0;
int head = 0;
volatile int count = 0;
struct msg *cur_buf;
struct msg *cur_buf1;
FILE *fp;
pthread_mutex_t mutex;

void thread1(int *clientfd)
{
	int i = 0;
	while(1)
	{
		if(rear == head)
		{
			while(count >= BUF_SIZE)
				i++;
		}
		cur_buf = (struct msg *)buffer[rear];
		if(recv(*clientfd,(void *)cur_buf,sizeof(struct msg),0)==-1)
		{
			fclose(fp);
			exit(0);
		}
		if(cur_buf->type == MSG_FILENAME)
		{
			fp=fopen(cur_buf->data,"w+");
			printf("文件名%s\n", cur_buf->data);
			printf("文件创建!\n");
		}
		if(cur_buf->type == MSG_DONE)
		{
			close(*clientfd);
			fclose(fp);
			printf("文件结束!\n ");
			exit(0);
		}
		if(cur_buf->type == MSG_EXCEPTION)
		{
			close(*clientfd);
			fclose(fp);
			printf("文件发送错误!\n ");
			exit(0);
		}
		if(cur_buf->type == MSG_CONTENT)
		{
			printf("%s\n",cur_buf->data);
			cur_buf->type=MSG_ACK;
			send(*clientfd,cur_buf,sizeof(struct msg),0);
		}

		rear = (rear+1)%BUF_SIZE;
		pthread_mutex_lock(&mutex);
		count++;
		pthread_mutex_unlock(&mutex);
	}
	pthread_exit(NULL);

}


void sig_child(int signo)
{
	pid_t pid;
	int stat;
	while((pid=waitpid(-1,&stat,WNOHANG))>0)
		printf("客户端停止\n");
}

void thread2(int *clientfd)
{

	int i = 0;
	int res;
	while(1)
	{
		if(rear == head)
		{
			while(count <= 0)
				i++;
		}
		cur_buf1 = (struct msg*)buffer[head];
		fwrite(cur_buf1->data,1,SIZE,fp);
		printf("%s\n",cur_buf1->data);
        bzero(cur_buf1,sizeof(cur_buf1));

		head = (head+1)%BUF_SIZE;
		pthread_mutex_lock(&mutex);
		count--;
		pthread_mutex_unlock(&mutex);
	}
    fclose(fp);
	pthread_exit(NULL);
}

int main(int argc,char *argv[])
{
	int i = 0;
	int sock_fd,addrlen,clientfd,len;
	struct sockaddr_in server_addr;
	struct sockaddr_in client_addr;
	struct sockaddr_in peeraddr;
	pthread_t pth1;
	pthread_t pth2;
	char ip[50];
	int res;
	time_t time_s;
	char buff[100];
	int id=0;
	FILE *fp;
	struct	msg  message;
	ssize_t recvlen=0;
	for(i=0; i<BUF_SIZE; i++)
	{
		buffer[i] = (char *)malloc(sizeof(char) * BUF);
	}
	signal(SIGCHLD,sig_child);
	if((sock_fd=socket(AF_INET,SOCK_STREAM,0))<0)
		printf("创建套接字失败!\n");
	else
	{
		printf("创建套接字成功!\n");
	}
	server_addr.sin_family=AF_INET;
	server_addr.sin_addr.s_addr=htonl(INADDR_ANY);
	server_addr.sin_port=htons(2500);
	bind(sock_fd,(struct sockaddr*)&server_addr,sizeof(server_addr));
	listen(sock_fd,10);
	addrlen=sizeof(client_addr);
	while(1)
	{

		clientfd=accept(sock_fd,(struct sockaddr*)&client_addr,&addrlen);
		id=fork();
		if(id==0)
		{
			close(sock_fd);
			len=sizeof(peeraddr);
			getpeername(clientfd,(struct sockaddr*)&peeraddr,&len);
			inet_ntop(AF_INET,&peeraddr.sin_addr,ip,sizeof(ip));
			printf("client ip=%s     port=%d\n",ip,peeraddr.sin_port);

			res = pthread_mutex_init(&mutex, NULL);
			if(res != 0)
			{
				printf("互斥量初始化失败!\n");
				exit(1);
			}
			res = pthread_create(&pth1, NULL, (void *)thread1,&clientfd);
			if(res != 0)
			{
				printf("创建线程1失败!\n");
				exit(1);
			}

			res = pthread_create(&pth2, NULL, (void *)thread2,&clientfd);
			if(res != 0)
			{
				printf("创建线程1失败!\n");
				exit(1);
			}
			pthread_join(pth1,NULL);
			pthread_join(pth2,NULL);
			pthread_mutex_destroy(&mutex);
			close(clientfd);
			exit(0);
		}
		close(clientfd);
}
//fclose(fp);
close(sock_fd);
return 0;

}
