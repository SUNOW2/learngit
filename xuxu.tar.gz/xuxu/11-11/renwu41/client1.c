#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <sys/socket.h>
#include <pthread.h>
#include <netinet/in.h>

#define PORT 2500
#define LENGTH 10
#define SIZE 1024
#define BUF_SIZE 4
#define MSG_FILENAME 1
#define MSG_CONTENT 2
#define MSG_ACK 3
#define MSG_DONE 4
#define MSG_EXCEPTION 5

struct msg
{
	int type;
	int data_len;
	char data[1024];
};

pthread_mutex_t mutex;

char *buffer[BUF_SIZE];
int rear = 0;
int head = 0;
volatile int count = 0; 
struct msg *cur_buf;
struct msg *cur_buf1;
FILE *filp;

void thread1(int *sockfd)
{
	int i = 0;
	char *ptr;
	char array[SIZE];

	if(rear == head)
	{
		while(count>=BUF_SIZE)
			i++;
	}


	filp = fopen("/etc/passwd","r");
	ptr = strrchr("/etc/passwd",'p');
	printf("文件名:%s\n",ptr);
	cur_buf = (struct msg *)buffer[rear];
	/*设置文件名类型*/
	cur_buf->type = MSG_FILENAME;
	strcpy(cur_buf->data, ptr);
	cur_buf->data_len = strlen(ptr);

	send(*sockfd, cur_buf, sizeof(struct msg),0);
//	recv(*sockfd, cur_buf, sizeof(struct msg),0);
	while(1)
	{
		if(rear == head)
		{
			while(count>=BUF_SIZE)
				i++;
		}
	    cur_buf = (struct msg *)buffer[rear];
		fread(array, 1, 100, filp);
		cur_buf->type = MSG_CONTENT;

		strcpy(cur_buf->data, array);

		cur_buf->data_len = strlen(array);
		if(feof(filp))
		{
			cur_buf->type = MSG_DONE;
			send(*sockfd, cur_buf, sizeof(struct msg),0);
			close(*sockfd);
			fclose(filp);
			exit(0);
		}

		if(ferror(filp))
		{
			cur_buf->type = MSG_EXCEPTION;
			send(*sockfd, cur_buf, sizeof(struct msg),0);
			close(*sockfd);
			fclose(filp);
			printf("传输出错!\n");
			exit(0);
		}


		rear = (rear+1)%BUF_SIZE;	
		pthread_mutex_lock(&mutex);
		count++;
		pthread_mutex_unlock(&mutex);
	}
	pthread_exit(NULL);
}

void thread2(int *sockfd)
{
	int i = 0;
	int res;
//	cur_buf1 = (struct msg*)buffer[head];
	while(1)
	{
		if(rear == head)
		{
			while(count <= 0)
				i++;
		}
        cur_buf1 = (struct msg*)buffer[head];
		send(*sockfd,(void *) cur_buf1, sizeof(struct msg),0);
		recv(*sockfd,(void *)cur_buf1, sizeof(struct msg),0);
		printf("%s\n",cur_buf1->data);
		bzero(cur_buf1,sizeof(cur_buf1));

		head = (head+1)%BUF_SIZE;
		pthread_mutex_lock(&mutex);
		count--;
		pthread_mutex_unlock(&mutex);
	}
	pthread_exit(NULL);
}

int main(int argc, char *argv[])
{
	int i;
	int res;
	int sockfd;
	FILE *filp;
	pthread_t pth1;
	pthread_t pth2;
	socklen_t addrlen;
	struct sockaddr_in host_addr;
	if(argc != 2)
	{
		printf("参数错误! \n");
		exit(1);
	}
	for(i=0; i<BUF_SIZE; i++)
	{
		buffer[i] = (char *)malloc(sizeof(char) * SIZE);
	}
	/*创建套接字*/
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1)
	{
		printf("创建套接字失败! \n");
		exit(1);
	}

	bzero(&host_addr,sizeof(host_addr));
	host_addr.sin_family = AF_INET;
	host_addr.sin_port = htons(PORT);
	host_addr.sin_addr.s_addr = inet_addr(argv[1]);
	bzero(&(host_addr.sin_zero), 8);

	/*连接*/
	addrlen = sizeof(struct sockaddr);
	res =  connect(sockfd, (struct sockaddr*)&host_addr, addrlen);
	if(res == -1)
	{
		printf("接受连接请求失败! \n");
		exit(1);
	}
//		while(1)
//		{

	res = pthread_mutex_init(&mutex, NULL);
	if(res != 0)
	{
		printf("互斥量初始化失败!\n");
		exit(EXIT_FAILURE);
	}
	res = pthread_create(&pth1, NULL, (void *)&thread1, &sockfd);
	if(res != 0)
	{
		printf("创建线程失败!\n");
		exit(EXIT_FAILURE);
	}

	res = pthread_create(&pth2, NULL, (void *)&thread2, &sockfd);
	if(res != 0)
	{
		printf("创建线程失败!\n");
		exit(EXIT_FAILURE);
	}

	pthread_join(pth1,NULL);
	pthread_join(pth2,NULL);
	pthread_mutex_destroy(&mutex);

//	}
	close(sockfd);
	return 0;
}
