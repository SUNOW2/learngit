#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<sys/types.h>
#include <sys/wait.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<time.h>
#include<signal.h>
#define MSG_FILENAME 1
#define MSG_CONTENT 2
#define MSG_ACK 3
#define MSG_DONE 4
#define MSG_EXCEPTION 5
struct msg
{
	int type;
	int data_len;
	char data[1024];
};
void sig_child(int signo)
{
	pid_t pid;
	int stat;
	while((pid=waitpid(-1,&stat,WNOHANG))>0)
		printf("客户端停止\n");
}
int main(int argc,char *argv[])
{
	int sock_fd,addrlen,newsock_fd,len;
	struct sockaddr_in server_addr;
	struct sockaddr_in client_addr;
	struct sockaddr_in peeraddr;
	char ip[50];
	time_t time_s;
	char buff[1000];
	int id=0;
	FILE *fp;
	struct	msg  message;
	ssize_t recvlen=0;
	signal(SIGCHLD,sig_child);
	if((sock_fd=socket(AF_INET,SOCK_STREAM,0))<0)
		printf("创建套接字失败!\n");
	else
	{
		printf("创建套接字成功!\n");
	}
	server_addr.sin_family=AF_INET;
	server_addr.sin_addr.s_addr=htonl(INADDR_ANY);
	server_addr.sin_port=htons(2500);
	bind(sock_fd,(struct sockaddr*)&server_addr,sizeof(server_addr));
	listen(sock_fd,10);
	addrlen=sizeof(client_addr);
	while(1)
	{
		newsock_fd=accept(sock_fd,(struct sockaddr*)&client_addr,&addrlen);
		id=fork();
		if(id==0)
		{
			close(sock_fd);
			len=sizeof(peeraddr);
			getpeername(newsock_fd,(struct sockaddr*)&peeraddr,&len);
			inet_ntop(AF_INET,&peeraddr.sin_addr,ip,sizeof(ip));
			printf("client ip=%s     port=%d\n",ip,peeraddr.sin_port);
			while(1)
			{
				if(recv(newsock_fd,&message,sizeof(message),0)==-1)
				{
					fclose(fp);
					exit(0);
				}
				if(message.type==MSG_FILENAME)
				{
					fp=fopen(message.data,"w+");
					printf("文件名%s\n", message.data);
					printf("文件创建!\n");
				}
				if(message.type==MSG_DONE)
				{
					close(newsock_fd);
					fclose(fp);
					printf("文件结束!\n ");
					exit(0);
				}
				if(message.type==MSG_EXCEPTION)
				{
					close(newsock_fd);
					fclose(fp);
					printf("文件发送错误!\n ");
					exit(0);
				}
				if(message.type==MSG_CONTENT)
				{
					fwrite(message.data,message.data_len,1,fp);
					printf("%s\n",message.data);
					message.type=MSG_ACK;
					send(newsock_fd,&message,sizeof(message),0);
				}
			}
			close(newsock_fd);
			exit(0);
		}
		close(newsock_fd);

	}
	fclose(fp);
	return 0;

}
