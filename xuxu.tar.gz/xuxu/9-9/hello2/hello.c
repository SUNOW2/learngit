#include <stdio.h>
//#include "my_info.h"
int main1(void);
int main(void)
{
		 printf("hello world!\n");
		 main1();
		 return 0;
}
