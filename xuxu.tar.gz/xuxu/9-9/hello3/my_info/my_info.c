#include <stdio.h>
#include "my_info.h"
int main1()
{
		 printf("My number is 1416101112!\n");
		 main2();
		 return 0;
}
