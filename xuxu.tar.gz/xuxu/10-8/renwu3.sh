#!/bin/bash
gnome-terminal -t "1" -x bash -c "./renwu1;./renwu1.1;exec bash;"
gnome-terminal -t "2" -x bash -c "./renwu1;./renwu1.1;exec bash;"
gnome-terminal -t "3" -x bash -c "./renwu1;./renwu1.1;exec bash;"
ps -ef | grep renwu1 | awk '{print $1 "\t" $2 "\t" $3 "\t" $4}' 
ps -ef | grep renwu1.1 | awk '{print $1 "\t" $2 "\t" $3 "\t" $4}'
sleep 3
killall renwu1 
killall renwu1.1
ps -aux
