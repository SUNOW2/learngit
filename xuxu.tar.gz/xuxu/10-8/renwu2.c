#include <stdio.h>
#include <stdlib.h>
int main(int argc,char *argv[])
{
	//int a=atoi(argv[1]);
	//int b=atoi(argv[2]);
    int x,y;
    scanf("%d",&x);
	scanf("%d",&y);
	while(x>0&&x<100000&&y>0&&y<100000)
	{
		printf("%d\n",x+y);
		sleep(2);
        scanf("%d",&x);
     	scanf("%d",&y);
	}
	return 0;
}
