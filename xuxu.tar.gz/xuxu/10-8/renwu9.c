#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
int main()
{
	char name1[50];
	char name2[50];
	char rename[50]="sunow1-machine";
	gethostname(name1,sizeof(name1));
	printf("hostname = %s\n",name1);
    sethostname(rename,sizeof(rename));
   	gethostname(name2,sizeof(name2));
   	printf("hostname = %s\n",name2);
	return 0;
}
