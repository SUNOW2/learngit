#!/bin/bash
mkdir wenjian14
a=$(du * | awk '{if($1>5000) print $2}')
for file in $a
do
  cp -rf $file wenjian14
done
