#!/bin/bash
a='/var/log/boot.log'
echo $a
b=${a%/*}
c=${a##*/}
d=${a##*.}
echo $b
echo $c
echo $d
