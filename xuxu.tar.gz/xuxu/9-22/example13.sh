#!/bin/bash
i=0
while [[ i -lt 50 ]]
do
  mkdir /userdata/user$((++i))
  chmod 754 /userdata/user$i
done
