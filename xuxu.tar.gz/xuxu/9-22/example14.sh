#!/bin/bash
counterl=0
counter=0
#echo $PATH > example15.5h
#sed 's/:/ /g' example15.sh
for mulu in `echo $PATH | sed 's/:/ /g'`
do
   counterl=$((++counterl))
 for file in `ls $mulu`
   do
      counter=$((++counter))
   done
done    
echo $counterl
echo $counter
