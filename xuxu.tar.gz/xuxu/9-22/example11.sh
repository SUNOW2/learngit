#!/bin/bash
i=0
groupadd -g 744 class1
while [[ $i -lt 30 ]]
do
   useradd stu$((++i)) -g class1
done
