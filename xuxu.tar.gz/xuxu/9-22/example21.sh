#!bin/bash
arr=(1 3 5 4 7 9)
for((i=0;i<${#arr[@]};i++))
{
		 for((j=0;j<${#arr[@]}-1;j++))
		 {
				  if [[ ${arr[j]} -gt ${arr[j+1]} ]]
						  then
								  tmp=${arr[j]}
								  arr[j]=${arr[j+1]}
								  arr[j+1]=$tmp
				  fi
		 }
}
echo "After sort"
echo ${arr[@]}
