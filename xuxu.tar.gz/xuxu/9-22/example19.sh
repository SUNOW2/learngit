#!/bin/bash
a=$(find ./ -type f -size +10k) 
for file in $a
do
  cp -rf $file /tmp
done
