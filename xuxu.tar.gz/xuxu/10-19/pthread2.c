#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void *start_routine(void *message)
{
	printf("message = %s\n",(char *)message);
	pthread_exit("\n");
}
int main()
{
	void *pthread_result;
	pthread_t pth;
	char *message = "hello world!";
    int res;

	res = pthread_create(&pth,NULL,start_routine,(void *)message);
    if(res != 0)
	{
		printf("fail to creat pthread!\n");
		exit(EXIT_FAILURE);
	}
	else
	{
		printf("succeed to creat pthread!\n");
	}

	pthread_join(pth, &pthread_result);
	sleep(1);
	printf("pthread exit:%s",(char *)pthread_result);
	return 0;
}
