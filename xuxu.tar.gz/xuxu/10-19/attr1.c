#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

int main()
{
	pthread_t pth;
	pthread_attr_t attr;
	int res;
	res = ptnread_attr_init(&attr);
    if(res != 0)
	{
		printf("fail to init!\n");
		exit(1);
	}

}
