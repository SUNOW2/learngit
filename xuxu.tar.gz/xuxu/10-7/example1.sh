
   char tmp[];
   sprintf(tmp,"/bin/mount -t vfat %s /mnt/usb",dev);
   system(tmp);
