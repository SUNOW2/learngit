#include <stdio.h>
#include <stdlib.h>
int main()
{
   char tmp[10];
   char dev="hello";
   sprintf(tmp,"/bin/mount -t vfat %s /mnt/usb",dev);
   printf("%s",tmp);
   system(tmp);
}

