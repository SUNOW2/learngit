#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 0
#define LENGTH 10

int main(int argc, char *argv[])
{
	int listenfd,connfd;
	struct sockaddr_in serveraddr;
	pid_t pid;
	char temp[20];

	listenfd = socket(AF_INET, SOCK_STREAM, 0);

	bzero(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(PORT);
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);

	bind(listenfd, (struct sockaddr *)&serveraddr, sizeof(serveraddr));
	listen(listenfd, LENGTH);
	while(1)
	{
		 struct sockaddr_in local;
		 connfd = accept(listenfd, (struct sockaddr *)NULL, NULL);
		 if((pid = fork()) == 0)
		 {
			  close(listenfd);
			  struct sockaddr_in serv,guest;
              char serv_ip[20];
//			  char guest_ip[20];
			  socklen_t serv_len = sizeof(serv);
//			  socklen_t guest_len = sizeof(guest);
			  getsockname(connfd, (struct sockaddr *)&serv, &serv_len);
//			  getpeername(connfd, (struct sockaddr *)&guest, &guest_len);
			  inet_ntop(AF_INET, &serv.sin_addr, serv_ip, sizeof(serv_ip));
//			  inet_ntop(AF_INET,&guest.sin_addr,guest_ip,sizeof(guest_ip));
//			  printf("host %s:%d\nguest %s:%d\n",serv_ip,ntohs(serv.sin_port), guest_ip,ntohs(guest.sin_port));

			  printf("host %s:%d\n",serv_ip, ntohs(serv.sin_port));
			  char buf[] = "hello world!";
			  write(connfd, buf, strlen(buf));
			  close(connfd);
			  exit(0);
		 }
		 close(connfd);
	}
	return 0;
}
