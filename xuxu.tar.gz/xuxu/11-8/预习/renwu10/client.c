#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 1235
#define SIZE 100

int main(int argc, char *argv[])
{
	int res;
	int sockfd;
	char array[SIZE];
	socklen_t addrlen;
	struct sockaddr_in host_addr;
	if(argc != 2)
	{
		 printf("参数错误! \n");
		 exit(1);
	}
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if(sockfd == -1)
	{
		 printf("创建套接字失败! \n");
		 exit(1);
	}
	else
	{
		 printf("创建套接字成功! \n");
		 printf("sockfd = %d\n",sockfd);
	}
    host_addr.sin_family = AF_INET;
	host_addr.sin_port = htons(PORT);
//	host_addr.sin_addr.s_addr =inet_addr("192.168.255.145");
	host_addr.sin_addr.s_addr =inet_addr(argv[1]);
	bzero(&(host_addr.sin_zero), 8);
	printf("请输入传输的字符串! \n");
	fgets(array, SIZE, stdin);
	addrlen = sizeof(struct sockaddr_in);
	res=sendto(sockfd,array,SIZE, 0,(struct sockaddr *)&host_addr, addrlen);
	if(res == -1)
	{
		 printf("发送数据失败! \n");
		 exit(1);
	}
	bzero(&array,sizeof(array));
	if(recvfrom(sockfd,array,SIZE,0,(struct sockaddr *)&host_addr,&addrlen) < 0)
	{
		 printf("接受失败! \n");
		 exit(1);
	}
	printf("服务器说:%s\n",array);
	close(sockfd);
	return 0;
}
