#include <stdio.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 1234
#define LENGTH 10
#define SIZE 100

int main(int argc, char *argv[])
{
	int res;
	int clientfd;
	int sockfd;
	char buf[SIZE];
	socklen_t addrlen;
    struct sockaddr_in host_addr;
	struct sockaddr_in client_addr;
	if(argc != 1)
	{
		 printf("参数错误! \n");
		 exit(1);
	}
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1)
	{
		 printf("创建套接字失败! \n");
		 exit(1);
	}
	else
	{
		 printf("创建套接字成功! \n");
		 printf("sockfd = %d\n",sockfd);
	}
    host_addr.sin_family = AF_INET;
	host_addr.sin_port = htons(PORT);
	host_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	bzero(&(host_addr.sin_zero), 8);
    res=bind(sockfd,(struct sockaddr *)&host_addr,sizeof(struct sockaddr));
	if(res == -1)
	{
		 printf("绑定套接字失败! \n");
		 exit(1);
	}
	else
	{
		 printf("绑定套接字成功! \n");
	}
	res = listen(sockfd, LENGTH);
	if(res == -1)
	{
		 printf("设置监听模式失败! \n");
		 exit(1);
	}
	else
	{
		 printf("设置监听模式成功! \n");
	     printf("服务器端端口号: %d\n",ntohs(host_addr.sin_port));
	}
	addrlen = sizeof(struct sockaddr_in);
	clientfd = accept(sockfd, (struct sockaddr *)&client_addr, &addrlen);
	if(clientfd == -1)
	{
		 printf("接受连接请求失败! \n");
		 exit(1);
	}
	else
	{
		 printf("接受连接请求成功! \n");
    }
	inet_ntop(AF_INET, &client_addr.sin_addr, buf, sizeof(buf));
	printf("客户端地址IP: %s\n",buf);
	printf("客户端端口号: %d\n",ntohs(client_addr.sin_port));
	close(sockfd);
	return 0;
}
