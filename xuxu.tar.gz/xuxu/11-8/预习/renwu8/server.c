#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 6676
#define LENGTH 10
#define SIZE 100

int main(int argc, char *argv[])
{
	int sockfd;
	int clientfd;
	char client_ip[SIZE];
	socklen_t addrlen;
	struct sockaddr_in serveraddr;
	struct sockaddr_in clientaddr;

	if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		 printf("创建套接字失败! \n");
		 exit(1);
	}

	bzero(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(PORT);
	serveraddr.sin_addr.s_addr = INADDR_ANY;
	bzero(&serveraddr.sin_zero, 8);

	if(bind(sockfd,(struct sockaddr *)&serveraddr,sizeof(serveraddr))<0)
	{
		 printf("绑定套接字失败! \n");
		 exit(1);
	}
	if(listen(sockfd, LENGTH) < 0)
	{
		 printf("监听失败!\n");
		 exit(1);
	}
	printf("在端口%d监听\n",ntohs(serveraddr.sin_port));
	addrlen = sizeof(struct sockaddr);
	clientfd = accept(sockfd,(struct sockaddr *)&clientaddr,&addrlen);
    /*端口号为0,获取IP和端口号*/
    socklen_t client_len = sizeof(clientaddr);
    getpeername(clientfd, (struct sockaddr *)&clientaddr, &client_len);
    inet_ntop(AF_INET,&clientaddr.sin_addr,client_ip,sizeof(client_ip));
	printf("客户端IP :%s\n",client_ip);
	printf("客户端Port: %d\n",ntohs(clientaddr.sin_port));
	close(sockfd);
	return 0;
}
