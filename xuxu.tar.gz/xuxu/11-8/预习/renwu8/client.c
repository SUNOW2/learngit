#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <errno.h>

#define PORT 6676
#define LENGTH 10

int main(int argc, char *argv[])
{
	int res;
	int sockfd;
	socklen_t addrlen;
	struct sockaddr_in host_addr;
	if(argc != 2)
	{
		 printf("参数错误! \n");
		 exit(1);
	}
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1)
	{
		 printf("创建套接字失败! \n");
		 exit(1);
	}
	else
	{
		 printf("创建套接字成功! \n");
		 printf("sockfd = %d\n",sockfd);
	}
    host_addr.sin_family = AF_INET;
	host_addr.sin_port = htons(PORT);
	host_addr.sin_addr.s_addr = inet_addr(argv[1]);
	bzero(&(host_addr.sin_zero), 8);
	addrlen = sizeof(struct sockaddr);
    inet_pton(AF_INET,argv[1], &host_addr.sin_addr);
	res =  connect(sockfd, (struct sockaddr*)&host_addr, addrlen);
	if(res == -1)
	{
		 printf("连接请求失败! %s\n",strerror(errno));
		 exit(1);
	}
	else
	{
		 printf("连接请求成功! \n");
	}
	close(sockfd);
	return 0;
}
