#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 1234
#define LENGTH 10

int main(int argc, char *argv[])
{
	int res;
	int sockfd;
	socklen_t addrlen;
    struct sockaddr_in host_addr;
	if(argc != 1)
	{
		 printf("参数错误! \n");
		 exit(1);
	}
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1)
	{
		 printf("创建套接字失败! \n");
		 exit(1);
	}
	else
	{
		 printf("创建套接字成功! \n");
	}
	addrlen = sizeof(struct sockaddr);
    host_addr.sin_family = AF_INET;
	host_addr.sin_port = htons(PORT);
	host_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	bzero(&(host_addr.sin_zero), 8);
    res = bind(sockfd, (struct sockaddr *)&host_addr, addrlen);
	if(res == -1)
	{
		 printf("绑定套接字失败! \n");
		 exit(1);
	}
	else
	{
		 printf("绑定套接字成功! \n");
	}
	return 0;
}
