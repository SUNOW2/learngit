#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 0
#define LENGTH 10
#define SIZE 100

int main(int argc, char *argv[])
{
	int sockfd;
	char serv_ip[SIZE];
	struct sockaddr_in serveraddr;

	if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
	{
		 printf("创建套接字失败! \n");
		 exit(1);
	}

	bzero(&serveraddr, sizeof(serveraddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(PORT);
	serveraddr.sin_addr.s_addr = htonl(INADDR_ANY);

	if(bind(sockfd, (struct sockaddr *)&serveraddr, sizeof(serveraddr)) < 0)
	{
		 printf("绑定套接字失败! \n");
		 exit(1);
	}
	if(listen(sockfd, LENGTH) < 0)
	{
		 printf("监听失败!\n");
		 exit(1);
	}
    socklen_t serv_len = sizeof(serveraddr);
    /*端口号为0,获取IP和端口号*/
    getsockname(sockfd, (struct sockaddr *)&serveraddr, &serv_len);
    inet_ntop(AF_INET, &serveraddr.sin_addr, serv_ip, sizeof(serv_ip));
	printf("server IP :%s",serv_ip);
	printf("Port: %d\n",serveraddr.sin_port);
	return 0;
}
