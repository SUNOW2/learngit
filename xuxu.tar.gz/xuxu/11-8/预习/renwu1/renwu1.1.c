#include <stdio.h>
#include <arpa/inet.h>

int main(int argc, char *argv[])
{
	 int i;
	 unsigned int x=0x12345678;
	 unsigned int y;
	 y = htonl(x);
	 printf("主机字节序(小端): 0x%x\n",x);
	 printf("网络字节序(大端): 0x%x\n",y);
	 return 0;
}
