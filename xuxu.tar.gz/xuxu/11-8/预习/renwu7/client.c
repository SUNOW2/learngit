#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 1234
#define LENGTH 10
#define DEST_IP "127.0.0.1"

int main(int argc, char *argv[])
{
     int n;
	 int sockfd;
	 char buf[100];
	 char serv_ip[20];
	 char guest_ip[20];
	 struct sockaddr_in serveraddr;
	 sockfd = socket(AF_INET, SOCK_STREAM, 0);
	 bzero(&serveraddr, sizeof(serveraddr));
	 serveraddr.sin_family = AF_INET;
	 serveraddr.sin_port = htons(PORT);
//	 server.sin_addr.s_addr = 
     inet_ntop(AF_INET,DEST_IP,&serveraddr.sin_addr);
	 connect(sockfd, (struct sockaddr *)&serveraddr, sizeof(serveraddr));

	 struct sockaddr_in serv,guest;
	 socklen_t serv_len = sizeof(serv);
	 socklen_t guest_len = sizeof(guest);

	 getsockname(sockfd, (struct sockaddr *)&serv, &serv_len);
	 getsockname(sockfd, (struct sockaddr *)&guest, &guest_len);

	 inet_ntop(AF_INET, &guest.sin_addr, guest_ip, sizeof(guest_ip));
	 inet_ntop(AF_INET, &serv.sin_addr, serv_ip, sizeof(serv_ip));

	 printf("host %s:%d\nguest %s:%d\n",serv_ip,ntohs(serv.sin_port),guest_ip,ntohs(guest.sin_port));
	 n = read(sockfd, buf, 100);
	 buf[n] = '\0';
	 printf("%s\n",buf);
	 close(sockfd);
	 exit(0);
}
