#include <stdio.h>
#include <arpa/inet.h>

int main(int argc, char *argv[])
{
	 int i;
	 unsigned int x=0x12345678;
	 unsigned int y;
//	 y = htonl(x);
//	 printf("主机字节序(小端): 0x%x\n",x);
//	 printf("网络字节序(大端): 0x%x\n",y);
     uint32_t b;
	 uint32_t a=0x12345678;
     printf("本地字节序(小端)\n");
	 for(i=0; i<4; i++)
	 {
		  printf("0x%x\t", *((char *)&a +i));
	 }
     printf("\n");
	 b = htonl(a);
     printf("网络字节序(大端)\n");
     for(i=0; i<4; i++)
	 {
		  printf("0x%x\t", *((char *)&b + i));
	 }
     printf("\n");
	 return 0;
}
