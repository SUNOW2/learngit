#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>

#define LENGTH 10
#define SIZE 128
#define SERV_PORT 2360

int main()
{
	int sockfd;
	int cnt;
	int clientfd;
	int res;
	int addrlen;
	char buf[SIZE];
	struct sockaddr_in hostaddr;
	struct sockaddr_in clientaddr;
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1)
	{
		printf("fail to socket!\n");
		exit(EXIT_FAILURE);
	}
	hostaddr.sin_family = AF_INET;
	hostaddr.sin_port = htons(SERV_PORT);
	hostaddr.sin_addr.s_addr = INADDR_ANY;
	bzero(&(hostaddr.sin_zero),8);
	res = bind(sockfd, (struct sockaddr *)&hostaddr, sizeof(struct sockaddr));
	if(res == -1)
	{
		printf("fail to bind");
		exit(EXIT_FAILURE);
	}
    res = listen(sockfd, LENGTH);
	if(res == -1)
	{
		printf("fail to liosten!\n");
		exit(EXIT_FAILURE);
	}
	printf("Waiting Cilent to bind!\n");
    while(1)
	{
		addrlen = sizeof(struct sockaddr_in);
		clientfd = accept(sockfd, (struct sockaddr *)&clientaddr, &addrlen);
		if(clientfd == -1)
		{
			printf("fail to accept!\n");
			continue;
		}
        printf("Client IP: %s\n",inet_ntoa(clientaddr.sin_addr));
		cnt = recv(clientfd, buf, SIZE, 0);
		if(cnt == -1)
		{
			printf("fail to receive!\n");
			exit(1);
		}
		printf("DATE: %s\n", buf);
		close(clientfd);
		break;
	}
	return 0;
}
