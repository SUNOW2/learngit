/*并发服务器: TCP*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define SERV_PORT 2369    /* 服务器端口号 */
#define LENGTH 10         /* 请求队列的长度数 */
#define SIZE 128          /* 缓冲区的长度 */

int main(int argc, char *argv[])
{
	int res;
	int cnt;
	int pth;
	int sockfd;          /*定义监听Socket描述符*/   
	int clientfd;
	int addrlen;
	struct fd_set fds;
	pid_t pid;
	char buf[SIZE];
	struct sockaddr_in hostaddr;   /*本机IP地址和端口号信息*/
	struct sockaddr_in clientaddr; /*客户端IP地址和端口号地址*/

	if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)   /*创建套接字*/
	{
		printf("套接字创建失败! \n");
		exit(1);
	}
    /*将套接字与IP地址和端口号进行绑定*/
	hostaddr.sin_family = AF_INET;       /*TCP/IP协议*/
	hostaddr.sin_port = htons(SERV_PORT); /*让系统随机选择一个未占用的端口号*/
	hostaddr.sin_addr.s_addr = INADDR_ANY;   /*本机IP地址*/
	bzero(&(hostaddr.sin_zero), 8);         /*清零*/
   /*绑定套接字*/
	res = bind(sockfd, (struct sockaddr *)&hostaddr, sizeof(struct sockaddr));
	if(res == -1)
	{
		printf("套接字绑定失败! \n");
		exit(1);
	}
    /*将套接字设为监听模式，以等待连接请球*/
	res = listen(sockfd, LENGTH);
	if(res == -1)
	{
		printf("监听失败! \n");
		exit(1);
	}
	printf("等待客户端连接! \n");
	/*循环处理客户端的请求*/
	while(1)
	{
		FD_ZERO(&fds);
        FD_SET(sockfd,&fds);
        switch(select(sockfd+1, &fds, &fds, NULL, &timeout))
		{
			
		}
		/*接受一个客户端的请求*/
		addrlen = sizeof(struct sockaddr);
		clientfd = accept(sockfd, (struct sockaddr *)&clientaddr, &addrlen);
		if(clientfd == -1)
		{
			printf("连接错误! \n");
			continue;
		}
		/*创建子进程，若创建失败，输出错误信息*/
		pid = fork(); 
		if(pid < 0)
		{
			printf("创建进程失败! \n");
			exit(1);
		}
		else if(pid == 0)         /*子进程，处理客户端的请求*/
		{
			close(sockfd);       /* 关闭父进程的套接字 */
			printf("客户端IP: %s\n",inet_ntoa(clientaddr.sin_addr));
			                                        /* 输出客户端的IP地址*/
			cnt = recv(sockfd, buf, SIZE, 0);/*如果数据接受失败，输出错误信息*/
			if(cnt == -1)
			{
				printf("接受数据失败! \n");
				exit(1);
			}
			printf("接收到的数据: %s\n",buf);     /*输出接收到的信息*/
			sleep(5);
			close(clientfd);                      /*关闭当前客户端的连接*/
			exit(0);
		}
	   close(clientfd);/*父进程，关闭子进程的套接字，准备接受下一个客户端连接*/
	}
	exit(0);
}
