#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
int main(int argc,char *argv[])
{
	struct stat sta;
	if(argc != 2)
	{
		printf("too few!\n");
		exit(1);
	}
	stat(argv[1],&sta);
	printf("wenjiandaxiao:%ld Byte\n",sta.st_size);
	printf("wenjianleixing:\n");
	switch (sta.st_mode & S_IFMT)
	{
		case S_IFSOCK:
			printf("1\n");
			break;
		case S_IFLNK:
			printf("2\n");
			break;
		case S_IFREG:
			printf("3\n");
			break;
		case S_IFBLK:
			printf("4\n");
			break;
		case S_IFDIR:
			printf("5\n");
            break;
		case S_IFCHR:
			printf("6\n");
			break;
		case S_IFIFO:
			printf("7\n");
			break;
		default:
			;
	}
	return 0;
}

