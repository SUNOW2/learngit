extern int shared;   /*shuo ming zai qi tai wen jian zhong ding yi */
int main()
{
	int a = 100;
	swap( &a,&shared );
}
