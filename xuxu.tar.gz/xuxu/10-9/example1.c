#include <stdio.h>
#include <stdlib.h>
int main(void)
{
	char buf1[50]= "SSSSSSSSSS";
	char buf2[50];
	FILE *stream1,*stream2,*stream3;
	int i;
	if((stream1 = fopen("file_1","w+")) == NULL)
	{
		fprintf(stderr,"Can't open the file!\n");
	    return 1;
	}
	for(i=0;i<sizeof(buf1);i++)
	{
	    if((fwrite(&buf1[i],sizeof(char),1,stream1))!=1)
		printf("write error!\n");
	}
   
	if((stream2 = fopen("file_2","w+")) == NULL)
	{
		fprintf(stderr,"Can't open the file!\n");
	    return 1;
	}
	rewind(stream1);
	for(i=0;!feof(stream1);i++)
	{
        fread(&buf2[i],sizeof(char),1,stream1);
	}
	for(i=0;i<sizeof(buf2);i++)
	{
        if((fwrite(&buf2[i],sizeof(char),1,stream2))!=1)
	    printf("write error!\n");
	}

    for(i=0;i<sizeof(buf2);i++)
	{
		buf2[i]=tolower(buf2[i]);
	}
	if((stream3 = fopen("file_3","w+")) == NULL)
	{
		fprintf(stderr,"Can't open the file!\n");
	}
    fwrite(buf2,sizeof(char),sizeof(buf2),stream3);
	fclose(stream1);
	fclose(stream2);
	fclose(stream3);
	system("cat file_1");
	printf("\n");
	system("cat file_2");
	printf("\n");
	system("cat file_3");
	printf("\n");
	return 0;
}
