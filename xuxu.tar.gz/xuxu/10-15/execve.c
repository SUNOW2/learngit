#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/wait.h>

int main(void)
{
	pid_t pid;
	int i,status;
	char *arrArg[] = {"exec", "A", "B", "C", NULL};
	char *arrEnv[] = {"envl=150", "env2=tom", NULL};
	pid = vfork();
	if (pid < 0)
	{
		printf("fail to fork yhe process!\n");
		exit(1);
	}
	else if (pid == 0)
	{
		execve ("./exec", arrArg, arrEnv);
	}
	else
	{
		if (pid != wait(&status))
		{
			printf("fail to wait the son process!\n");
			exit(1);
		}
		i = WIFEXITED(status);
		printf("i=%d\n",i);
	}
	return 0;
}
