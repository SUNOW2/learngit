#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>
#include <sys/wait.h>

int main()
{
	pid_t pid1,pid2;
	int b = 1;
	int a = 0;
	int status1,status2;
	printf("please choose 1 fork() or 2 vfork()\n");
	scanf("%d",&b);
	if(b == 1)
	{
	pid1 = fork();
	if(pid1 < 0)
	{
		perror("fail to fork!");
		exit(1);
	}
	else if(pid1 == 0)
	{
		printf("fork:child process!\n");
		printf("a = %d\n",++a);
	}
	else
	{
		printf("fork:parent process\n");
		if(wait(&status1) != pid1)
		{
			printf("fail to wait child process!\n");
		}
		printf("a = %d\n",++a);
	}
	}
	else
	{
	pid2 = vfork();
	if(pid2 < 0)
	{
		perror("fail to vfork!");
		exit(1);
	}
	else if(pid2 == 0)
	{
		printf("vfork:child process!\n");
		printf("a = %d\n",++a);
		exit(0);
	}
	else
	{
		printf("vfork:parent process\n");
		if(wait(&status2) != pid2)
		{
			printf("fail to wait child process!\n");
		}
		printf("a = %d\n",++a);
	}
	}
	return 0;
}
