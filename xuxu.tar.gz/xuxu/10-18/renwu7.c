#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
	int status;
	pid_t pid;
	pid = fork();
	if (pid < 0)
	{
		perror("fail to fork!");
		exit(1);
	}
	else if(pid == 0)
	{
	    printf("This is child process!\n");
		sleep(5);
		exit(0);
	}
	else
	{
		while(waitpid(pid,&status,WNOHANG) != pid)
		{
			printf("fail to wait the child process!\n");
			sleep(1);
		}
		if(WIFEXITED(status))
		{
			printf("common exit:%d\n",WEXITSTATUS(status));
		}
	}
	return 0;
}
