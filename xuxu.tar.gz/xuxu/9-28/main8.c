#include <stdio.h>
int addr(int *c,int *d)
{
	printf("%d+%d=%d",*c,*d,*c+*d);
}
int main(int argc,char *argv[])
{
	int a=atoi(argv[1]);
	int b=atoi(argv[2]);
	printf("%d+%d=%d\n",a,b,a+b);
	addr(&a,&b);
	return 0;
}
