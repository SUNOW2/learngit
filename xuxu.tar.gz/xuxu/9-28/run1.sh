#!/bin/bash
gcc main1.c -o main1
./main1
