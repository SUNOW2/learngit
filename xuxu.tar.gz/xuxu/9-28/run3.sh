#!/bin/bash
ld -static /usr/lib/x86_64-linux-gnu/ctr1.o /usr/lib/x86_64-linux-gnu/ctri.o /usr/lib/gcc/x86_64-linux-gnu/4.8.4/crtbeginT.o -L/usr/lib/gcc/x86_64-linux-gnu/4.8.4 -L/usr/lib -L/lib main4.o --start-group -lgcc_eh_-lc --end-group /usr/lib/gcc/x86_64-linux-gnu/4.8.4/crtend.o /usr/lib/x86_64-linux-gnu/crtn.0 -o main4
file main4
objdump -X main4
