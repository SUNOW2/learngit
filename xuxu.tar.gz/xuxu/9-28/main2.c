#include <stdio.h>
#define N "hello world!\n"
int main()
{
  	printf(N);
	return 0;
}
