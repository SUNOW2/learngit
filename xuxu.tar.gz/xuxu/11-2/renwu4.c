#include <stdio.h>
#include <stdlib.h>

#define LEN 6

int cmpfunc(const void *a, const void *b)
{
	return (*(int *)b - *(int *)a); 
}

int main(int argc, char *argv[])
{
	int i;
	int value[LEN];
	printf("请输入%d个整数! \n",LEN);
	for(i=0; i<LEN; i++)
	{
		scanf("%d",&value[i]);
	}
	printf("排序之前: \n");
	for(i=0; i<LEN; i++)
	{
		printf("%6d", value[i]);
	}
	printf("\n");
	qsort(value, LEN, sizeof(int), cmpfunc);
	printf("排序之后: \n");
	for(i=0; i<LEN; i++)
	{
		printf("%6d", value[i]);
	}
	printf("\n");
	return 0;
}
