#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>

int main(int argc, char *argv[])
{
	long i;
	char array[100];
	FILE *filp1,*filp2;
	if(argc != 3)
	{
		printf("参数错误! \n");
		exit(1);
	}

	filp1 = fopen(argv[1], "r");
	if(filp2 == NULL)
	{
		printf("打开文件错误! \n");
		exit(1);
	}

	filp2 = fopen(argv[2], "w+");
	if(filp2 == NULL)
	{
		printf("打开文件错误! \n");
		exit(1);
	}

    fseek(filp1, 0, SEEK_END);

	i = ftell(filp1);
	printf("文件指针位置为: \n");
	printf("%ld\n",i);

    fseek(filp1, 0, SEEK_SET);

	fread(array, sizeof(char), i, filp1);
	printf("文件%s中内容为: \n",argv[1]);
	printf("%s",array);  
	fwrite(array, sizeof(char), i, filp2);  /*方法一*/
	
//	fwrite(array, strlen(array), 1, filp2); /*方法二*/
	
//	fwrite(array, sizeof(array), 1, filp2);/*错误写法，数组中并没有存满，会有乱码*/
	printf("文件%s中内容为: \n",argv[2]);
	fclose(filp1);
	fclose(filp2);
	system("cat b.txt");
	return 0;
}
