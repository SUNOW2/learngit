#include <stdio.h>
#include <mcheck.h>
#include <string.h>
#include <stdlib.h>

#define SIZE 100
#define LEN 4
int main(int argc, char *argv[])
{
	mtrace();
	int i;
	char buf[SIZE];
	char **line = (char **)malloc(LEN*sizeof(char *));
	if(argc != 1)
	{
		printf("参数错误! \n");
		exit(1);
	}
	printf("请输入%d个字符串! \n",LEN);
	for(i=0; i<LEN;i++)
	{
		*(line+i) = (char *)malloc(SIZE * sizeof(char));
	    fgets(buf,SIZE,stdin);
	    strcpy(*(line+i), buf);
	}
	printf("输出: \n");
	for(i=0; i<LEN; i++)
	{
		printf("%s",line[i]);
	    free(line[i]);
	}
    free(line);
	return 0;
}
