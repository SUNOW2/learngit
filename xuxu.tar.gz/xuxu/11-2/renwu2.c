#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 256

int main(int argc, char *argv[])
{
	int i;
	char a[atoi(argv[1])][SIZE];
	if(argc != 2)
	{
		printf("参数错误! \n");
		exit(1);
	}
	printf("请输入%d个字符串: \n",atoi(argv[1]));
	for(i=0; i<atoi(argv[1]); i++)
	{
		fgets(a[i], SIZE, stdin);
	}
	printf("输出: \n");
	for(i=0; i<atoi(argv[1]); i++)
	{
		printf("%s", a[i]);
	}
	return 0;
}
