#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 100

int main(int argc, char *argv[])
{
	FILE *filp;
	char *line = NULL;
	size_t len = 0;
	ssize_t read;
	char array[SIZE] = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";

	filp = fopen(argv[1], "w+");
	if(filp == NULL)
	{
		printf("打开文件失败! \n");
		exit(EXIT_FAILURE);
	}
    fseek(filp, 0, SEEK_SET);
	fwrite(array, sizeof(char), atoi(argv[2]), filp);
	printf("输入文件的内容: %s\n", array);

    fseek(filp, 0, SEEK_SET);
    while((read = getline(&line, &len, filp)) != -1)
	{
		printf("读取到的长度: read = %zu\n", read);
		printf("自动分配的长度: len = %lu\n",len);
		printf("文件每行内容: %s\n", line);
	}
	free(line);
	fclose(filp);
}
