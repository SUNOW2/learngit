#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	char *line = NULL;
	size_t len = 0;
	ssize_t read;
	char c=':';
	char *strtemp;
	FILE *filp1,*filp2;
	if(argc != 2)
	{
		printf("参数错误! \n");
		exit(1);
	}

	filp1 = fopen("/etc/passwd", "r");
    if(filp1 == NULL)
	{
		printf("打开文件失败! \n");
		exit(1);
	}

	filp2 = fopen(argv[1], "w+");
    if(filp2 == NULL)
	{
		printf("打开文件失败! \n");
		exit(1);
	}
    while((read = getline(&line, &len, filp1)) != -1)
	{
		strtemp = strchr(line, c);
		if(strtemp != NULL)
		{
			fwrite(line,sizeof(char),strtemp-line+1,filp2);
		}
	}
	fclose(filp1);
	fclose(filp2);
	return 0;
}
