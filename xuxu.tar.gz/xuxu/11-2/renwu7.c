#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define SIZE 100
int cmpfunc(const void *a,const void *b)
{
	return strcmp(*(char **)a, *(char **)b);
}

int main(int argc, char *argv[])
{
	int i,a,l=0,j=1,n=5,k=0,p=0,b;
	int s1,s2;
	size_t len =0;
	ssize_t read;
	char *readline = NULL;
	char buf[SIZE];
    FILE *filp1,*filp2,*filp3;
	char **line1 = (char **)malloc(SIZE * sizeof(char *));
    char **line2 = (char **)malloc(SIZE * sizeof(char *));
    char **line3 = (char **)malloc(SIZE * sizeof(char *));
	if(argc != 3)
	{
		printf("参数错误! \n");
		exit(1);
	}

    filp1 = fopen(argv[1], "r");
    if(filp1 == NULL)
    {
    	printf("打开文件失败! \n");
    	exit(1);
    }

	fseek(filp1, 0 ,SEEK_SET);
	for(i=0; i<n;i++)
	{
		if((read = getline(&readline, &len, filp1)) != -1)
		{
            *(line1+i) = (char *)malloc(SIZE * sizeof(char));
	    	strcpy(*(line1+i), readline);
		}
	}

	printf("文件内容! \n");
	for(i=0; i<n; i++)
	{
		printf("%s",line1[i]);
	}
    
	qsort(line1, n, sizeof(line1[0]), cmpfunc);
for(i=1;i<n;i++)
{
	if(strcmp(line1[j-1], line1[i]) != 0)
	{
	    strcpy(line1[j++],line1[i]);
	}
	else
	{
	    p++;
	}
}

	printf("排序之后 : \n");
	qsort(line1, n-p, sizeof(line1[0]), cmpfunc);
	for(i=0; i<n-p; i++)
	{
		printf("%s",line1[i]);
	}

    filp2 = fopen(argv[2], "r");
    if(filp2 == NULL)
    {
    	printf("打开文件失败! \n");
    	exit(1);
    }

	fseek(filp2, 0 ,SEEK_SET);
	for(i=0; i<n;i++)
	{
		if((read = getline(&readline, &len, filp2)) != -1)
		{
            *(line2+i) = (char *)malloc(SIZE * sizeof(char));
	    	strcpy(*(line2+i), readline);
		}
	}

	printf("文件内容! \n");
	for(i=0; i<n; i++)
	{
		printf("%s",line2[i]);
	}

    j = 1;
	qsort(line2, n, sizeof(line2[0]), cmpfunc);
	for(i=1;i<n;i++)
	{
	   if(strcmp(line2[j-1], line2[i]) != 0)
	   {
	     	strcpy(line2[j++],line2[i]);
	   }
	   else
	   {
			 l++;
	   }
	}
    printf("l =%d\n",l);
	printf("排序之后 : \n");
	qsort(line2, n-l, sizeof(line2[0]), cmpfunc);
	for(i=0; i<n-l; i++)
	{
		printf("%s",line2[i]);
	}
	

	a = n-p;
	b = n-l;
	i=0;j=0;k=0;
    while(i<a && j<b)
	{
		if(strcmp(line1[i], line2[j]) < 0)
		{
			*(line3+k) = (char *)malloc(SIZE*sizeof(char));
			line3[k++] = line1[i];
			i++;
		}
		else if(strcmp(line1[i], line2[j]) > 0)
		{
			*(line3+k) = (char *)malloc(SIZE*sizeof(char));
			line3[k++] = line2[j];
			j++;
		}
		else
		{
			*(line3+k) = (char *)malloc(SIZE*sizeof(char));
			line3[k++] = line2[j];
			i++;
			j++;
		}
	}
	while(i < a)
	{
		*(line3+k) = (char *)malloc(SIZE*sizeof(char));
		line3[k++] = line1[i];
		i++;
	}
	while(j < b)
	{
        *(line3+k) = (char *)malloc(SIZE*sizeof(char));
		line3[k++] = line2[j];
		j++;
	}
    printf("文件%s和文件%s的并集为：\n",argv[1],argv[2]);
	for(i=0; i<k; i++)
	{
		printf("%s",line3[i]);
	}
    filp3 = fopen("./bing.txt","w+");
    if(filp3 == NULL)
    {
    	printf("打开文件失败!\n");
    	exit(1);
    }
//    fseek(filp3, 0 ,SEEK_SET);
	for(j=0; j<k; j++)
	{
       fwrite(line3[j], sizeof(char), sizeof(line3[j]), filp3);
	   free(line3[j]);
	}

	fclose(filp1);
	fclose(filp2);
	fclose(filp3);
	free(readline);
	free(line1);
	free(line2);
	free(line3);
	return 0;
}
