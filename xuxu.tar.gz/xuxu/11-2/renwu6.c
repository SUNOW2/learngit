#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define SIZE 100
int cmpfunc(const void *a,const void *b)
{
	return strcmp(*(char **)a, *(char **)b);
}

int main(int argc, char *argv[])
{
	int i,a,b=0,j=1,n=5;
	size_t len =0;
	ssize_t read;
	char *readline = NULL;
	char buf[SIZE];
    FILE *filp,*fp;
	char **line = (char **)malloc(SIZE * sizeof(char *));

	if(argc != 2)
	{
		printf("参数错误! \n");
		exit(1);
	}

    filp = fopen(argv[1], "r");
    if(filp == NULL)
    {
    	printf("打开文件失败! \n");
    	exit(1);
    }

	fseek(filp, 0 ,SEEK_SET);
	for(i=0; i<n;i++)
	{
		if((read = getline(&readline, &len, filp)) != -1)
		{
            *(line+i) = (char *)malloc(SIZE * sizeof(char));
	    	strcpy(*(line+i), readline);
		}
	}

	printf("文件内容! \n");
	for(i=0; i<n; i++)
	{
		printf("%s",line[i]);
	}
    
	printf("去除重复行并且排序之后: \n");

	qsort(line, n-b, sizeof(line[0]), cmpfunc);
	for(i=1;i<n;i++)
	{
	   if(strcmp(line[j-1], line[i]) != 0)
	   {
	     	strcpy(line[j++],line[i]);
	   }
	   else
	   {
			b++;
	   }
	}

	fp = fopen("./hello","w+");

	for(j=0; j<n-b; j++)
	{
		printf("%s",line[j]);
        fwrite(line[j], sizeof(char), sizeof(line[j]), fp);
	}

//	i = sizeof(line)/sizeof(line[0]);
//	printf("数组个数: %d\n", i);

	fclose(filp);
	fclose(fp);
	free(readline);
	free(line);
	return 0;
}
