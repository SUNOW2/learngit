#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define SIZE 100
int main(int argc, char *argv[])
{
	int i;
	size_t len =0;
	ssize_t read;
	char *readline = NULL;
	char buf[SIZE];
    FILE *filp;
	char **line = (char **)malloc(3*sizeof(char *));
    filp = fopen("./readme.txt", "r");
    if(filp == NULL)
    {
    	printf("打开文件失败! \n");
    	exit(1);
    }
	for(i=0; i<3;i++)
	{
		if((read = getline(&readline, &len, filp)) != -1)
		{
		    *(line+i) = (char *)malloc(SIZE * sizeof(int));
//	     	fgets(buf,SIZE,stdin);

	    	strcpy(*(line+i), readline);
		}
	}
	printf("输出: \n");
	for(i=0; i<3; i++)
	{
		printf("%s",line[i]);
	}
	free(*line);
	return 0;
}
