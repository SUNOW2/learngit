#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
	FILE *filp;
	char *line = NULL;
	size_t len = 0;
	ssize_t read;

	filp = fopen("./readme.txt", "r");
	if(filp == NULL)
	{
		printf("打开文件失败! \n");
		exit(EXIT_FAILURE);
	}
//    fseek(filp, 0, SEEK_SET);
    while((read = getline(&line, &len, filp)) != -1)
	{
		printf("每行长度: %zu\n", read);
		printf("文件内容: %s", line);
  //      fseek(filp, 0, SEEK_SET);
	}
	free(line);
	fclose(filp);
}
