#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define SIZE 100
char cmpfunc(const void *a,const void *b)
{
	return (*(char *)a - *(char *)b);
}
int main(int argc, char *argv[])
{
	int i,a,b=0,j=1,n=5;
	size_t len =0;
	ssize_t read;
	char *readline = NULL;
	char buf[SIZE];
    FILE *filp,*fp;
	char line[SIZE][SIZE];

    filp = fopen("./readme1.c", "r");
    if(filp == NULL)
    {
    	printf("打开文件失败! \n");
    	exit(1);
    }
	for(i=0; i<n;i++)
	{
		if((read = getline(&readline, &len, filp)) != -1)
		{

	    	strcpy(*(line+i), readline);
		}
	}
	qsort(line, 5, SIZE, cmpfunc);
	printf("文件内容! \n");
	for(i=0; i<n; i++)
	{
		printf("%s",line[i]);
	}
	printf("去除重复行之后: \n");
	for(i=1;i<n;i++)
	{
	   if(strcmp(line[j-1], line[i]) != 0)
	   {
	     	strcpy(line[j++],line[i]);
			b++;
	   }
	}
	fp = fopen("./hello","w+");
	for(j=0;j<5-b;j++)
	{
		printf("%s",line[j]);
        fwrite(line[j], sizeof(line[j]), 1, fp);
	}
	i = sizeof(line)/sizeof(line[0]);
	printf("数组个数: %d\n", i);
	fclose(filp);
	fclose(fp);
	free(readline);
	return 0;
}
