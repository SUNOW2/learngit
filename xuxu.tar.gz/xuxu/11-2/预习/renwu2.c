#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 256
int main(int argc, char *argv[])
{
	int i;
	char a[SIZE][SIZE];
	FILE *filp;
	char *line = NULL;
	size_t len = 0;
	ssize_t read;

	filp = fopen("./readme.txt", "r");
	if(filp == NULL)
	{
		printf("打开文件失败! \n");
		exit(EXIT_FAILURE);
	}

	for(i=0; i<3; i++)
	{
       if((read = getline(&line, &len, filp)) != -1)
	   {
		    strcpy(a[i], line);
//		    printf("%s",a[i]);
	   }
	}
	printf("文件内容: \n");
	for(i=0; i<3; i++)
	{
		printf("%s", a[i]);
	}
	free(line);
	fclose(filp);
	return 0;
}
