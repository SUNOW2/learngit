#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define SIZE 100
int main(int argc, char *argv[])
{
	int i,ret;
	size_t len =0;
	ssize_t read;
	char *readline = NULL;
	char buf[SIZE];
    FILE *filp;
	char **line = (char **)malloc(3*sizeof(char *));
    filp = fopen("./readme.txt", "r");
    if(filp == NULL)
    {
    	printf("打开文件失败! \n");
    	exit(1);
    }
	for(i=0; i<2;i++)
	{
		if((read = getline(&readline, &len, filp)) != -1)
		{
		    *(line+i) = (char *)malloc(SIZE * sizeof(int));

	    	strcpy(*(line+i), readline);
			ret = strlen(*(line+i))/sizeof(char) -1;
			printf("%s",*(line+i));
			*(*(line+i)+ret) = '\0';
		}
	}
	ret = strcmp(line[0],line[1]);
	if(ret > 0)
	{
		printf("%s比%s长! \n",line[0],line[1]);
	}
	else if(ret == 0)
	{
		printf("%s等于%s! \n",line[0],line[1]);
	}
	else
	{
		printf("%s比%s短! \n",line[0],line[1]);
	}

	free(*line);
	return 0;
}
