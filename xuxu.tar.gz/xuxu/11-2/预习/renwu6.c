#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	FILE *fp;
	char *line = NULL;
	size_t len = 0;
	fp = fopen("./", "r");
	if(fp == NULL)
	{
		printf("打开文件失败! \n");
		exit(EXIT_FAILURE);
	}

}
