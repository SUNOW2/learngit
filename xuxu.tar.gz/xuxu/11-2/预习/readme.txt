hello boy
hello girl
hello teacher
