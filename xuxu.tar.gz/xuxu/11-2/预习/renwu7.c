#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	
    int A[3] = {1,3,2};
    int B[3] = {1,9,0};
    int C[8];
	int i=0,j=0,k=0;
    while(i<3 && j<3)
	{
		if(A[i] < B[j])
		{
			C[k++] = A[i];
			i++;
		}
		else if(A[i] > B[j])
		{
			C[k++] = B[j];
			j++;
		}
		else
		{
			C[k++] = A[i];
			i++;
			j++;
		}
	}
//	printf("k=%d",k)i;
	while(i<3)
	{
		C[k++] = A[i];
		i++;
	}
	while(j<3)
	{
		C[k++] = B[j];
		j++;
	}
	for(i=0; i<k; i++)
	{
		printf("%d\n",C[i]);
	}
	return 0;
}
