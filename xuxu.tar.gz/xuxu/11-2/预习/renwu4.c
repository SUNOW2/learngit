#include <stdio.h>
#include <stdlib.h>

int value[5] = {88,56,100,2,25};

int cmpfunc(const void *a, const void *b)
{
	return (*(int *)a - *(int *)b); 
}

int main(int argc, char *argv[])
{
	int i;
	printf("排序之前: \n");
	for(i=0; i<5; i++)
	{
		printf("%6d", value[i]);
	}
	printf("\n");
	qsort(value, 5, sizeof(int), cmpfunc);
	printf("排序之后: \n");
	for(i=0; i<5; i++)
	{
		printf("%6d", value[i]);
	}
	printf("\n");
	return 0;
}
