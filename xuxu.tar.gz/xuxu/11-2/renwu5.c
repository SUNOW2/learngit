#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define SIZE 100
#define LEN 5

int cmpfunc(const void *a,const void *b)
{
	return strcmp(*(char **)a ,*(char **)b);
}
int main(int argc, char *argv[])
{
	int i;
	size_t len =0;
//	char buf[SIZE];
	ssize_t read;
	char *readline = NULL;
    FILE *filp;
	char **line = (char **)malloc(SIZE * sizeof(char *));

    filp = fopen(argv[1], "r");
    if(filp == NULL)
    {
    	printf("打开文件失败! \n");
    	exit(1);
    }

//	printf("请输入%d个字符串! \n", LEN);
//	fseek(filp, 0, SEEK_SET);
//	for(i=0; i<LEN; i++)
//	{
//		fgets(buf, SIZE, stdin);
//		scanf("%s",buf);
//		memset(buf,'0',SIZE);
//		fwrite(buf, sizeof(char), SIZE, filp);
//		printf("%s\n",buf);
//	}

	fseek(filp, 0, SEEK_SET);
	for(i=0; i<LEN ;i++)
	{
		if((read = getline(&readline, &len, filp)) != -1)
		{
            *(line +i) = (char *)malloc(SIZE * sizeof(char));
	    	strcpy(*(line+i), readline);
		}
	}

	printf("排序之前文件内容! \n");
	for(i=0; i<LEN; i++)
	{
		printf("%s",line[i]);
	}

	qsort(line, LEN, sizeof(line[0]), cmpfunc);
	printf("排序之后文件内容! \n");
	for(i=0; i<LEN; i++)
	{
		printf("%s",line[i]);
		free(line[i]);
	}

	fclose(filp);
	free(line);
	free(readline);
	return 0;
}
