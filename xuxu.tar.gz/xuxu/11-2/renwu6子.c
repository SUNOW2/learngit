#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define SIZE 100

int cmpfunc(const void *a,const void *b)
{
	return strcmp(*(char **)a, *(char **)b);
}

int fun(char array[SIZE], char **line, int *a)
{
	int i,b=0,j=1,n=6;
	size_t len =0;
	ssize_t read;
	char *readline = NULL;
	char buf[SIZE];
    FILE *filp;
	*line = (char *)malloc(SIZE * sizeof(char));


    filp = fopen(array, "r");
    if(filp == NULL)
    {
    	printf("打开文件失败! \n");
    	exit(1);
    }

	fseek(filp, 0 ,SEEK_SET);
	for(i=0; i<n; i++)
	{
		if((read = getline(&readline, &len, filp)) != -1)
		{
            *(line+i) = (char *)malloc(SIZE * sizeof(char));
	    	strcpy(*(line+i), readline);
		}
	}

	printf("文件内容! \n");
	for(i=0; i<n; i++)
	{
		printf("%s",line[i]);
	}
    
	printf("去除重复行并且排序之后: \n");

	qsort(line, n-b, sizeof(line[0]), cmpfunc);
	for(i=1;i<n;i++)
	{
	   if(strcmp(line[j-1], line[i]) != 0)
	   {
	     	strcpy(line[j++],line[i]);
	   }
	   else
	   {
			b++;
	   }
	}
	for(i=0; i<n-b; i++)
	{
		printf("%s",line[i]);
	}


	fclose(filp);
	free(readline);
//	free(line);
	return *a=(n-b);
}

int main(int argc, char *argv[])
{
	FILE *filp;
	int i=0,j=0,k=0;
	int a=0,b=0;
	char **fine1 = (char **)malloc(SIZE*sizeof(char *));
	char **fine2 = (char **)malloc(SIZE*sizeof(char *));
	char **fine3 = (char **)malloc(SIZE*sizeof(char *));
	if(argc != 3) 
	{
		printf("参数错误! \n");
		exit(1);
	}
	a = fun(argv[1],fine1,&a);
	b = fun(argv[2],fine2,&b);
	printf("*********************************************\n");
	for(i=0; i<a; i++)
	{
//		fine1[i] = (char *)malloc(SIZE*sizeof(char));
		printf("%s",fine1[i]);
	}
	printf("*********************************************\n");
	for(i=0; i<b; i++)
	{
//		fine1[i] = (char *)malloc(SIZE*sizeof(char));
		printf("%s",fine2[i]);
	}
	printf("a=%d,b=%d\n",a,b);
	i=0,j=0;
    while(i<a&&j<b)
	{
    	if(strcmp(fine1[i],fine2[j]) < 0)
		{
			*(fine3+k) = (char *)malloc(SIZE*sizeof(char));
            fine3[k++] = fine1[i];
			i++;
		}
		else if(strcmp(fine1[i],fine2[j]) > 0)
		{
		   *(fine3+k) = (char *)malloc(SIZE*sizeof(char));
           fine3[k++] = fine2[j];
		   j++;
		}
		else
		{
		   *(fine3+k) = (char *)malloc(SIZE*sizeof(char));
		   fine3[k++] = fine1[i];
		   i++;
		   j++;
		}
	}
	while(i<a)
	{
		*(fine3+k) = (char *)malloc(SIZE*sizeof(char));
        fine3[k++] = fine1[i];
		i++;
	}
	while(j<b)
	{
		*(fine3+k) = (char *)malloc(SIZE*sizeof(char));
        fine3[k++] = fine2[j];
		j++;
	}
	printf("文件%s和文件%s的并集是：\n",argv[1],argv[2]);
	for(i=0; i<k; i++)
	{
		printf("%s",fine3[i]);
	}
    filp = fopen("./bing","w+");
	fseek(filp,0,SEEK_SET);
	for(i=0; i<k; i++)
	{
		fwrite(fine3[i],sizeof(char),strlen(fine3[i]),filp);
		free(fine3[i]);
	}
	fclose(filp);
	free(fine3);
	free(fine1);
	free(fine2);
	return 0;
}
