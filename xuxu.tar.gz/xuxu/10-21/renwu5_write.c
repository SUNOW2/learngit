#include <sys/types.h>
#include <stdio.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#define SIZE 256 

int main(int argc,char *argv[])
{
	int fd;
	int sta;
	char buffer[SIZE];
//	sta = mkfifo(argv[1],0777);
	sta = mkfifo("./FIFO",0777);
	if(sta < 0)
	{
		printf("mkfifo error!\n");
		exit(1);
	}
//	fd = open(argv[1], O_RDWR);
    fd = open("./FIFO", O_RDWR);
	if(fd < 0)
	{
		printf("open error!\n");
		exit(1);
	}

	printf("Send messages!\n");
	fgets(buffer, sizeof(buffer), stdin);
	write(fd, buffer, sizeof(buffer));
//    unlink(argv[1]);
	unlink("./FIFO");
	return 0;
}
