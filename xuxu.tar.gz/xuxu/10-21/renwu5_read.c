#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>

#define SIZE 256
int main(int argc,char *argv[])
{
	int fd;
	int num;
	char buffer[SIZE];

//	fd = open(argv[1], O_RDWR);
	fd = open("./FIFO", O_RDWR);
	if(fd < 0)
	{
		printf("open error!\n");
		exit(1);
	}
	printf("Receive messages!\n");
	num = read(fd, buffer, sizeof(buffer));
	if(num == -1)
	{
		printf("read error!\n");
		exit(1);
	}
	printf("%s",buffer);
	return 0;
}
