#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>

#define SIZE 512

struct msgbuf
{
	long mtype;
	char mtext[SIZE];
};
int main(int argc, char *argv[])
{
	key_t key;
	int msgid;
	int res;
	struct msgbuf buffer;
	key = ftok("./",123);
	if(key < 0)
	{
		printf("ftok error!\n");
		exit(EXIT_FAILURE);
	}
	msgid = msgget(key, IPC_CREAT | 0666);
	if(msgid == -1)
	{
		printf("msgget error!\n");
		exit(EXIT_FAILURE);
	}
	while(1)
	{
		printf("please input some characters!\n");
		fgets(buffer.mtext,SIZE,stdin);
		buffer.mtype = getpid();
        if(msgsnd(msgid,&buffer,SIZE,0)<0)
		{
			 printf("msgsnd error!\n");
			 exit(1);
		}
		if(strncmp(buffer.mtext,"end",3) == 0)
			break;
	}
	return 0;
}
