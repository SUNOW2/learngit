#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#define SHM_SIZE 2048
#define BUFSIZE 512
int main(int argc,char *argv[])
{
	pid_t pid;
	key_t key;
	int shmid;
//	char buffer[BUFSIZE];
	int res;
	char *psm;
	struct shmid_ds dsbuf;
	key = ftok("/home/sunow1",100);
	if(key < 0)
	{
		printf("ftok error!\n");
		exit(EXIT_FAILURE);
	}
	shmid = shmget(key, SHM_SIZE, IPC_CREAT | 0666);
	if(shmid < 0)
	{
		printf("shmget error!\n");
		exit(EXIT_FAILURE);
	}
	printf("shmid = %d\n",shmid);
	pid = fork();
	if(pid < 0)
	{
		printf("fork error!\n");
		exit(EXIT_FAILURE);
	}
	else if(pid == 0)
	{
		printf("This is Child process!pid = %d\n",getpid());
        psm = (char *)shmat(shmid, NULL, 0);
		if((int)psm == -1)
		{
			printf("shmat error!\n");
			exit(EXIT_FAILURE);
		}
//		printf("please input some chars!\n");
//		fgets(buffer, BUFSIZE, stdin);
//      strcpy((char *)psm, buffer);
		strcpy(psm, argv[1]);
//		printf("******%s\n",buffer);
		printf("Send message!%s\n",psm);
		res = shmdt(psm);
		if(res == -1)
		{
			printf("shmdt error!\n");
			exit(EXIT_FAILURE);
		}
//		sleep(3);
	}
	else
	{
        sleep(3);
		printf("This is Parent process!pid = %d\n",getpid());
        res = shmctl(shmid, IPC_STAT, &dsbuf);
		if(res < 0)
		{
			printf("shmctl error!\n");
			exit(EXIT_FAILURE);
		}
		printf("MemorySize = %d\n",dsbuf.shm_segsz);
		psm = (char *)shmat(shmid, NULL, 0);
		if((int)psm == -1)
		{
			printf("shmat error!\n");
			exit(EXIT_FAILURE);
		}
		printf("Receive some chars:%s\n",psm);
		res = shmdt(psm);
		if(res == -1)
		{
			printf("shmdt error!\n");
			exit(EXIT_FAILURE);
		}
        res = shmctl(shmid, IPC_RMID, NULL);
		if(res < 0)
		{
			printf("shmtcl error\n");
			exit(EXIT_FAILURE);
		}
	}
    return 0;
}
