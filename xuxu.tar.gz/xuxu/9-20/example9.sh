#!/bin/bash
touch file
for file in `ls`
do
  a=ls -l $file | awk '{print $5}'
  cat $a > file
done
while [ ]
