#a simple if loop
awk '(if($1==0){printf "This cell has a value of zero"}else {printf "The value is %dn",$1})'
