/bin/a.b
/sbin/c.d
/usr/bin/e.f
/usr/sbin/g.h
/usr/local/bin/i.j
