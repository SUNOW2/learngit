#!/bin/bash
#example6.c
#to test the method of while

COUNTER=0
while [ $COUNTER -lt 5 ]
do
  echo $COUNTER
  COUNTER=`expr $COUNTER + 1`
done
