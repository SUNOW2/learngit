#!/bin/bash
ifconfig eth0 | awk -F: -v 'OFS=**' '{print $1,$2}'
