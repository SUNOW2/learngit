#include <stdio.h>
void fun(int s[],int l,int r)
{
		 int i,j,k;
		 if(l<r)
		 {
				  i=l;
				  j=r;
				  k=s[i];
				  while(i<j)
				  {
						   while(i<j&&s[j]>k)
								   j--;
						   if(i<j)
								   s[i++]=s[j];
						   while(i<j&&s[i]<k)
								   i++;
						   if(i<j)
								   s[j--]=s[i];
				  }
				  s[i] = k;
				  fun(s,l,i-1);
				  fun(s,i+1,r);
		 }
}
int main()
{
		 int a[]={65,43,79,21,298,12,3,54,44,1};
		 int l=0;
		 int r=9;
		 int i;
         fun(a,l,r);
				 for(i=0;i<10;i++)
						 printf("%4d",a[i]);
		 printf("\n");
		 return 0;
}
