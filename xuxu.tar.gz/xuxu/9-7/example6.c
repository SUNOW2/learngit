#include <stdio.h>
#include <signal.h>
#include <execinfo.h>
#include <stdlib.h>
void sigdump(int s)
{
		 void *array[10];
		 size_t size;
		 char **strings;
		 size_t i;
		 size = backtrace (array,10);
		 strings = backtrace_sysbols (array,size);
		 for(i=0;i<size;i++)
		 {
				  printf("%s",strings[i]);
		 }
		 free(strings);
		 exit(0);
}

int func()
{
		 int i;
		 char *p=NULL;
		 i++;
		 strcpy(p,"123");
		 printf("i=%d\n,p=%s\n",i,p);
		 return 0;
}
void main()
{
		 signal(SIGSEGV,(__sighandler_t)sigdump);
}
