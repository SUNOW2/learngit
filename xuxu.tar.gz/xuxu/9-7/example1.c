/* exampe1.c */
void bounds1(void)
{
		 int a[10];
		 a[10] = 0;
		 return;
}
