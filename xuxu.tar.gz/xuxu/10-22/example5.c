#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <error.h>
#include <string.h>
#include <fcntl.h>

#define NAME_SIZE 10
#define STUDENT_SIZE 32

struct student
{
	unsigned int id;
	char name[NAME_SIZE];
};


int main(int argc, char *argv[])
{
	int i;
	int len;
	int fd;
	int id;
	char name[NAME_SIZE]={"0"};
	struct student stu;
//	struct student stu1;
    if(argc != 1)
	{
		perror("too many arguments!");
		exit(EXIT_FAILURE);
	}
	fd = open("xuesheng.txt",O_CREAT | O_RDWR, 0666);
	if(fd == -1)
	{
		printf("fail to open the file!\n");
		exit(EXIT_FAILURE);
	}
	lseek(fd, 0, SEEK_SET);
	printf("please input student information!\n");
    for(i=0; i<STUDENT_SIZE; i++)
	{
		printf("id:\n");
		scanf("%d",&id);
		if(id < 0)
		{
			printf("false id\n");
			break;
		}
		else
		{
			printf("name:\n");
//			fgets(name, NAME_SIZE, stdin);
        	scanf("%s",name);
			printf("%s",name);
	    	len = strlen(name);
			printf("len =%d\n",len);
     		name[len] = '\0';
			stu.id = id;
			bzero(stu.name,NAME_SIZE);
			strcpy(stu.name, name);
			lseek(fd, id*sizeof(stu), SEEK_SET); //按照id号排列
			write(fd, (char *)&stu, sizeof(unsigned int)+len);
			fflush(stdin);
			system("cat xuesheng.txt");
	    	printf("\n");
		}
	}
    close(fd);
	return 0;
}
