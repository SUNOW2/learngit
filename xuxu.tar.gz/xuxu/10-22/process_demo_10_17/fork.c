#include <stdio.h>
#include <unistd.h>

int global_a = 10;

int main(void)
{
	pid_t pid;

	printf("before fork! global_a = %d  \n", 
			global_a);	
	pid = fork();
	
	if (pid < 0) {
		printf("error! \n");
		return -1;
	} else if (pid == 0) {
	/*child process*/
		printf("in child process! pid = %d ;ppid =%d \n", 
				getpid(), getppid());
		global_a++;
		printf("child:global_a = %d \n", global_a);
	} else {
	/*parent process*/
		printf("in parent process! pid = %d ;ppid =%d \n", 
				getpid(), getppid());
		printf("parent:global_a = %d \n", global_a);
		sleep(3);
	}
	printf("after fork! \n");	
}
