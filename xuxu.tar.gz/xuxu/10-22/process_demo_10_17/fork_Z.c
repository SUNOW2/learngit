/*create a zombie process*/

#include <stdio.h>
#include <sys/types.h>


int main(int argc, const char *argv[])
{
	pid_t pid;
	
	printf("before fork!  \n");
	

	/*创建一个子进程*/
	if((pid = fork()) == -1) {
		perror("fork");
		return 1;
	} else if (pid == 0) {
		printf("In child process. getpid = %d getppid = %d \n",
				getpid(), getppid());
	} else {
		sleep(20);
		printf("parent process. child pid = %d. getpid = %d \n",
				pid, getpid());
	}

	return 0;
}
