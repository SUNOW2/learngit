
#include <sys/wait.h>
#include <stdio.h>
#include <sys/types.h>


int main(int argc, const char *argv[])
{
	pid_t pid;
	
	printf("before fork! \n");

	/*创建一个子进程*/
	if((pid = fork()) == -1) {
		perror("fork");
		return 1;
	} else if (pid == 0) {
		/*子进程*/
		printf("In child process. getpid = %d getppid = %d \n",
				getpid(), getppid());
		sleep(2);
		printf("child process over!\n");
		return 5;
	} else {
		/*父进程*/
		pid_t w_pid;
		int status;
		printf("parent process. child pid = %d. getpid = %d \n",
				pid, getpid());
		/*父进程等待子进程结束，收尸,  等待过程，父进程阻塞*/
		//w_pid = wait(NULL);
		//接收子进程退出状态
		w_pid = wait(&status);
		//WIFEXITED 返回真表示子进程正常退出（遇到exit _exit return）
		if (WIFEXITED(status)) {
			//WEXITSTATUS 此宏返回退出码
			printf("parent process :child[%d] is exit. exit status is %d \n",
					w_pid, WEXITSTATUS(status));
		}
		sleep(20);
	
	}

	return 0;
}
