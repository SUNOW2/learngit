#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>

int main(int argc, char *argv[])
{
	int res;
	FILE *fp;
	fp = fopen("example","r");
	fseek(fp,3,SEEK_END);
	res = ftell(fp);
	printf("res = %d",res);
	fclose(fp);
	return 0;
}
