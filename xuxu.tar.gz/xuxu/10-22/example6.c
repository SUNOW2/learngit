#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <error.h>
#include <string.h>
#include <fcntl.h>

#define NAME_SIZE 100
#define STUDENT_SIZE 32

struct student
{
	unsigned int id;
	char name[NAME_SIZE];
};


int main(int argc, char *argv[])
{
	int i;
	int len;
	int fd;
	int id;
	char name[1000];
	struct student stu;
	printf("RGSHHHHHHHHHHHi\n");
	fgets(name, 1000, stdin);
    if(argc != 1)
	{
		perror("too many arguments!");
		exit(EXIT_FAILURE);
	}
	fd = open("xuesheng.txt",O_CREAT | O_RDWR, 0666);
	if(fd == -1)
	{
		printf("fail to open the file!\n");
		exit(EXIT_FAILURE);
	}
	lseek(fd, 0, SEEK_SET);
	printf("please input student information!\n");
    for(i=0; i<STUDENT_SIZE; i++)
	{
		printf("id:\n");
		scanf("%d",&id);
		if(id < 0)
		{
			printf("false id\n");
			break;
		}
		else
		{
//			bzero(stu.name,NAME_SIZE);
			printf("name:\n");
//			scanf("%s",stu.name);
//			fgets(stu.name, 100, stdin);
	fgets(name, 1000, stdin);
			len = strlen(stu.name);
			printf("len =%d\n",len);
			stu.name[len] = '\0';
			stu.id = id;
			lseek(fd, id*sizeof(stu), SEEK_SET); //按照id号排列
			write(fd, (char *)&stu, sizeof(struct student));
			fflush(stdin);
			system("cat xuesheng.txt");
			printf("\n");
		}
	}
    close(fd);
	return 0;
}
