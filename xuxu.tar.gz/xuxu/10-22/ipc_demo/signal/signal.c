#include <stdio.h>
#include <sys/types.h>
#include <stdlib.h>
#include <signal.h>

void  my_hander(int signo)
{
	if (signo == SIGQUIT)
		printf("got SIGQUIT\n");
	//signal(SIGQUIT, SIG_IGN);
}

int main(int argc, const char *argv[])
{
	
	int count;
	count = 0;
	signal(SIGQUIT, my_hander);
	while (1) {
		printf("count = %d \n", count);
		sleep(1);
		count++;
	}
	return 0;
}
