#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <string.h>

#define PATH_NAME "./"
#define PRO_ID 100
#define SHM_SIZE 4096

int main(int argc, const char *argv[])
{
	int shmid;
	void *shm_addr;
	pid_t pid;
#if 1
	/*生成一个IPC key*/
	key_t key1;
	if ((key1 = ftok(PATH_NAME, PRO_ID)) == -1) {
		perror("ftok");
		exit(EXIT_FAILURE);
	}
	printf("child: key1 = %#x \n", key1);
#endif
	/*
	 *通过IPC key，让内核创建一个共享内存(IPC_CREAT)，返回此共享内存的ID
	 *如果此key对应的共享内存已经存在，返回此共享内存的ID
	 */
	shmid = shmget(IPC_PRIVATE, SHM_SIZE, IPC_CREAT | 0666);
	if (shmid == -1) {
		perror("shmget");
		exit(EXIT_FAILURE);
	}


	if ((pid = fork()) == -1) {
		perror("fork");
		exit(EXIT_FAILURE);
	} else if (pid == 0) {
		/*子进程*/	
		char *buf;
		/*将共享内容映射到进程用户地址空间*/
		if ((shm_addr = shmat(shmid, NULL, 0)) == (void *)-1) {
			perror("shmat");
			exit(EXIT_FAILURE);
		}
		buf = (char *)shm_addr;
		/*访问共享内存*/
		strncpy(buf, "hello jit\n", 20);
		buf[20] = '\0';
		printf("buf = %s",buf);
		/*取消进程和共享内存的关联*/
		if (shmdt(shm_addr) == -1) {
			perror("shmdt");
		}

	} else {
		/*父进程*/
		char *buf;
		/*将共享内容映射到进程用户地址空间*/
		if ((shm_addr = shmat(shmid, NULL, 0)) == (void *)-1) {
			perror("shmat");
			exit(EXIT_FAILURE);
		}
		buf = (char *)shm_addr;
		sleep(1);
		printf("buf = %s", buf);
		/*取消进程和共享内存的关联*/
		if (shmdt(shm_addr) == -1) {
			perror("shmdt");
		}
		wait(NULL);
		/*共享内存控制：IPC_RMID,删除此共享内存*/
		if (shmctl(shmid, IPC_RMID, NULL) == -1) {
			perror("shmctl");
		}
	}


	return 0;
}
