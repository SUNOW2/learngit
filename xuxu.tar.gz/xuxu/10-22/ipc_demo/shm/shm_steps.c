#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <string.h>

#define PATH_NAME "./"
#define PRO_ID 100
#define SHM_SIZE 4096

int main(int argc, const char *argv[])
{
	int shmid;
	void *shm_addr;

	/*生成一个IPC key*/
	key_t key1;
	if ((key1 = ftok(PATH_NAME, PRO_ID)) == -1) {
		perror("ftok");
		exit(EXIT_FAILURE);
	}
	printf("child: key1 = %#x \n", key1);

	/*
	 *通过IPC key，让内核创建一个共享内存(IPC_CREAT)，返回此共享内存的ID
	 *如果此key对应的共享内存已经存在，返回此共享内存的ID
	 */
	shmid = shmget(key1, SHM_SIZE, IPC_CREAT | 0666);
	if (shmid == -1) {
		perror("shmget");
		exit(EXIT_FAILURE);
	}
	printf("child: shmid = %d \n", shmid);
	printf("********after shmget**********\n");
	system("ipcs -m | grep 666");
	
	/*将共享内容映射到进程用户地址空间*/
	if ((shm_addr = shmat(shmid, NULL, 0)) == (void *)-1) {
		perror("shmat");
		exit(EXIT_FAILURE);
	}
	printf("********after shmat**********\n");
	system("ipcs -m | grep 666");

	/*访问共享内存*/
	strncpy(shm_addr, "hello jit\n", 20);

	/*取消进程和共享内存的关联*/
	if (shmdt(shm_addr) == -1) {
		perror("shmdt");
	}
	printf("********after shmdt**********\n");
	system("ipcs -m | grep 666");

	/*共享内存控制：IPC_RMID,删除此共享内存*/
	if (shmctl(shmid, IPC_RMID, NULL) == -1) {
		perror("shmctl");
	}
	printf("********after shmctl(IPC_RMID)**********\n");
	system("ipcs -m | grep 666");
	return 0;
}
