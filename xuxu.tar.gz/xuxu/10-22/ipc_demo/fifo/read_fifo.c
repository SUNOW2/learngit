#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <string.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

#define READ_SIZE 256

int main(int argc, const char *argv[])
{
	int fd;
	char buf[READ_SIZE+1];
	int n;

	if ((mkfifo("./myfifo", 0664) && errno != EEXIST) == -1) {
		perror("mkfifo");
		exit(EXIT_FAILURE);
	}
	
	if ((fd = open("./myfifo", O_RDONLY)) == -1) {
		perror("open");			
		exit(EXIT_FAILURE);
	}
	printf("read: open success! \n");

	while (1) {
		memset(buf, 0x00, READ_SIZE+1);
		n = read(fd, buf, READ_SIZE);
		buf[n] = '\0';
		printf("Read: read %d bytes: %s \n", n, buf);
		if (n == 0) {
			break;
		}
	}
	return 0;
}
