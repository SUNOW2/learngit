#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/msg.h>
#include <sys/ipc.h>
#include <fcntl.h>

#define SIZE 128
#define LUJING "/home/sunow1"
#define LUJING_ID 123
struct msg_buf
{
	long mtype;
	char buf[SIZE];
};
int main()
{
    key_t key;
	int msgid;
	struct msg_buf buffer;
	key = ftok(LUJING,LUJING_ID);
	if(key < 0)
	{
		printf("ftok error!\n");
		exit(1);
	}

	msgid = msgget(key, IPC_CREAT | 0666);
	if(msgget < 0)
	{
		printf("msgget error!\n");
		exit(EXIT_FAILURE);
	}
	printf("please input some chars: \n");

	fgets(buffer.buf, SIZE, stdin);
	buffer.mtype = getpid();
	printf("Send: %s\n",buffer.buf);
	if(msgsnd(msgid, &buffer, SIZE, 0 ) == -1)
	{
		printf("msgsnd error!\n");
		exit(1);
	}
	if(msgctl(msgid, IPC_RMID, 0) < 0)
	{
		printf("msgctl error!\n");
		exit(EXIT_FAILURE);
	}
	exit(EXIT_SUCCESS);
}
