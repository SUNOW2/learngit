#include <stdio.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <stdlib.h>
#include <fcntl.h>

#define PATH_NAME "/home/linux"
#define PRO_ID 200

#define WRITER_ID 321

#define MSG_SIZE 256
struct msg_buf {
	long mtype; 
	char buf[MSG_SIZE]; 
};

void main(int argc, const char *argv[])
{
	key_t key;
	int msg_id;
	struct msg_buf my_buf;

	key = ftok(PATH_NAME, PRO_ID);

	msg_id = msgget(key, IPC_CREAT | 0666);
	if (msg_id < 0) {
		perror("msgget");
		exit(EXIT_FAILURE);
	}
	
	my_buf.mtype = WRITER_ID;
	printf("write: ");
	fgets(my_buf.buf, MSG_SIZE, stdin);
	if(msgsnd(msg_id, &my_buf, sizeof(struct msg_buf)- sizeof(long),
		   0) < 0) {
		perror("msgrcv");
		exit(EXIT_FAILURE);
	}

	if (msgctl(msg_id, IPC_RMID, 0) < 0) {
		perror("msgctl");
		exit(EXIT_FAILURE);
	}
	
	exit(EXIT_SUCCESS);

}
