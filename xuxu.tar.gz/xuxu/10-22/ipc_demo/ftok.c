#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <stdlib.h>

#define PATH_NAME "/home/sunow1"
#define PRO_ID 100

int main(int argc, const char *argv[])
{
	pid_t pid;

	pid = fork();

	if (pid == 0) {
		key_t key1;
		if ((key1 = ftok(PATH_NAME, PRO_ID)) == -1) {
			perror("ftok");
			exit(EXIT_FAILURE);
		}
		printf("child: key1 = %#x \n", key1);
		printf("child: other key = %#x, \n", ftok("/home/linux",100));
		printf("child: another key = %#x, \n", ftok("/home/linux",101));
	} else {
		/*parent process*/
		key_t key2;
		if ((key2 = ftok(PATH_NAME, PRO_ID)) == -1) {
			perror("ftok");
			exit(EXIT_FAILURE);
		}
		printf("parent: key2 = %#x \n", key2);
		wait(NULL);
	}
	return 0;
}
