#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <error.h>
#include <sys/types.h>

int main(int argc, char *argv[])
{
	int res;
	if(argc != 1)
	{
		perror("too few arguments!");
		exit(EXIT_FAILURE);
	}

	res = mkdir("/home/sunow1/xuxu/boy", S_IRUSR | S_IWUSR | S_IXGRP | S_IROTH);
	if(res == -1)
	{
		printf("fail to mkdir!\n");
		exit(EXIT_FAILURE);
	}
	printf("Finish!\n");
	return 0;
}
