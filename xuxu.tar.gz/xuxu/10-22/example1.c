#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>

int main(int argc, char *argv[])
{
	int fd;
	int res;
	fd = open("./example",O_RDONLY);
	res = lseek(fd,3,SEEK_END);
	printf("res = %d",res);
	close(fd);
	return 0;
}
