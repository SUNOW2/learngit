#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#define _LOCK
#ifdef _LOCK
pthread_mutex_t  lock;
#endif

void *pthread_function0(void *arg)
{
	
	int i = 0;
#ifdef _LOCK
	pthread_mutex_lock(&lock);
#endif
	while (i < 6) {
		printf("AAAAAAAAAAAAAAA\n");
		usleep(1);
		i++;
	}
#ifdef _LOCK
	pthread_mutex_unlock(&lock);
#endif
	pthread_exit(NULL);
}

void *pthread_function1(void *arg)
{
	int i = 0;
	/* do sth ... */
#ifdef _LOCK
	pthread_mutex_lock(&lock);
#endif
	while (i < 6) {
		printf("BBBBBBBBBBBBBBB\n");
		usleep(1);
		i++;
	}
#ifdef _LOCK
	pthread_mutex_unlock(&lock);
#endif
	pthread_exit(NULL);
}

int main()
{
	pthread_t	tid0, tid1;
	void		*retval;
#ifdef _LOCK
	pthread_mutex_init(&lock, NULL);
#endif

	/* create thread 0 */
	if (pthread_create(&tid0, NULL, pthread_function0, NULL) != 0) {
		perror("main: pthread_create thread0 failed ");
		exit(EXIT_FAILURE);
	}
	else {
		printf("main: pthread_create thread0[%lu] succeed!\n", tid0);
	}
	/* create thread 1 */
	if (pthread_create(&tid1, NULL, pthread_function1, NULL) != 0) {
		perror("main: pthread_create thread1 failed ");
		exit(EXIT_FAILURE);
	}
	else {
		printf("main: pthread_create thread1[%lu] succeed!\n", tid1);
	}

	if (pthread_join(tid0, NULL) != 0) {
		perror("main: pthread_join thread0 failed");
		exit(EXIT_FAILURE);
	}
	printf("main: pthread_join thread0[%lu] succeed.\n",
		tid0);

	/* wait and join threads */
	if (pthread_join(tid1, NULL) != 0) {
		perror("main: pthread_join thread1 failed");
		exit(EXIT_FAILURE);
	}	
	printf("main: pthread_join thread1[%lu] succeed.\n",tid1);
	
	
	return 0;
}
