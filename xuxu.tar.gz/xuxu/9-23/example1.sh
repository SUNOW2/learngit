echo "hello world!"
echo 'hello!'
