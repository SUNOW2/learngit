int main()
{
		 printf("please input!");
		 return 0;
}
