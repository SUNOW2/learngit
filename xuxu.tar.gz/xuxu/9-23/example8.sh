#!/bin/bash
mkdir ~/xuxu/hello12
a=$(du * | awk '{if($1<10k) print $2}')
for file in $a
do 
  cp $file ~/xuxu/hello12
done
