#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	FILE *filp;
	filp = fopen("./file","w");
	if(filp == NULL)
	{
		printf("打开文件失败!\n");
		exit(1);
	}
	printf("打开文件成功!\n");
	fclose(filp);
	return 0;
}
