#include <stdio.h>
#include <stdlib.h>

#define SIZE 256

int main(int argc, char *argv[])
{
	char buf[SIZE];
	FILE *filp1,*filp2;
	filp1 = fopen(argv[1], "r");
	if(filp1 == NULL)
	{
		printf("打开文件1失败! \n");
		exit(1);
	}
	filp2 = fopen(argv[2], "w+");
	if(filp2 == NULL)
	{
        printf("打开文件2失败! \n");
		exit(1);
	}
	while(fgets(buf, SIZE, filp1) != NULL)
	{
		fputs(buf, filp2);
	}
	fclose(filp1);
	fclose(filp2);
/*	printf("argv[1] = %s\n",argv[1]);
	system("cat argv[1]");
	system("cat argv[2]");*/
	return 0;
}
