#include <stdio.h>
#include <stdlib.h>

#define SIZE 3

struct student
{
	int id;
	int score;
};

int main(int argc, char *argv[])
{
	struct student array[SIZE];
	int i, sum;
	FILE *filp;
	filp = fopen("./file4", "w+");
	if(filp == NULL)
	{
		printf("打开文件失败! \n");
		exit(1);
	}
	printf("打开文件成功!\n");
	for(i=0; i<SIZE; i++)
	{
		printf("请输入学号: \n");
		scanf("%d",&array[i].id);
		printf("请输入分数: \n");
		scanf("%d",&array[i].score);
	}
	sum = fwrite(array, sizeof(struct student), SIZE, filp);
	if(sum != SIZE)
	{
		printf("写入文件失败! \n");
		exit(1);
	}
	fclose(filp);
	return 0;
}
