#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	FILE *filp;
	int i, text, pos;
	filp = fopen("./file2","r+");
	if(filp == NULL)
	{
		printf("打开文件失败!\n");
		exit(1);
	}
	printf("打开文件成功！\n");
	for(i=0; i<8; i=i+2)
	{
		fseek(filp, i, SEEK_SET);
		pos = ftell(filp);
		printf("当前读写位置: %d\n",pos+1);
        text = fgetc(filp);
		printf("字符为: \n");
		putchar(text);
		printf("\n");
	}
	fclose(filp);
	return 0;
}
