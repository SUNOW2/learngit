#include <stdio.h>
#include <stdlib.h>

#define SIZE 256

int main(int argc, char *argv[])
{
	int j=0;
	char buf[SIZE];
	FILE *filp;
	if(argc != 2)
	{
		printf("too few arguments!\n");
		exit(1);
	}
	if((filp = fopen(argv[1], "r")) == NULL)
	{
		printf("打开文件失败: \n");
		exit(1);
	}
	printf("打开文件成功!\n");
	while(fgets(buf, SIZE, filp) != NULL)
	{
    	printf("%d: %s",j++,buf);
	}
	fclose(filp);
	return 0;
}
