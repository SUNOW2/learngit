#include <stdio.h>
#include <stdlib.h>

#define SIZE 3
struct student 
{
	int id;
	int score;
};

int main(int argc, char *argv[])
{
	int i;
	int res;
	struct student stu[SIZE];
	FILE *filp;
	filp = fopen("./file4", "r");
	if(filp == NULL)
	{
		printf("打开文件失败! \n");
		exit(1);
	}
    res = fread(stu, sizeof(struct student), SIZE, filp);
	if(res != SIZE)
	{
		if(!feof(filp))
		{
			printf("已到文件末尾! \n");
		}
		else
		{
			printf("读取文件失败! \n");
		}
	}
	printf("ID\tScore\n");
	for(i=0; i<SIZE; i++)
	{
		printf("%d\t%d\n",stu[i].id,stu[i].score);
	}
	fclose(filp);
	return 0;
}
