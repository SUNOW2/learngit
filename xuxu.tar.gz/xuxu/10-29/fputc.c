#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	FILE *filp;
	char text;
	if((filp = fopen("./file1","w+")) == NULL)
	{
		printf("打开文件失败!\n");
		exit(1);
	}
	printf("打开文件成功!\n");
	while((text = getchar()) != '!')
	{
	    fputc(text, filp);		 
	}
	rewind(filp);
#if 0
	while((text = fgetc(filp)) != EOF)
	{
		putchar(text);
	}
#endif
	text = fgetc(filp);
	while(!feof(filp))
	{
		putchar(text);
		text = fgetc(filp);
	}
	printf("\n");
	fclose(filp);
	return 0;
}
