#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

int main()
{
		int i;
		int *x,*y;
		x = malloc(50 * sizeof(int));
		if(!x)
		{
					perror("malloc error!");
					return -1;
		}
		y = calloc(50,sizeof(int));
		if(!y)
		{
					perror("calloc error");
					return -1;
		}
		for(i=0; i<50; i++,x++,y++)
		{
		     printf("x: %d\n",*x);
	     	 printf("y: %d\n",*y);
		}
}
