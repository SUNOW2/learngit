#ifndef CTEST_H
#define CTEST_H

int test1();
int test2();

#endif
