#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
void fun(struct stat sta1);
int main()
{	
    struct stat sta1,sta2,sta3;
	chmod("test01",0664);
	chmod("test02",0674);
	chmod("test03",0622);
	stat("test01",&sta1);
	printf("test01\n");
	fun(sta1);
	stat("test02",&sta2);
    printf("test02\n");
	fun(sta2);
	stat("test03",&sta3);
    printf("test03\n");
	fun(sta3);
}
void fun(struct stat sta1)
{
	if ((sta1.st_mode & S_IRUSR)== S_IRUSR)
	{
		printf("user read!\n");
	}
	if ((sta1.st_mode & S_IWUSR)== S_IWUSR)
	{
		printf("user write!\n");
	}
	if ((sta1.st_mode & S_IXUSR)== S_IXUSR)
	{
		printf("user zhixing!\n");
	}
		
	if ((sta1.st_mode & S_IRGRP)== S_IRGRP)
	{
		printf("grp read!\n");
	}
	if ((sta1.st_mode & S_IWGRP)== S_IWGRP)
	{
		printf("grp write!\n");
	}
	if ((sta1.st_mode & S_IXGRP)== S_IXGRP)
	{
		printf("grp zhixing!\n");
	}
		
	
	if ((sta1.st_mode & S_IROTH)== S_IROTH)
	{
		printf("oth read!\n");
	}
	if ((sta1.st_mode & S_IROTH)== S_IWOTH)
	{
		printf("oth write!\n");
	}
	if ((sta1.st_mode & S_IXOTH)== S_IXOTH)
	{
		printf("oth zhixing!\n");
	}
}
