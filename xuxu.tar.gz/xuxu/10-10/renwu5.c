#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
int main(void)
{
	int fp,fd,ret;
	struct flock flock1;
	flock1.l_type=F_RDLCK;
	flock1.l_whence=SEEK_SET;
	flock1.l_start=10;
	flock1.l_len=20;
	struct flock flock2;
	flock2.l_type=F_WRLCK;
	flock2.l_whence=SEEK_SET;
	flock2.l_start=40;
	flock2.l_len=10;
	fd = open ("renwu2.sh",O_RDWR);
    ret=fcntl (fd,F_SETLK,&flock1);
			if(ret<0)
					printf("error\n");
	     printf("Process ** locking file!\n");
		 sleep(10);
		 printf("Process ** closing file!\n");
		 close(fd);
	fd = open ("renwu2.sh",O_RDWR);
    ret = fcntl (fd,F_SETLK,&flock2);
			if(ret<0)
					printf("error\n");
	     printf("Process ** locking file!\n");
		 sleep(10);
		 printf("Process ** closing file!\n");
		 close(fd);
}

