#!/bin/bash
dpkg-query -W --showformat='${Package} ${Version}\n' > filesystem.manifest
cut -f 1 filesystem.manifest -d " " > filesystem.manifest.name
cat filesystem.manifest.name
cat filesystem.manifest.name | xargs > filesystem.manifest.name.oneline
cat filesystem.manifest.name.oneline
cat filesystem.manifest.name | grep lsb | wc -l
