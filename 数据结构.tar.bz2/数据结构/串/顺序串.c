#include <stdio.h>
#include <string.h>
#define MAXSIZE 256       /*串可能的最大长度*/

typedef struct
{
	char ch[MAXSIZE];     /*字符串数组*/
	int length;           /*串的当前长度*/
}SeqString;               /*顺序串的类型*/

/*实现串的输入，限制串的长度为MAXSIZE，输入Enter键结束输入*/
void in_string(SeqString *s)
{
	int i=0;
	char ch;
	while((ch = getch()) !='\n' && i<MAXSIZE)  /*判断字符串是否结束*/
	{
		s->ch[i++] = ch;
	}
	s->length = i;                        /*置字符串的长度*/
}

/*实现串的输出*/
void out_string(SeqString *s)
{
	int i;
	for(i=0; i<s->length; i++)
	{
		putchar(s->ch[i]);
	}
}

/*输出串的长度*/
int Strlen(SeqString *s)
{
	return(s->length);
}

/*将串S复制到串T*/
void Strcpy(SeqString *s,SeqString *t)
		                        /*复制的目的串放在后面，复制的源串放在前面*/
{
	int i;
	for(i=0; i<s->length; i++)
	{
		t->ch[i] = s->ch[i];
	}
	t->length = s->length;
}

/*将串T链接到串S的尾部*/
SeqString *Strcat(SeqString *s, SeqString *t)
{
	int i;
	/*判断S和T之和是否超过串的最大长度*/
	if(s->length + t->length <= MAXSIZE)
	{
		for(i=0; i<t->length; i++)
		    s->ch[i+s->length] = t->ch[i];/*让串T全部连接到串S的尾部*/
		s->length = s->length +t->length; /*置串的实际长度*/
	}
	else
	{
		for(i=0; i<MAXSIZE-s->length; i++)
			s->ch[i+s->length] = t->ch[i];/*置串T的一部分到串S的尾部*/
		s->length = MAXSIZE;              /*置串的实际长度*/
	}
	return s;
}

/*在串s的pos处插入串t*/
SeqString *SeqInsert(SeqString *s, int pos, SeqString *t)
{
	int i,j;
	if(pos < 0 || pos >s->length)
		printf("插入位置不合法");
	if(s->length + t->length < MAXSIZE)
		{
			for(i=s->length+t->length; i>=t->length; i--)
				s->ch[i-1] = s->ch[i-t->length-1];
			for(i=0; i<t->length; i++)
				s->ch[i+pos-1] = t->ch[i];
		    s->length = s->length + t->length; 
		}
	else
	{
		if(pos+t->length < MAXSIZE)
		{
			for(i=MAXSIZE)
		}
	}
}

int main(int argc, char *argv[])
{
	SeqString *S,*T,*R;
	SeqString str_s,str_t,str_r;
	int i,j;
	S = &str_s;
	T = &str_t;
	R = &str_r;
	printf("请输入串S: \n");
	in_string(S);
	printf("\n请输入串T: \n");
	in_string(T);
	printf("\n串S为： \n");
	out_string(S);
	printf("\n串S的长度为：%d\n",Strlen(S));
	printf("\n串T为： \n");
    out_string(T);
	printf("\n串T的长度为：%d\n",Strlen(T));
	printf("\n串T复制给串R,串R为：\n");
	strcpy(T,R);
	out_string(R);
	printf("\n串R的长度为: %d\n",Strlen(R));
	printf("\n将R连接到T的尾部,串T为： \n");
	strcat(T,R);
	out_string(R);
	printf("\n串T的长度为: %d\n",Strlen(T));
	printf("请输入插入子串的位置：");
	scanf("%d",&i);
	StrInsert(S,i,T);
	printf("\nS中插入T之后，S为:\n");
	out_string(S);
	printf("\n请输入删除字串的位置和长度\n");
	scanf("%d,%d",i,j);
	printf("\n删除字串后，串S为: \n");
	StrDelete(S,i,j);
	out_string(S);
}
