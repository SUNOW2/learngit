#include <stdio.h>
#include <malloc.h>

#define SIZE 20
typedef char ElemType;
typedef struct LNode 
{
	ElemType data[SIZE];
	struct LNode * next;
}LNode,*LinkList;

LinkList CreateList(LinkList head);
void LinkPint(LinkList head);
int LinkInsert(LinkList head, int n, ElemType temp[]);
int DelList(LinkList head, int n);

int main(int argc, char *argv[])
{
	int n;
	ElemType cmp;
	LinkList head;
	ElemType buf[SIZE];
	head = (LinkList)malloc(sizeof(LNode));
	head->next = NULL;
	CreateList(head);
    LinkPint(head);
	printf("请输入： \n");
	printf("I,i...插入\n");
	printf("D,d...删除\n");
	printf("Q,q...退出\n");
//	scanf("%d",&n);
	scanf("%s",&cmp);
	switch(cmp)
	{
		case 'i':
		case 'I':
			printf("请输入插入的数值: \n");
			scanf("%s",buf);
			printf("请输入插入的位置: \n");
			scanf("%d",&n);
			LinkInsert(head, n, buf);
            LinkPint(head);
			break;
		case 'D':
		case 'd':
			printf("请输入删除的位置： \n");
			scanf("%d",&n);
            DelList(head, n);
            LinkPint(head);
			break;
		default:
			break;
	}
}

LinkList CreateList(LinkList head)
{
	int i;
	ElemType temp[SIZE];
	LinkList p;
	LinkList q;
    head->next = NULL;
	q = head;
    printf("请输入结点值： \n");
//	fgets(temp, SIZE, stdin);
	scanf("%s",temp);
    while(temp[0] != '0')
	{
		p = (LinkList)malloc(sizeof(LNode));
        for(i=0; i<sizeof(temp); i++)
		{
		    p->data[i] = temp[i];
		}
		q->next = p;
//		q = q->next;
		q = p;
		printf("请输入结点值： \n");
//		fgets(temp, SIZE, stdin);
		scanf("%s",temp);
	}
	q->next = NULL;
	return head;
}


void LinkPint(LinkList head)
{
	int i=0;
	LinkList p;
	p = head->next;
	while(p != NULL)
	{
		i++;
	    printf("第%d个元素是%s\n",i,p->data);
		p = p->next;
	}
}



int LinkInsert(LinkList head, int n, ElemType temp[])
{
	int i;
	LinkList p,q;
	p = head;
	for(i=0; i<n-1; i++)
	{
		p = p->next;
	}
	q = (LinkList)malloc(sizeof(LNode));
	for(i=0; i<sizeof(temp); i++)
	{
    	q->data[i] = temp[i];
	}
	q->next = p->next;
	p->next = q;
	printf("***********\n");
	return 1;
}

int DelList(LinkList head, int n)
{
	int i;
	LinkList p,q;
	p = head->next;
	q = head;
	for(i=0; i<n-1; i++)
	{
		p = p->next;
		q = q->next;
	}
    q->next = p->next;
	free(p);
	return 1;
}
