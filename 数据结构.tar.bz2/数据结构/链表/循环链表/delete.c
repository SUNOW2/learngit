/*     从以L作为表头的循环链表中删除第i个结点,
       如果成功，返回TRUE，
       如果失败，返回FALSE    */
int DelCList(LinkList *L,int i)
{
   int j;
   LinkList *t1, *t2; 
   j = 1;
   t1 = L->next;
   t2 = L;                     /*用t2保存要删除结点的前一个结点*/
   if(j<i-1 && t1->next!=NULL)
   {
	   j++;
	   t2 = t2->next;
	   t1 = t1->next;
   }
   if(j>i)                     /*找不到要删除的合适的结点*/
	   return FALSE;
   t2->next = t1->next;        /*有合适的删除结点*/
   free(t1);                   /*释放存储空间*/
   return TURE;
}
