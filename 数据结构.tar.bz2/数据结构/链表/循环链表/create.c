int InitCList(LinkList *L)
{
	/*创建一个头指针为L的循环链表，若成功，则返回TRUE，否则，返回FALSE*/
	L = (LinkList *)malloc(sizeof(LinkList)); 
	if(L == NULL)
		return FALSE;
	L->next = L;
	return TRUE;
}
