/*   *本算法数据e插入以L作为表头的循环链表中的第i个位置，
     *若成功，返回TRUE，
     *若失败，则返回FAKLSE*/
int InsertCList(LinkList *L, int i, ElempType e)
{
	int j;
	LinkList *temp,*node;
	temp = L->next;
	j = 1;
	while(j<i && temp != L)
	{
		j++;
		temp = temp->next;
	}
	if(j<i && temp->next==L)      /*没有合适的插入位置*/
		return FALSE;
	node = (LinkList *)malloc(sizeof(LinkList));
    if(node == NULL)              /*申请结点不成功*/
		return FALSE;
	node->next = temp->next;      /*插入数据*/
	temp->next = node;
	return TRUE;
}
