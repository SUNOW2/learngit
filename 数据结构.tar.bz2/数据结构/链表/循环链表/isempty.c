//判断循环链表是否为空
int isempty(LinkList *L)
{
	if(L->next == L)
		return TRUE;
	else
		return FALSE;
}
