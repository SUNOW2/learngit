#include <stdio.h>
#include <malloc.h>
#define SIZE 20

typedef char ElemType;
typedef struct LNode
{
	ElemType data[SIZE];
	struct LNode * next; 
}LNode, *LinkList;

#if 0
int ListInsert_L(LinkList head, int i, ElemType e);
#endif
int ListDel_L(LinkList head, int i);
void ListPint_L(LinkList head);
LinkList CreateList(LinkList head);


//main函数
void main(int argc, char *argv[])
{
	int i;
	char cmd,e;
	LinkList head;
	head = (LinkList)malloc(sizeof(LNode));   //头结点
    CreateList(head);             //尾插法实现带头结点的链表
	ListPint_L(head);             //顺序输出链表的内容
	do
	{
		printf("i,I...插入\n");
		printf("d,D...删除\n");
        printf("q,Q...退出\n");
		do
		{
		fflush(stdin);                           //清除磁盘缓冲区
			scanf("%s",&cmd);
		}while((cmd != 'D')&&(cmd != 'd')&&(cmd != 'I')&&(cmd != 'i')&&(cmd != 'Q')&&(cmd != 'q'));
		switch(cmd)
		{
#if 0
			case 'i':
			case 'I':
					printf("请输入你要插入的数据：\n");
					fflush(stdin);                   //清除磁盘缓冲区
					scanf("%s",&e);
					printf("请输入你要查入的位置：\n");
					scanf("%d",&i);
					ListInsert_L(head,i,e);
					ListPint_L(head);
					break;
#endif
			case 'd':
			case 'D':
					printf("请输入你要删除的位置：\n");
       				fflush(stdin);                  //清除磁盘缓冲区
					scanf("%d",&i);
					ListDel_L(head,i);
					ListPint_L(head);
					break;
		}
	}while((cmd != 'q')&&(cmd != 'Q'));
}


//在带头结点的单链表中的第i个位置之后插入数据
#if 0
int ListInsert_L(LinkList head, int i, ElemType e)
{
	LinkList p = head;
	LinkList s;
	int j;
	for(j=1; j<i; j++)
	{
		if(p)
			p = p ->next;
		else 
			break;
	}
	if(!p || i<1)
	{
		printf("error!!请输入正确的i值：\n");
		return 0;
	}
	s = (LinkList)malloc(sizeof(LNode));
	s->data = e;
	s->next = p->next;        //在当前结点p之后插入结点s
	p->next = s;
	return 0;
}
#endif

//建立链表，尾插法实现
LinkList CreateList(LinkList head)
{
	int i;
	LinkList p,q;
	ElemType temp[SIZE];
	head->next = NULL;
	q = head;
	printf("请输入结点值（输入0结束）:\n");
	fflush(stdin);
	scanf("%s",temp);
//	fgets(temp, SIZE, stdin);
	while(temp[0] !='0')
	{
        p = (LinkList)malloc(sizeof(LNode));
		for(i=0; i<sizeof(temp); i++)
		{
			p->data[i] = temp[i];
		}
        q->next = p;
		q = p;
		printf("请输入结点值（输入0结束）:\n");
		fflush(stdin);
		scanf("%s",temp);
//		printf("%s\n",temp);
//		fgets(temp, SIZE, stdin);
	}
	p->next = NULL;
	return head;
}


//在带头结点的单链表中删除第i个结点（从1开始）的元素
int ListDel_L(LinkList head, int i)
{
	int j;
	LinkList p,tmp;
	p = head->next;
	tmp = head;
	for(j=1; j<i; j++)
	{
		if(p)
		{
			p = p->next;               //p指向当前结点，p结点后移
			tmp = tmp->next;           //tmp指向当前结点的前趋
		}
		else
			break;
	}
	if(!p || i<1)
	{
		printf("error!!请输入正确的i值！\n");
		return 0;
	}
	tmp->next = p->next;               //删除结点p
	free(p);
	return 1;
}

//顺序输出链表的内容
void ListPint_L(LinkList head)
{
	int i=0;
	LinkList p;
	p =head->next;
	while(p !=NULL )
	{
		i++;
		printf("第%d个元素是：",i);
		printf("%s\n",p->data);
		p = p->next;
	}
}
