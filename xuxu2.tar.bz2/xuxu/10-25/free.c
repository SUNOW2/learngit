#include <stdio.h>
#include <mcheck.h>
#include <errno.h>
#include <stdlib.h>
int main()
{
	mtrace();
	int i;
    for(i=0; i<5; i++)
	{
		int j;
		char *s;
		s = calloc(i+2, 1);
		if(!s)
		{
			perror("calloc error!");
			exit(1);
		}
		for(j=0; j<i+1; j++)
		{
			s[j]='S';
		}
//		s[j]='\0';
		printf("%s\n",s);
		free(s);
	}
}
