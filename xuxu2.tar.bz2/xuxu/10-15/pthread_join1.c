#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>


void newthread()
{
	int i;
	for(i=0; i<3; i++)
	{
		printf("this is new pthread!\n");
	}
	pthread_exit("new pthread return!\n");
}

int main(void)
{
	void *pthread_result;
	pthread_t pth;
	int res;
	int i;
	res = pthread_create(&pth,NULL,(void *)newthread,NULL);
	if (res != 0)
	{
	    printf("fail to creat the pthread!\n");
		exit(1);
	}
    
	pthread_join(pth,&pthread_result);
	for(i=0; i<3; i++)
	{
		printf("this is father pthread!\n");
	}
	printf("pthread exit:%s\n",(char *)pthread_result);
	return 0;
}
