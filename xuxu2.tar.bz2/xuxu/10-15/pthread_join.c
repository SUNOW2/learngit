#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void newthread()
{
    int i;
	for(i=0; i<3; i++)
	{
		printf("this is new pthread!\n");
	}
	pthread_exit("pthread return!\n");
}
int main()
{
	pthread_t pth;
	int i;
	int res;
	void *pth_result;
	res = pthread_create(&pth,NULL,(void *)newthread,NULL);

	if(res != 0)
	{
		printf("fail to creat the thread!\n");
		exit(1);
	}
	for(i=0; i<3; i++)
	{
		printf("this is zhu pthread!\n");
	}
	pthread_join(pth,&pth_result);
	printf("pthread return!%s\n",(char *)pth_result);
	return 0;
}
