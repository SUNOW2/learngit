#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

int main(int argc, char *argv[])
{
	int sta;
	pid_t pid;
	union sigval sg;
	if(argc != 2)
	{
		printf("arguments error!\n");
		exit(1);
	}
	pid = atoi(argv[1]);
	sg.sival_int = getpid();
	sta = sigqueue(pid, SIGUSR1,sg);
	if (sta < 0)
		printf("sed error!\n");
	else
		printf("Done!\n");
	return 0;
}
