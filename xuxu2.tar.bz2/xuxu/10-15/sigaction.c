#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

void sig_handler(int sig, siginfo_t *info, void *t)
{
	printf("Received signal:%d\n",sig);
    return;
}
int main()
{
	int sta;
	struct sigaction act;
	act.sa_sigaction = sig_handler;
	sigemptyset(&act.sa_mask);
	act.sa_flags = SA_SIGINFO;
	sta = sigaction(SIGINT, &act, NULL);
	if(sta < 0)
	{
	    printf("sigaction error!\n");
	}
	for(; ;);
	return 0;
}
