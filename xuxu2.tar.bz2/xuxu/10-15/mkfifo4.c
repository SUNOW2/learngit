#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#define SIZEBUF 256

int main(int argc, char *argv[])
{
	int fd;
	int num;
	char buf[SIZEBUF];
    fd = open(argv[1], O_RDONLY|O_NONBLOCK);
	if (fd < 0)
	{
		printf("open error!\n");
		exit(1);
	}
	printf("Client:\n");
	while (1)
	{
		num = read(fd, buf, sizeof(buf));
		if(num == -1)
		{
			if(errno == EAGAIN)
			{
				printf("No data avlaible\n");
			}
		}
		else
		{
			printf("Real read bytes: %d\n",num);
			printf("Received message:%s\n",buf);
			break;
		}
		sleep(1);
	}
	return 0;
}
