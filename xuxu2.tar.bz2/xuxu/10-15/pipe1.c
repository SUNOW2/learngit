#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#define BUFSIZE 256

int main(int argc, char *argv[])
{
	pid_t cpid;
	int status;
	int fifod[2];
	char buf[BUFSIZE] = "Linux C is very good!\n";
	char buf2[BUFSIZE];
	if (pipe(fifod) < 0)  //chaung jian ni ming guan dao
	{
		printf("pipe error!\n");
		exit(1);
	}
	cpid = fork();        //chuang jian zi jing cheng  
	if (cpid < 0)
	{
	    printf("fork error!\n");
		exit(1);
	}
	else if (cpid == 0)
	{
		close(fifod[0]);
		write(fifod[1], buf, sizeof(buf));
	}
	else 
	{
		close(fifod[1]);
		read(fifod[0], buf2, sizeof(buf));
        printf("Received message from child process:\n%s",buf2);
		if (wait(&status) != cpid)
		{
			printf("fail to wait the child process!\n");
			exit(1);
		}
	}
	return 0;
}
