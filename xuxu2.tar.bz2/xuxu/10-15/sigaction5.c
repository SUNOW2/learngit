#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
int main()
{
int sta;
pid_t pid;
union sigval sg;
sg.sival_int = getpid(); 
if (argc != 2)
{
    printf("arguments error!\n");
	exit(1);
}
pid = atoi (argv[1]);
sta = sigqueue (pid, SIGUSR1, sg);
if (sta < 0)
	printf("send error!\n");
else
    printf("Done!\n");
}
