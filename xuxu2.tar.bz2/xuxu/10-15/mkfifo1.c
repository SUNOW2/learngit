#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>

int main(int argc, char *argv[])
{
	mode_t mode=0750;
	int status;
	if (argc != 2)
	{
		printf("arguments error!\n");
		exit(1);
	}
	status = mkfifo(argv[1], mode);
	if (status < 0)
	{
		printf("mkfifo error!\n");
		exit(1);
	}
	else
	{
		printf("FIFO creat success!\n");
		exit(0);
	}
	unlink(argv[1]);
	return 0;
}
