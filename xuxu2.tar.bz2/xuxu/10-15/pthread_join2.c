#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

void newthread();
int main()
{
//	void *pthread_result;
	pthread_t pth;
	void *pthread_result;
    int res;
    int i; 

	res = pthread_create(&pth,NULL,(void *)newthread,NULL);
	if(res != 0)
	{
		printf("fail to create the pthread!\n");
		exit(1);
	}
    
	for(i=0; i<3; i++)
	{
		printf("this is new pthread!\n");
		sleep(1);
	}
	pthread_join(pth,&pthread_result);
    printf("exit:%s",(char *)pthread_result);
	return 0;
}

void newthread()
{
	int i;
	for (i=0; i<4; i++)
	{
		printf("this is a new thread!\n");
		sleep(1);
	}
	pthread_exit("the new thread exit!\n");
}
