#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
int main(void)
{
		 int fol;
		 fol = open("file",O_CREAT | O_EXCL,00750);
		 if(fol==-1)
		 {
				  perror("Failed open!\n");;
				  exit(1);
		 }
		 return 0;
}
