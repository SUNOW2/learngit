#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <error.h>
#define SIZE 256
int main(int argc,char **argv)
{
		 int fol1,fol2;
		 int cpy,wri;
		 if(argc != 3)
		 {
				  printf("few!\n");
				  exit(1);
		 }
		 fol1 = open (argv[1],O_RDONLY);
		 if(fol1==-1)
		 {
				  printf("fail to open the file1!\n");
				  exit(1);
		 }
		 fol2 = open(argv[2],O_WRONLY | O_CREAT,S_IRUSR | S_IWUSR);
		 if(fol2==-1)
		 {
				  printf("fail to open the fail2!\n");
		 }
		 while(cpy=read(fol1,buffer,SIZE))
		 {
				  if(cpy=-1)
				  {
						   prror("Wrong!\n");
						   break;
				  }
				  else if(cpy>0)
				  {
						   ptr = buuffer;
						   while((wri = (fol2,ptr,SIZE))!=0)
						   {

								    if(wri == -1)
									{
											 printf("faile to write!\n");
											 break;
									}
									else if(wri == cpy)
									{
										     break;	 
									}
									else if(wri>0)
									{
											 ptr+=wri;
											 cpy-=wri;
									}
						   }
						   if(wri==-1)
								   break;
				  }
		 }
		 close(fol1);
		 close(fol2);
		 printf("OK!\n");
		 return 0;
}
