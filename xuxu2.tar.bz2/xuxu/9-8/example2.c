#include <stdio.h>
{
		 int a[10];
		 a[10]=5;
		 return 0;
}
