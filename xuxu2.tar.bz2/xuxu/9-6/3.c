#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#define M 10
int main()
{
		int fd,len,i;
		int a[M];
		fd=open("sort.txt",O_RDWR);
		printf("%4d\n",fd);
		len=read(fd,a,40);
		printf("%4d\n",len);
//		for(i=0;i<M;i++)
//		{
				 printf("%4d",a);
//		}
}
