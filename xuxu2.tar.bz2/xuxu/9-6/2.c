#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
int main()
{
		int fd;
        fd= open("sort.txt",O_CREAT|O_RDWR,S_IRUSR|S_IWUSR);
		if(fd)
		{
	 write(fd,"65,43,79,21,298,12,3,54,44,1",40);
	                close (fd);
		 }
}
