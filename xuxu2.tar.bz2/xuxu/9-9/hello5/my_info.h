#include <stdio.h>
void main2(void)
{
		 printf("141610\n");
}

