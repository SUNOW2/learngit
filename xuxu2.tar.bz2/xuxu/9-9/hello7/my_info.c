#include <stdio.h>
void main1();
void main(void)
{
		 printf("141610\n");
		 main1();
}
