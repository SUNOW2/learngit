#include <stdio.h>
//#include "my_info.h"
void main2(void);
void main1(void)
{
		 printf("hello world!\n");
		 main2();
}
