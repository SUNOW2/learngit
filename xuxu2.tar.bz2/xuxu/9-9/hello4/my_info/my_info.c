#include <stdio.h>
//#include "my_info.h"
//int main2();
int main1()
{
		 printf("my number is 1416101112!\n");
//		 main2();
		 return 0;
}
