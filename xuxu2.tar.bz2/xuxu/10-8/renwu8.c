#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
int main()
{
	char name[100];
	gethostname(name,sizeof(name));
	printf("hostname = %s\n",name);
}
