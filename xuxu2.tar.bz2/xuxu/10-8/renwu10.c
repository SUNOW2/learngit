#include <string.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
int main(void)
{
	int i,fp1,fp2,fp3;
	char buf1[50] = "SSSSSSSSSSSSSSSSSSSS";
	char buf2[50];
	fp1 = open ("./file_src",O_RDWR|O_CREAT,0777);
    fp2 = open ("./file_bak",O_RDWR|O_CREAT,0777);
	fp3 = open ("file",O_RDWR|O_CREAT,0777);
    write (fp1,buf1,sizeof(buf1));

	lseek(fp1,0,SEEK_SET);
    read (fp1,buf2,sizeof(buf1));
    write (fp2,buf2,sizeof(buf2));

    printf("\nfile_src\n");
	system("cat file_src");
	printf("\nfile_bak\n");
	system("cat file_bak");
	printf("\n");
    
    read(fp2,buf2,sizeof(buf2));
	for(i=0;i<sizeof(buf2);i++)
	{
		buf2[i]=tolower(buf2[i]);
	}
	lseek(fp2,0,SEEK_SET);
	write(fp2,buf2,sizeof(buf2));
    
	printf("\nfile_bak\n");
	system("cat file_bak");
	printf("\n");

    strcat(buf1,buf2);
	write(fp3,buf1,sizeof(buf1));

	printf("\nHEBING:file\n");
	system("cat file");
	printf("\n");

    close(fp1);
	close(fp2);
	close(fp3);
    return 0;
}
