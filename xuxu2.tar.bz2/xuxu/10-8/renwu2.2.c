#include <stdio.h>
#include <stdlib.h>
int main(void)
{
    int x,y;
    char fx[7],fy[7];
    fgets(fx,7,stdin);
	fgets(fy,7,stdin);
	x=atoi(fx);
    y=atoi(fy);
	while(x>0&&x<100000&&y>0&&y<100000)
	{
		printf("%4d\n",x+y);
		sleep(2);
        fgets(fx,7,stdin);
     	fgets(fy,7,stdin);
        x=atoi(fx);
     	y=atoi(fy);
	}
	return 0;
}
