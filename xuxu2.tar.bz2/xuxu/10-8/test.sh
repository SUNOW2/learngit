#!/bin/bash
echo $HELLO,$USER!
