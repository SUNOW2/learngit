#!/bin/bash
a=$(pwd)
echo $a
b=${a%/*}
c=${a:3:6}
echo $c
echo $b
