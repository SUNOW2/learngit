#!/bin/bash
ps -aux | sort -nrk3 | head -5 | awk 'BEGIN{print "CPU" "\t" "COMMAND"}{print $3 "\t" $11}END{print "success"}'
