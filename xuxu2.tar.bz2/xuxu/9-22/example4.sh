#/bin/bash
mkdir 9-22-1
touch ~/xuxu/9-22/9-22-1/example5.sh
