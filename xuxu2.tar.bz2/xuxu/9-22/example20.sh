#!/bin/bash
echo "qq4 :"
sort ./qq4
echo "qq2 :"
sort ./qq2 
echo "qq4 have but qq2 don't have"
comm -23 ./qq4 ./qq2
echo "both qq4 and qq2 have"
comm -1 ./qq4 ./qq2
