#!/bin/bash
i=0
while [[ $i -lt 30 ]]
do
   userdel stu$((++i)) 
done

