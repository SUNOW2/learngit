#!/bin/bash
sort ./example100.sh -o example100.sh
sort ./example200.sh -o example200.sh
echo "example200.sh have but example100.sh don't have"
comm -23 ./example100.sh ./example200.sh
echo "both example200.sh and example100.sh have"
comm -122 ./example100.sh ./example200.sh
