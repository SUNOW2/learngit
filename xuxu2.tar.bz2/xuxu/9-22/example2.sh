#!/bi/bash
ls -l | awk NR!=1 | sort -k5 -o example3.sh
