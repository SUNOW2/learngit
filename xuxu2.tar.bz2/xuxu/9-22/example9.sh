#!/bin/bash
#mkdir ~/xuxu/9-22/backup
#tar -zcvf ~/xuxu/9-22/backup/log_back.tar.bz2 /var/log
tar -zxvf ~/xuxu/9-22/backup/log_back.tar.bz2 -C /tmp
rm ~/xuxu/9-22/backup/log_back.tar.bz2
