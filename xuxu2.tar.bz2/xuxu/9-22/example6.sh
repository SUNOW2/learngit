#!/bin/bash
cat example5.sh | while read line 
do
echo $line
done
