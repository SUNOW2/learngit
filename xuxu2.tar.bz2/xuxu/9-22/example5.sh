hello world
hello boy
hello girl
