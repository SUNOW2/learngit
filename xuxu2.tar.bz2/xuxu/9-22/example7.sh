#!/bin/bash
IFS=$'\n'
for line in `cat example5.sh`
do
   echo $line | tr 'a-z' 'A-Z'   
# echo $line | sed 'y/qwertyuiopasdfghjklmnbvcxz/QWERTYUIOPLKJHGFDSAZXCVBNM/' 
   echo $line | sed 's/[a-z]/\u&/g'
done
