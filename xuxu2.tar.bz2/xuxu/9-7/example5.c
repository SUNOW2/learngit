#include <stdio.h>
#include <stdlib.h>
void fun(int s[],int l,int r);
int main()
{
		 int i;
		 int a[10]={1,3,2,5,4,7,6,8,9,0};
		 fun(a,0,9);
		 for(i=0;i<10;i++)
		 {
				  printf("%4d",a[i]);
		 }
		 printf("\n");
		 return 0;
}
void fun(int s[],int l,int r)
{
		 int i,j;
		 int temp;
		 if(l<r)
		 {
				 i=l;
				 j=r;
				 temp=s[i];
				  while(i<j)
				  {
						  while(s[j]>temp&&i<j)
								  j--;
						  if(i<j)
								  s[i++]=s[j];
						  while(s[i]<temp&&i<j)
								  i++;
						  if(i<j)
								  s[j--]=s[i];
				  }
				  s[i]=temp;
		          fun(s,l,i-1);
		          fun(s,i+1,r);
		 }
}
