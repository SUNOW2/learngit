#include <stdio.h>
#define SIZE 10
void fun2(int s[],int l,int r);
void fun1(int a[SIZE]);
int main()
{
		FILE *fp1,*fp2;
		int i;
		int px[SIZE],px2[SIZE];
		if((fp1=fopen("sort.txt","r"))==NULL)
		{
				 printf("Can't open!");
                 return;
		}
		for(i=0;i<SIZE;i++)
		{
				 fscanf(fp1,"%4d",&px[i]);
		}
		rewind(fp1);
		for(i=0;i<SIZE;i++)
		{
				 fscanf(fp1,"%4d",&px2[i]);
		}
		for(i=0;i<SIZE;i++)
		{
				 printf("%4d",px[i]);
		}
        printf("\n");

		for(i=0;i<SIZE;i++)
		{
				 printf("%4d",px2[i]);
		}
		printf("\n");
		fun1(px);
		fun2(px2,0,SIZE-1);
		fclose(fp1);
		if((fp2=fopen("result.txt","w"))==NULL)
		{
				 printf("Can't open!");
				 return;
		}
		for(i=0;i<SIZE;i++)
		{
				 fprintf(fp2,"%4d",px[i]);
		}
		fprintf(fp2,"\n");

		for(i=0;i<SIZE;i++)
		{
				 fprintf(fp2,"%4d",px2[i]);
		}
		fprintf(fp2,"\n");
		fclose(fp2);
		return 0;
}
void fun1(int a[SIZE])
{
		 int i,j,k;
		 for(i=0;i<SIZE;i++)
		 {
				  for(j=0;j<SIZE-1-i;j++)
				  {
						   if(a[j]>a[j+1])
						   {
								  k=a[j];
								  a[j]=a[j+1];
								  a[j+1]=k;
						   }
				  }
		 }
		 return 0;
}
void fun2(int s[],int l,int r)
{
		 int i,j,k;
		 if(l<r)
		 {
				  i=l;
				  j=r;
				  k=s[i];
				  while(i<j)
				  {
						   while(i<j&&s[j]>k)
								   j--;
						   if(i<j)
								   s[i++]=s[j];
						   while(i<j&&s[i]<k)
								   i++;
						   if(i<j)
								   s[j--]=s[i];
				  }
				  s[i] = k;
				  fun2(s,l,i-1);
				  fun2(s,i+1,r);
		 }
}
