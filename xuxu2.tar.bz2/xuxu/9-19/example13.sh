#!/bin/bash
ifconfig | grep 'inet addr' | awk '{print $2}' | sed -n '1p' | sed 's/addr://g'
