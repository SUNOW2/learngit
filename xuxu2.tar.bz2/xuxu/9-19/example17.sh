#!/bin/bash
echo "please input a word!"
read word
grep -q $word example30.sh
if test $?==0
then
   echo "exit"
else
   echo "no exit"
fi
