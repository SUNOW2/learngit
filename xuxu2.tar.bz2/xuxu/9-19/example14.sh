#!/bin/bash
#cat /etc/shadow | grep '!' | awk '{print $1}'

cat /etc/shadow | grep '!' | awk 'BEGIN {FS=":"}{print $1}'
