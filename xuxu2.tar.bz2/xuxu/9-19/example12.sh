#!/bin/bash
echo "please input the fileage!"
read fileage
while [ 1 ]
do
  if test -d ~/xuxu/9-19/$fileage
  then
     echo "exit"
  else
     echo "not exit"
     mkdir $fileage
	 break
  fi
done
