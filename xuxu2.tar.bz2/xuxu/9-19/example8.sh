#!/bin/bash
find . -size -10k | tee readme.txt | wc -l 
