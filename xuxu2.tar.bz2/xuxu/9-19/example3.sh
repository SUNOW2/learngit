#!/bin/bash
echo "please input two numbers!"
read num1
read num2
if [ $num1 -eq $num2 ]
then
   echo "$num1 equal $num2"
elif [ $num1 -gt $num2 ]
then
   echo "$num1 great $num2"
else
  echo "$num1 little $num2"
fi
