#!/bin/bash
echo "shurulianggezifu!"
read a b 
if [ -b $example1.c ]
then
  echo "Yes"
  cp example1.c /dev
else
  echo "No"
fi
test $a -gt $b
echo $? 
