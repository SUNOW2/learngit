#!/bin/bash 
a=$(ps -u | grep $$ | awk '{print $1}')
echo $a
