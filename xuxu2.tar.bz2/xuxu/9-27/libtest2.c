int test2()
{
	return 2;
}
