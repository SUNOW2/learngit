#include <stdio.h>
#include "foo.h"
int main(void)
{
	puts("This is a shared library!\n");
	foo();
	return 0;
}
