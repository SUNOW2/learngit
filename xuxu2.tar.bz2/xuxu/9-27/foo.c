#include <stdio.h>
void foo(void)
{
	puts("hello,i'm boy!\n");
}
