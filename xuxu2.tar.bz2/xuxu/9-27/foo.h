#ifndef foo_h_
#define foo_h_
extern void foo(void);
#endif //foo_h_
