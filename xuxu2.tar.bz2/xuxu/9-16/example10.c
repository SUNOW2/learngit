//example10.c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <errno.h>
int main(void)
{
		 pid_t pid;
		 if((pid=fork())==-1)
                  {
						   perror("failed to create a new process\n");
						   exit(0);
				  }
		 else if(pid==0)
		 {
				  printf("This is child process,output begin\n");
				  printf("This is child process,content in buffer");
				  exit(0);
		 }
		 else
		 {
				 sleep(3);
				 printf("\nparent process,output begin\n");
				  printf("This is child process,content in buffer");
				  _exit(0);
		 }
		 return 0;
}
