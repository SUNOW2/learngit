#!/bin/bash
counter=0
for files in `ls`
do
   counter=$((++counter))
done
echo "there are $counter files in `pwd`"
