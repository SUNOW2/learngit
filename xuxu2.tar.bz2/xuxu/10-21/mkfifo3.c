#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#define SIZEBUF 256

int main(int argc, char *argv[])
{
	int fd;
	char buf[SIZEBUF];
	if (argc != 2)
	{
		perror("arguments error!");
		exit(1);
	}
    fd = open(argv[1], O_RDONLY);
	if (fd == -1)
	{
		printf("fail to open the FIFO:\n");
		exit(1);
	}
	printf("Client:\n");
//	lseek(fd,0,SEEK_SET);
	read(fd,buf,sizeof(buf));
	printf("Received message:%s",buf);
	return 0;
}
