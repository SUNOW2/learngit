#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <string.h>

#define SIZE 1024
typedef struct
{
	char no[8];
	char name[8];
	double price;
}BOOK;

int main()
{
	int i;
	int shmid;
	key_t key;
	BOOK *shmaddr;
	
	key = ftok("/home/sunow1",123);
	if(key < 0)
	{
		printf("ftok error!\n");
		exit(EXIT_FAILURE);
	}

	shmid = shmget(key,SIZE,IPC_CREAT | 0666);
	printf("shmid = %d\n",shmid);
    shmaddr = (BOOK *)shmat(shmid, NULL, 0);
    if (shmaddr == (BOOK *)-1)
	{
		printf("shmat error!\n");
		exit(1);
	}
	
	for(i=0; i<2 ;i++)
	{
		printf("no:%s\nname:%s\nprice:%2.0lf\n",(*(shmaddr+i)).no,(*(shmaddr+i)).name,(*(shmaddr+i)).price);
	}
	shmdt(shmaddr);
	if(shmctl(shmid,IPC_RMID,0) == -1)
	{
		printf("smctl error!\n");
		exit(1);
	}
	return 0;
}
