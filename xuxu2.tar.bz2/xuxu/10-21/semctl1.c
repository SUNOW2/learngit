#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <errno.h>
#include <unistd.h>

#define SIZE 1024
union struct
{
	int val;
	struct semid_ds *buf;
	unsigned short *array;
}arg;

int main()
{
	int semid;
	pid_t pid;
	key_t key;
	int shmid;
	unsigned short sem_array[2];
	sem_array[0] = 0;
	sem_array[1] = 1;
	arg.array = sem_array;
	int res;
	int status;
	int shmaddr;
	struct sembuf lock = {0,-1,SEM_UNDO};
	struct sembuf unlock = {0,1,SEM_UNDO};// | IPC_NOWAIT};
	shmid = shmget(IPC_PRIVATE,SIZE,IPC_CREAT | 0666);
	key = ftok("./",'a');
	if(key < 0)
	{
		printf("fail to ftok!\n");
		exit(1);
    }
	semid = semget(key, 2, IPC_CREAT | 0666);           ///
    if(semid < 0)
	{
		printf("fail to semget!\n");
		exit(1);
	}

	res = semctl(semid, 0, SETVAL, 1);                     ////
	if(res == -1)
	{
		printf("fail to semtcl!\n");
		exit(1);
	}
	pid = fork();
	if (pid < 0)
	{
		printf("fail to fork!\n");
		exit(1);
	}
	else if(pid == 0)
	{
			shmaddr = (int)shmat(shmid,0,0);
			if(shmaddr == -1)
			{
				printf("shmat error!\n");
				exit(1);
			}
			while(1)
			{
	res = semctl(semid, 0, SETVAL, 1);                     ////
	     		sleep(abs((int)(3.0*rand()/(RAND_MAX+1.0))));
                res = semop(semid,&lock,1);
		    	if(res == -1)
	     		{
		     		perror("lock error1");
			    	exit(1);
		    	}
				shmaddr = rand();
				printf("xiaofei:\n%d\n",shmaddr);
	     		sleep(abs((int)(3.0*rand()/(RAND_MAX+1.0))));
		    	res = semop(semid,&unlock,1);
		    	if(res == -1)
		    	{
			    	printf("unlock error!\n");
			    	exit(1);
		     	}
//		    	printf("Complete!\n");
	res = semctl(semid, 1, SETVAL, 1);                     ////
	    	}
			shmdt(shmaddr);
	}
	else
	{

		shmaddr = (int)shmat(shmid,0,0);
		if(shmaddr == -1)
		{
			printf("shmat error!\n");
			exit(1);
		}
		while(1)
		{
	res = semctl(semid, 0, SETVAL, 1);                     ////
			sleep(abs((int)(3.0*rand()/(RAND_MAX+1.0))));
			res = semop(semid,&lock,1);
			if(res == -1)
			{
				printf("lock error!\n");
				exit(1);
			}
            
//			shmaddr = rand();
			printf("shengchan:\n%d\n",shmaddr);
			sleep(abs((int)(3.0*rand()/(RAND_MAX+1.0))));
			res = semop(semid,&unlock,1);
			if(res == -1)
			{
			    printf("unlock error!\n");
				exit(1);
			}
//			printf("Complete!\n");
	res = semctl(semid, 1, SETVAL, 1);                     ////
		}
		if(wait(&status) != pid)
		{
			printf("fail to wait!\n");
			exit(1);
		}
		res = semctl(semid, 0, IPC_RMID, 0);
		if(res == -1)
		{
			perror("semctl error1");
			exit(1);
		}
	}
	return 0;
}
