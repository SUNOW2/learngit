#include <stdio.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <errno.h>
#include <unistd.h>

#define SIZE 1024
union semun
{
	int val;
	struct semid_ds *buf;
	unsigned short *array;
};

int shmid,semid;
union semun array;

int main()
{
	pid_t pid;
	int du;
	int res;
	char buffer[20]= {0};
	struct sembuf buf1 = {0,-1,SEM_UNDO};
	struct sembuf buf2 = {1,1,SEM_UNDO};
	struct sembuf buf3 = {1,-1,SEM_UNDO};
	struct sembuf buf4 = {0,1,SEM_UNDO};
	void *shmaddr;

	shmid = shmget(IPC_PRIVATE,SIZE,IPC_CREAT | 0666);
    
	semid = semget(IPC_PRIVATE,2,IPC_CREAT | 0666);
	printf("semid = %d\n",semid);
	shmaddr = shmat(shmid,NULL,0);

	pid = fork();
	if(pid < 0)
	{
		printf("fork error1\n");
		exit(1);
	}
	else if(pid == 0)
	{
		array.val = 0;
		semctl(semid, 1, SETVAL,array);
		
		while(1)
		{
			semop(semid, &buf1, 1);
			printf("consumer:%s\n",(char *)shmaddr);
			semop(semid, &buf2, 1);
			sleep(1);
		}
	}
	else
	{
	    array.val = 1;
		semctl(semid, 1, SETVAL,array);
		while(1)
		{
			semop(semid, &buf3, 1);

			du = (int)rand()%10;
			sprintf(buffer,"%d",du);
			strcpy(shmaddr,buffer);

			printf("producer:%s\n",(char *)shmaddr);
			semop(semid, &buf4, 1);
			sleep(1);
		}
	}
}
