#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#define SIZE 3 
int main()
{
	pid_t pid;
	int fifod[2];
	int status;
	char buffer[SIZE];
	if(pipe(fifod) < 0)
	{
		printf("pipe error!\n");
		exit(1);
	}
	pid = fork();
	if (pid < 0)
	{
		printf("fork error!\n");
		exit(1);
	}
	else if(pid == 0)
	{
//		char buffer[SIZE];
		read(fifod[0], buffer, sizeof(buffer));
		printf("Receive message:%s\n",buffer);
       
        if(strcmp("-l",buffer) == 0)
		{
		    execl("/bin/ls","ls",buffer,NULL);
		}

	}
	else 
	{
		close(fifod[0]);
		printf("please input some chars!\n");
		fgets(buffer, SIZE, stdin);
		write(fifod[1], buffer, sizeof(buffer));
		printf("Send message:%s\n",buffer);
		if(wait(&status) != pid)
		{
			printf("wait error!\n");
			exit(1);
		}
	}
	return 0;
}
