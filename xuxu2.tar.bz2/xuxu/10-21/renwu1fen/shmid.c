#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <string.h>

#define SIZE 1024

int main()
{
	int shmid;
	int status;
	pid_t pid;
	struct shmid_ds buf_l;
	void *shmaddr;
	char buf[100];
	shmid = shmget(IPC_PRIVATE,SIZE,IPC_CREAT|0666);
	printf("shmid = %d\n",shmid);
    pid = fork();
	if(pid < 0)
	{
		printf("fork error!release\n");

		if(shmctl(shmid, IPC_RMID, 0) == -1)
		{
			printf("delete error!\n");
			exit(1);
		}
		exit(1);
	}
	else if(pid == 0)
	{
		printf("this is child process!\n");
        shmaddr = shmat(shmid, NULL, 0);
		if (shmaddr == (void *)-1)
		{
			printf("shmat error!\n");
			exit(1);
		}
		printf("please input some chars:\n");
		fgets(buf,sizeof(buf),stdin);
		printf("chars you write are:\n");
		strcpy((char *)shmaddr, buf);
		printf("%s",(char *)shmaddr);
		shmdt(shmaddr);
		exit(0);
	}
	else
	{
		if(wait(&status) != pid)
		{
			printf("wait error!\n");
			exit(1);
		}
		printf("this is parent process!\n");
        printf("Child process pid = %d\n",pid);
        printf("Parent process pid = %d\n",getpid()); 
		if(shmctl(shmid, IPC_STAT, &buf_l) == -1)
		{
			printf("shmid error!\n");
			exit(1);
		}
		printf("MemorySize = %ld\n",buf_l.shm_segsz);
        shmaddr = shmat(shmid, NULL, 0);
		if(shmaddr == (void *)-1)
		{
			printf("shmaddr error!\n");
			exit(1);
		}
        printf("Receive chars:\n%s",(char *)shmaddr);
		shmdt(shmaddr);
		if(shmctl(shmid, IPC_RMID, 0) == -1)
		{
			printf("delete error!\n");
			exit(1);
		}
	}	
	return 0;
}
