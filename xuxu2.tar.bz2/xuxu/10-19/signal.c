#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <sys/wait.h>
void my_func(int sign_no)
{
	if(sign_no == SIGINT)
	{
	    printf("I have get SIGINT\n");
	}
	else if(sign_no == SIGQUIT)
	{
		printf("I have get SIGQUIT\n");
	}
	return;
}

int main()
{
	printf("waiting for signal SIGINT or SIGQUIT\n");
	signal(SIGINT,my_func);
	signal(SIGQUIT,my_func);
//	for(;;);
//	pause();
	sleep(10);
	printf("hello world!\n");
	return 0;
}
