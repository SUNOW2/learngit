#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h>

int main()
{
	int pipe_fd[2];
	if(pipe(pipe_fd) < 0)
	{
		printf("fail to creat pipe!\n");
		exit(1);
	}
	else
	{
		printf("succeed to creat pipe!\n");
	}
	close(pipe_fd[0]);
	close(pipe_fd[1]);
}
