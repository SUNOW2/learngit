#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>

char buffer[512];
//sem_t sem;

void start_routine(void *message)
{
	printf("message = %s\n",(char *)message);
//        sem_wait(&sem);
//		while(strncmp("exit",buffer,4) != 0)
//		{
//			printf("the number you press:%d\n",strlen(buffer)-1);
//		    sem_wait(&sem);
//		}
		
		pthread_exit("thread exit!\n");
}
int main()
{
	void *pthread_result;
	char *message = "hello world";
	pthread_t pth;
	int res;

//	res = sem_init(&sem,0,0);
//    if(res != 0)
//	{
//		printf("fail to sem_init!\n");
//		exit(1);
//	}
	res = pthread_create(&pth, NULL, (void *)&start_routine,(void *)message);
	if(res != 0)
	{
	    fprintf(stderr,"fail to create!%d",errno);
		exit(1);
	}

	printf("please input some chars!\n");
	while(strncmp("exit",buffer,4) != 0)
	{
		fgets(buffer,512,stdin);
//		sem_post(&sem);
	}


	pthread_join(pth,&pthread_result);
	sleep(abs((int)(3.0*rand()/(RAND_MAX+1.0))));
	printf("exit:%s",(char *)pthread_result);
//	sem_destroy(&sem);
    return 0;
}
