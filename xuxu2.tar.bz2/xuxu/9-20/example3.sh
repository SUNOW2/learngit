for list in ``
do
  echo ${list#/*}
  echo $[list##/*]
  echo ${list}
  echo ${
