#!/bin/bash

for list in `cat ~/xuxu/9-20/example4.sh`
do
echo ${list%/*}
echo ${list##*/}
echo ${list##*.}
echo "--------------"
done
