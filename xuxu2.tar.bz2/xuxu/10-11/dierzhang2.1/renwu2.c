#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
int main(int argc,char **argv)
{
	pid_t pid1,pid2;
	pid1 = fork();
	if ( pid1 < 0 )
	{
		printf("fork error!\n");
	}
	else if ( pid1 == 0 )
	{
		printf("b: pid = %d,ppid = %d\n",getpid(),getppid());
	}
	else if ( pid1 > 0 )
	{
		printf("a: pid = %d,ppid = %d\n",getpid(),getppid());
		sleep(2);
		pid2 = fork();
		if( pid2 < 0 )
		{
			printf("fork error!\n");
		}
		else if ( pid2 == 0)
		{
			printf("c: pid = %d,ppid = %d\n",getpid(),getppid());
		}
		else
		{
			printf("d: pid = %d,ppid = %d\n",getpid(),getppid());
		}
		sleep(3);
	}
	return 0;
}
