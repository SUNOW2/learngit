#include <stdio.h>
#include <stdlib.h>
void fun1(int a[],int n);
void fun2(int s[],int l,int r);
int main()
{
	int i;
	FILE *fp1,*fp2;
	int px1[10],px2[10];
	if((fp1=fopen("sort.txt","r"))==NULL)
	{
		printf("open error!\n");
		return 1;
	}
	for(i=0;i<10;i++)
	{
		fscanf(fp1,"%4d",&px1[i]);
	}
	for(i=0;i<10;i++)
	{
		printf("%4d",px1[i]);
	}
    printf("\n");

	rewind(fp1);
	for(i=0;i<10;i++)
	{
		fscanf(fp1,"%4d",&px2[i]);
	}
	for(i=0;i<10;i++)
	{
		printf("%4d",px2[i]);
	}
	printf("\n");
	fclose(fp1);
    fun1(px1,10);
	fun2(px2,0,9);

	for(i=0;i<10;i++)
	{
		printf("%4d",px1[i]);
	}
	printf("\n");

	for(i=0;i<10;i++)
	{
		printf("%4d",px2[i]);
	}
	printf("\n");

    if((fp2=fopen("result.txt","w+"))==NULL)
	{
		printf("open error!\n");
		return 1;
	}

	for(i=0;i<10;i++)
	{
		fprintf(fp2,"%4d",px1[i]);
	}
    fprintf(fp2,"\n");
	
	for(i=0;i<10;i++)
	{
		fprintf(fp2,"%4d",px2[i]);
	}
    fprintf(fp2,"\n");

	fclose(fp2);
	return 0;
}

void fun1(int a[],int n)
{
	int i,j,k;
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-1;j++)
		{
			if(a[j]>a[j+1])
			{
				k=a[j];
				a[j]=a[j+1];
				a[j+1]=k;
			}
		}
	}
}

void fun2(int s[],int l,int r)
{
	int i,j,k;
	if(l<r)
	{
		i=l;
		j=r;
		k=s[i];
		while(i<j)
		{
			while(i<j&&s[j]>k)
					j--;
			if(i<j)
					s[i++]=s[j];
			while(i<j&&s[i]<k)
					i++;
			if(i<j)
					s[j--]=s[i];
		}
		s[i]=k;
		fun2(s,l,i-1);
		fun2(s,i+1,r);
	}
}
