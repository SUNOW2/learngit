#/bin/bash
gcc -Wall -fPIC -c add.c -o add.o
gcc -shared add.o -o libadd.so
gcc -Wall -L. -I. main1.c -ladd -o main -ldl
./main 4 6
