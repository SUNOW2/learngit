#!/bin/bash
gcc -Wall -fPIC -c add.c -o add.o
gcc -shared add.o -o libadd.so 
#gcc -Wall -L. -I. main.c -o main1 -ladd
#export LD_LIBRARY_PATH=/home/sunow1/xuxu/10-10/fuxi4.1:$LD_LIBRARY_PATH
#unset LD_LIBRARY_PATH
#gcc -Wall -L. -I. -Wl,-rpath=/home/sunow1/xuxu/10-10/fuxi4.1 main.c -o main2 -ladd
cp /home/sunow1/xuxu/10-10/fuxi4.1/libadd.so /usr/lib
chmod 0755 /usr/lib/libadd.so
ldconfig
gcc -Wall -L. -I. main.c -o main3 -ladd
./main3
