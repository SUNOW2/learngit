#include <stdio.h>
#include <dlfcn.h>
#include <stdlib.h>
#include "add.h"
int main(int argc,char *argv[])
{
	void *lib_handle;
	int (*fn)();
	char *error;

	lib_handle = dlopen("libadd.so",RTLD_LAZY);    //jia zai dong tai ku
	if(!lib_handle)
	{
		fprintf(stderr,"%s\n",dlerror());
		return 1;
	}

	fn = dlsym(lib_handle,"add");    //fan hui cha zhao han shu de di zhi
	if((error=dlerror()) != NULL)
	{
		fprintf(stderr,"%s\n",error);
		return 1;
	}
    
	int a=atoi(argv[1]);
	int b=atoi(argv[2]);
    printf("a+b=%d\n",fn(a,b));

	dlclose(lib_handle);           //xie zai dong tai ku

	return 0;
}
