
#!/bin/bash
gcc -Wall -fPIC -c add.c -o add.o
gcc -shared add.o -o libadd.so 

cp /home/sunow1/xuxu/10-10/fuxi4.1/libadd.so /usr/lib
chmod 0755 /usr/lib/libadd.so
ldconfig

gcc -Wall -L. -I. main1.c -o main4 -ladd -ldl

./main4 4 6
