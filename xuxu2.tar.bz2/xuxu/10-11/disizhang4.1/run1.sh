#/bin/bash
gcc -I. -c add.c -o add.o
ar -rcs libadd.a add.o
gcc main.c -o main -L./ -ladd
./main
