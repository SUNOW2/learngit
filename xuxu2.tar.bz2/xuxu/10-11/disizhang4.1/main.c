#include <stdio.h>
#include "add.h"
int main()
{
	int a,b;
	printf("please input a,b\n");
	scanf("%d%d",&a,&b);
    printf("a+b=%d\n",add(a,b));
	return 0;
}

