#!/bin/bash
a=$(ping -c 1 127.0.0.1 | grep "ttl" | awk '{print $6}')
echo $a
b=${a#*=}
echo $b
if [[ $b -gt 0 ]]
then
   echo "liantong success!"
else
   echo "liantong error!"
fi
