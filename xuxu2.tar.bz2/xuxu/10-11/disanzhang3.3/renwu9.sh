#!/bin/bash
find . -name "*.h" | while read line
do
  new=$(echo $line | sed 's/ /*/g')
  mv "$line" "$new"
done
