#!/bin/bash
echo "son process!"
echo $$
echo `cat /proc/$$/cmdline`
echo "father process!"
echo $PPID
echo `cat /proc/$PPID/cmdline`
echo "please confirm! yes or no?"
read a
if [[ $a == yes ]]
then
  kill $$
else
  echo "running!"
fi
