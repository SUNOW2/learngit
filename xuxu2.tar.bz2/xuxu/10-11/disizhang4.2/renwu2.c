#include <stdio.h>
#include <stdlib.h>
int main(int argc,char *argv[])
{
    
	int i;
	for(i=1;;i++)
	{
		printf("%4d\n",i);
		system(argv[1]);
		sleep(2);
	}
	return 0;
}
