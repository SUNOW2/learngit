#include <stdio.h>
#include <stdlib.h>
int main(void)
{
	char name[100];
	gethostname(name,sizeof(name));
	printf("hostname=%s\n",name);
	printf("%ld\n",sizeof(name));
	return 0;
}
