#include <stdio.h>
#include <stdlib.h>
int main(void)
{
	int i=1;
	while(1)
	{
		printf("%4d\n",i);
		system("date");
		i++;
		sleep(2);
	}
	return 0;
}
