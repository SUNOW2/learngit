#!/bin/bash
gnome-terminal -t "1" -x bash -c "./renwu1"
ps -aux | grep renwu1 | awk 'BEGIN{print "the information of PID"}{print $1 "\t" $2 "\t" $3}'
