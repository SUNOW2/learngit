#include "../head/my_info.h"
int main()
{
	printf("hello world");
	my_info();
	return 0;
}
