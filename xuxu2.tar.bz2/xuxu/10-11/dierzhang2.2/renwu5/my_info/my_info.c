#include "../head/my_info.h"
void my_info()
{
	printf("1416101112\n");
}
