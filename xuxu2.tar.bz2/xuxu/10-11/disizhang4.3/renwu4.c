#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
int main(void)
{
	int fd,fp;
	fd = open("renwu4.c",O_WRONLY);
	fp = fcntl(fd,F_GETFL);
	switch(fp & O_ACCMODE)
	{
			case O_RDONLY:
					printf("read only!\n");
					break;
			case O_WRONLY:
					printf("write only!\n");
			        break;
			case O_RDWR:
					printf("wrute and read!\n");
					break;
			default:
					printf("qita!\n");
					break;
	}
	return 0;
}
