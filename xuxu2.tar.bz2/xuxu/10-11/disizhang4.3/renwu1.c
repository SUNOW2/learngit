#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdlib.h>
#include <fcntl.h>

int main(void)
{
	int fp1,fp2,fp3,nue;
	char buf1[10000];
	if((fp1 = open ("/etc/passwd",O_RDONLY))==-1)
	{
		printf("open error!\n");
		return 1;
	}
	lseek(fp1,0,SEEK_SET);
	nue = read (fp1,buf1,10000);
	printf("/etc/passwd:\n");
	printf("%s\n",buf1);

	if((fp2 = open ("passwd",O_RDWR|O_CREAT,0777))==-1)
	{
		printf("open error!\n");
		return 1;
	}
	write(fp2,buf1,nue);
    printf("passwd:\n");
    system("cat passwd");
	printf("\n");

	if((fp3 = open ("passwd_half",O_RDWR|O_CREAT,0777))==-1)
	{
		printf("open error!\n");
		return 1;
	}
	write(fp3,buf1,nue/2);
	printf("passwd_half:\n");
	system("cat passwd_half");
	printf("\n");
	return 0;
}
