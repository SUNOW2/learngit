#include <stdio.h>
int main(void)
{
	FILE *fp1,*fp2,*fp3;
	int fd1,fd2,fd3;
    fd1 = fileno(stdin);
	printf("stdin=%d\n",fd1);
	fd2 = fileno(stdout);
	printf("stdout=%d\n",fd2);
	fd3 = fileno(stderr);
	printf("stderr=%d\n",fd3);
	
	fp1 = fopen("renwu6.c","r");
	fd1 = fileno(fp1);
	printf("fd1=%d\n",fd1);

	fp2 = fopen("renwu6.c","r");
	fd2 = fileno(fp2);
	printf("fd2=%d\n",fd2);
    fclose(fp1);
	fclose(fp2);

	fp3 = fopen("renwu6.c","r");
	fd3 = fileno(fp3);
	printf("fd3=%d\n",fd3);
	fclose(fp3);
	return 0;
}
