#include <stdio.h>
int main()
{
	int i,j;
	int k=13,sum=0;
	for(i=0;i<13/2;i++)
	{
		k=k-2;

		for(j=0;j<sum;j++)
		{
			printf(" ");
		}
         
		sum++;

		for(j=0;j<k;j++)
		{
			printf("*");
			fflush(NULL);
		}
		printf("\n");
	}
}
