#!/bin/bash
ps -aux | grep $$ | awk 'BEGIN{hello }{print $1}'
