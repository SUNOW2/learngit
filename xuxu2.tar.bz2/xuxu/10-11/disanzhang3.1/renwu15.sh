#!/bin/bash
echo "please input n!"
read n
sum=1
while [ $n -gt 0 ]
do
  sum=$(expr $sum \* $n)
  n=$((--n))
done
echo $sum
