#!/bin/bash
echo "please input the file you want to find!"
read file
if test -e /root/$file
then
   echo "exit!"
else 
   echo "no exit!"
fi
