#!/bin/bash
echo "please input a file!"
read file
sort -c $file
if [ $? -ne 0 ]
then
  echo "no sort!"
  sort -n $file
else 
  echo "sort before!"
fi
