#!/bin/bash
echo "please input a character!"
read char
case $char in 
        [[:upper:]]) echo "daxie"
		;;
		[[:lower:]]) echo "xiaoxie"
		;;
		[0-9]) echo "shuzi"
		;;
		*) echo "qita"
		;;
esac
