#!/bin/bash
echo "please input two numbers!"
read a
read b
if [ $a -lt $b ]
then 
   echo "$a is smaller than $b"
elif [ $a -gt $b ]
then
   echo "$a is bigger than $b"
else
   echo "$a is equal to $b"
fi
