#!/bin/bash
echo "please input a word!"
read word
grep -q $word /usr/share/dict/british-english
if test $? == 0
then 
   echo "exit!"
else
   echo "no exit!"
fi
