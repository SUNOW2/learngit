#!/bin/bash
a=$(pwd)
echo $a
b=${a%/*}
echo $b
