#!/bin/bash
echo "please input the directory!"
read directory
mkdir ./$directory
cd $directory
touch renwu3.sh
tree
