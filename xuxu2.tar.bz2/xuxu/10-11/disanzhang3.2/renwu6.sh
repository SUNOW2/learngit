#!/bin/bash
a='/var/log/boot.log'
b=${a%/*}
c=${a##*/}
d=${a##*.}
echo $b
echo $c
echo $d
