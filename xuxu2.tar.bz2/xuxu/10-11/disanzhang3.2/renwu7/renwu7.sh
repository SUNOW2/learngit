#!/bin/bash
mkdir ./backup
tar -zcvf ./backup/log_back.tar.bz2 /var/log
