#!/bin/bash
cat renwu2.sh | while read line 
do
  echo $line
done
