#!/bin/bash
ls -l | awk NR!=1 | sort -nk5 -o sort.txt
cat sort.txt
