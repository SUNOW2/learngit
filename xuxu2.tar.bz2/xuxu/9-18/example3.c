#include <stdio.h>
void function(int a[],int l,int r)
{
		int i,j,term;
	    if(l<r)
		{
			 i=l;
			 j=r;
		     term=a[i];
			 while(i<j)
	      	{
				 while(term>a[j]&&i<j)
						 j--;
                 if(i<j)
						 a[i++]=a[j];
				 while(term<a[i]&&i<j)
						 i++;
				 if(i<j)
						 a[j--]=a[i];
	    	}
		         a[i]=term;
                 function(a,l,i-1);
				 function(a,i+1,r);
        }
}
int main()
{
		int i;
		int a[10]={1,9,3,5,4,7,0,2,8,6};
		function(a,0,9);
		for(i=0;i<10;i++)
		{
				 printf("%3d",a[i]);
		}
		printf("\n");
		return 0;
}
