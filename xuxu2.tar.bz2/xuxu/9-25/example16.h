#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
void *thread_func(void *arg)
{
	int *val=arg;
	printf("Hi,i am a thread!\n");
	if(NULL!=arg)
	{
			 while(1)
				printf("arguement set: %d\n",*val);
	}
}
int main(void)
{
	pthread_t tid;
	int t_arg=10;
	if(pthread_create(&tid,NULL,thread_func,&t_arg))
	{
	   	perror("Failed to create thread!\n");
	}
	sleep(1);
	printf("Main thread!\n");
	pthread_cancel(tid);
	return 0;
}
