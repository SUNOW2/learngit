example16.c
