#!/bin/bash
ping -c 1 127.0.0.1 | grep "ttl=" | awk -F: '{print $1}'
