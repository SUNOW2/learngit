#!/bin/bash
ping -c 1 127.0.0.1 | awk -F: '{print $0}'
