#!/bin/bash
ifconfig eth0 | grep "inet addr" | awk '{print $2"\n"$3"\n"$4}' | awk -F: '{print $2}'
