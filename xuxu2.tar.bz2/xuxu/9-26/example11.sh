#!/bin/bash
for((i=141;i<145;i++))
do
  ping -c 1 192.168.255.$i
done
