#!/bin/bash
cat /etc/passwd | grep "/bin/bash" | awk '{OFS=":"}{print $7}' | wc -l
