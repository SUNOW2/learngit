#!/bin/bash
find . -name "*.t" | while read line
do
  mv $line `echo $line | sed 's/.t/.txt/g'`
done
