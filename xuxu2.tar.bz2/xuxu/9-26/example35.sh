#!/bin/bash
ls -l | awk NR!=1 | sort -nk5 -o example36.sh
