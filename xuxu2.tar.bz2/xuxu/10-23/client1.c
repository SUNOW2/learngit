#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <errno.h>

#define SERV_PORT 2360
#define SIZE 128

int main(int argc, char *argv[])
{
	int sockfd;
	int addrlen;
	int cnt;
	char buf[SIZE];
	struct sockaddr_in serveraddr; 
	sockfd = socket(AF_INET, SOCK_DGRAM, 0);
	if(sockfd == -1)
	{
		printf("sockfd error!\n");
		exit(EXIT_FAILURE);
	}
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(SERV_PORT);
	serveraddr.sin_addr.s_addr = inet_addr(argv[1]);
	bzero(&(serveraddr.sin_zero),8);
	addrlen = sizeof(struct sockaddr);
	strcpy(buf,argv[2]);
	cnt =sendto(sockfd, buf, SIZE, 0, (struct sockaddr *)&serveraddr,addrlen);
    if(cnt == -1)
	{
		printf("sendto error!\n");
		exit(EXIT_FAILURE);
	}
	printf("Send: %s\n",buf);
	close(sockfd);
}
