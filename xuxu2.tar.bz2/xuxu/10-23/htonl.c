#include <stdio.h>
#include <error.h>
#include <stdlib.h>
#include <netinet/in.h>

int main(int argc, char **argv)
{
	int x = 0x12345678;
	int *p = &x;
	int a = 4;
	int *q;
	q = &a;
	if(argc != 1)
	{
		perror("too many argumets1\n");
	}
	printf("%d\n",*q);
	char h = *((char *)p);
	printf("x = 0x%x\n",x);
	printf("h = 0x%x\n",h);
	int y = htonl(x);
	printf("y = 0x%x\n",y);
	return 0;
}
