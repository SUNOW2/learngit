#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
int main()
{
	int fd,fp;
	fd = open ("renwu2.sh",O_WRONLY);
	fp = fcntl(fd,F_GETFL);
	switch (fp & O_ACCMODE)
	{
		case O_RDONLY:
			printf("read only\n");
			break;
		case O_WRONLY:
			printf("write only\n");
			break;
		case O_RDWR:
			printf("write read\n");
			break;
		default:
			printf("unkown mode");
			break;
	}
    close(fd);
}
