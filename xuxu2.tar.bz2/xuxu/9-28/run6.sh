#!/bin/bash
gcc -E main8.c -o main8.i
gcc -S main8.i -o main8.s
gcc -c main8.s -o main8.o
gcc -static main8.o -o main81
gcc main8.o -o main82
file main81
file main82
objdump -x main81 | grep NEEDED
objdump -x main82 | grep NEEDED
