#!/bin/bash
gcc main8.c -o main8
./main8 8 9
