#!/bin/bash
gcc -E main1.c -o main1.i
gcc -E main2.c -o main2.i
diff -q main1.i main2.i
