ld -static /usr/lib/x86_64-linux-gnu/crt1.o /usr/lib/x86_64-linux-gnu/crti.o /usr/lib/gcc/x86_64-linux-gnu/4.8.4/crtbeginT.o -L/usr/lib/gcc/x86_64-linux-gnu/4.8.4 -L/usr/lib -L/lib main4.o --start-group -lgcc -lgcc_eh -lc --end-group /usr/lib/gcc/x86_64-linux-gnu/4.8.4/crtend.o /usr/lib/x86_64-linux-gnu/crtn.o -o main4
file main4
objdump -x main4
