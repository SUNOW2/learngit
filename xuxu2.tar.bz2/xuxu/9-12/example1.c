#include <stdio.h>
void main()
{
		 int i,j;
		 for(i=0;i<6;i++)
		 {
				  if(i==0)
				  for(j=0;j<11;j++)
				  {
						   printf("* ");
				  }
				  printf("\n");
				  printf(" ");
				  if(i==1)
						  for(j=0;j<9;j++)
						  {
								   printf("* ");
						  }
				  printf("\n");
				  printf("  ");
				  if(i==2)
						  for(j=0;j<7;j++)
						  {
								   printf("* ");
						  }
				  printf("\n");
				  printf("   ");
				  if(i==3)
						  for(j=0;j<5;j++)
						  {
								   printf("* ");
						  }
				  printf("\n");
                  printf("    ");
				  if(i==4)
						  for(j=0;j<3;j++)
						  {
								   printf("* ");
						  }
				  printf("\n");
                  printf("     ");
				  if(i==5)
								   printf("* \n");
		 }
}
