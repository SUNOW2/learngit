#include <stdio.h>
void fun1();
void main()
{
		 int i,j,k,n=0,m;
		 for(i=0;i<7;i++)
		 {
                  k=n;				  
				  n=n+2;
				  for(m=0;m<k/2;m++)
				  {
						   printf(" ");
				  }
				  for(j=0;j<13-n+2;j++)
				  {
						   printf("*");
				  }
				  for(m=0;m<k/2;m++)
				  {
						   printf(" ");
				  }
				  printf("\n");
		 }
		 fun1();
}
void fun1()
{
		 int i,j,k=13;
	     for(i=0;i<6;i++)
		 {
				  k=k-2;
				  for(j=0;j<k/2;j++)
				  {
						   printf(" ");
				  }
				  for(j=0;j<=13-k;j++)
				  {
						   printf("*");
				  }
				  printf("\n");

		 }
}
