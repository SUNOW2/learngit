#include <stdio.h>
int main()
{
		 int i,j;
		 for(i=11;i>0;i=i-2)
		 {
				  for(j=0;j<(11-i)/2;j++)
						  printf(" ");
				  for(j=0;j<i;j++)
				  {
						  printf("*");
						  fflush(NULL);
				  }
				  for(j=0;j<(11-i)/2;j++)
						  printf(" ");
				  printf("\n");
		 }
		 return 0;
}
