#include "my_info.h"
void main()
{
		 printf("hello world\n");
		 main1();
}
