#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>

char buffer[512];
int i=0;
pthread_rwlock_t rwlock;

void start_routine1()
{
		while(1)
		{
        pthread_rwlock_rdlock(&rwlock);
		printf("readlock1 = %d\n",i);
		i++;
		pthread_rwlock_unlock(&rwlock);
		sleep(1);
		}
//		sleep(2);
		pthread_exit("thread exit!\n");
}


void start_routine2()
{
		while(1)
		{
        pthread_rwlock_rdlock(&rwlock);
		printf("readlock2 = %d\n",i);
		i++;
		pthread_rwlock_unlock(&rwlock);
		sleep(1);
		}
		pthread_exit("thread exit!\n");
}


void start_routine3()
{
		while(1)
		{
		pthread_rwlock_rdlock(&rwlock);
		printf("readlock3 = %d\n",i);
		i++;
		pthread_rwlock_unlock(&rwlock);
		sleep(1);
		}
		pthread_exit("thread exit!\n");
}


void start_routine4()
{
		while(1)
		{
        pthread_rwlock_rdlock(&rwlock);
		printf("readlock4 = %d\n",i);
		i++;
		pthread_rwlock_unlock(&rwlock);
		sleep(1);
		}
		pthread_exit("thread exit!\n");
}


void start_routine5()
{
		while(1)
		{
        pthread_rwlock_rdlock(&rwlock);
		printf("readlock5 = %d\n",i);
		i++;
		pthread_rwlock_unlock(&rwlock);
		sleep(1);
		}
		pthread_exit("thread exit!\n");
}


void start_routine6()
{
		while(1)
		{
        pthread_rwlock_wrlock(&rwlock);
		printf("writelock1 = %d\n",i);
		printf("please input some chars!\n");
		fgets(buffer,512,stdin);
		i++;
		pthread_rwlock_unlock(&rwlock);
		sleep(1);
		}
		pthread_exit("thread exit!\n");
}


void start_routine7()
{
		while(1)
		{
        pthread_rwlock_wrlock(&rwlock);
		printf("writelock2 = %d\n",i);
		printf("please input some chars!\n");
		fgets(buffer,512,stdin);
		i++;
		pthread_rwlock_unlock(&rwlock);
		sleep(1);
		}
		pthread_exit("thread exit!\n");
}


void start_routine8()
{
		while(1)
		{
        pthread_rwlock_wrlock(&rwlock);
		printf("writelock3 = %d\n",i);
		printf("please input some chars!\n");
		fgets(buffer,512,stdin);
		i++;
		pthread_rwlock_unlock(&rwlock);
		sleep(1);
		}
		pthread_exit("thread exit!\n");
}
int main()
{
	void *pthread_result;
	char *message = "hello world";
	pthread_t pth1,pth2,pth3,pth4,pth5,pth6,pth7,pth8;
	int res;

    res = pthread_rwlock_init(&rwlock,NULL);
    if(res != 0)
	{
		printf("fail to pthread_mutex_init!\n");
		exit(1);
	}

	res = pthread_create(&pth1, NULL, (void *)&start_routine1,NULL);
	if(res != 0)
	{
	    printf("fail to create!");
		exit(1);
	}

	res = pthread_create(&pth2, NULL, (void *)&start_routine2,NULL);
	if(res != 0)
	{
	    printf("fail to create!");
		exit(1);
	}

	res = pthread_create(&pth3, NULL, (void *)&start_routine3,NULL);
	if(res != 0)
	{
	    printf("fail to create!");
		exit(1);
	}
	res = pthread_create(&pth4, NULL, (void *)&start_routine4,NULL);
	if(res != 0)
	{
	    printf("fail to create!");
		exit(1);
	}
	res = pthread_create(&pth5, NULL, (void *)&start_routine5,NULL);
	if(res != 0)
	{
	    printf("fail to create!");
		exit(1);
	}
	res = pthread_create(&pth6, NULL, (void *)&start_routine6,NULL);
	if(res != 0)
	{
	    printf("fail to create!");
		exit(1);
	}
	res = pthread_create(&pth7, NULL, (void *)&start_routine7,NULL);
	if(res != 0)
	{
	    printf("fail to create!");
		exit(1);
	}
	res = pthread_create(&pth8, NULL, (void *)&start_routine8,NULL);
	if(res != 0)
	{
	    printf("fail to create!");
		exit(1);
	}


	pthread_join(pth1,NULL);
	pthread_join(pth2,NULL);
	pthread_join(pth3,NULL);
	pthread_join(pth4,NULL);
	pthread_join(pth5,NULL);
	pthread_join(pth6,NULL);
	pthread_join(pth7,NULL);
	pthread_join(pth8,NULL);

    printf("exit:");
    pthread_rwlock_destroy(&rwlock);
	return 0;
}
