#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>
#define BUFSIZE 512
char buffer[BUFSIZE];
sem_t sem;

void start_routine(void)
{
        sem_wait(&sem);     //xin hao liang jian yi
//		sleep(3);
		while(strncmp("end",buffer,3) != 0)		
		{
     		sleep(3);
			int i = 0;
//			printf("the number you press is:%d\n",sizeof(buffer)-1);
//		    sem_wait(&sem);               //zu se
			while(buffer[i]!=0)
			{
				i++;
			}
//            printf("%s\n",buffer);
			printf("the number you press is:%d\n",i-1);
//	        bzero(buffer,BUFSIZE);
		    sem_wait(&sem);
		}
		
		pthread_exit("thread exit!\n");
}
int main()
{
	void *pthread_result;
	pthread_t pth;
	int res;

    res = sem_init(&sem,1,0);             //chu shi hua 
    if(res != 0)
	{
		printf("fail to sem_init!\n");
		exit(1);
	}

	res = pthread_create(&pth, NULL, (void *)&start_routine,NULL);
	if(res != 0)
	{
	    fprintf(stderr,"fail to create!%d",errno);
		exit(1);
	}

//	printf("please input some chars!\n");
	while(strncmp("end",buffer,3) != 0)
	{
	    printf("please input some chars!\n");
		fgets(buffer,512,stdin);
		sem_post(&sem);                          //xin hao liang jia yi
	}


	pthread_join(pth,&pthread_result);
	sleep(abs((int)(3.0*rand()/(RAND_MAX+1.0))));
	printf("exit:%s",(char *)pthread_result);
    sem_destroy(&sem);                           //xiao hui xin hao liang
    return 0;
}
