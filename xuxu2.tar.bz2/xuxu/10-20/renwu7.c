#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

void* newthread(void *message)
{
	int i,res;
	printf("message = %s\n",(char *)message);
	res = pthread_setcancelstate(PTHREAD_CANCEL_ENABLE,NULL);
	if(res != 0)
	{
		printf("fail to cancel!\n");
		exit(1);
	}
	res = pthread_setcanceltype(PTHREAD_CANCEL_DEFERRED,NULL);
	if(res != 0)
	{
		printf("fail to cancel!\n");
		exit(1);
	}

	for(i=0;i<3;i++)
	{
		printf("pthread running!\n");
		sleep(1);
	}
	pthread_exit(NULL);
}


int main(void)
{
	pthread_t pth;
	int res;
	char *message = "hello";

	res = pthread_create(&pth,NULL,newthread,(void *)message);
	if (res != 0)
	{
		printf("fail to create!\n");
		exit(1);
	}
    sleep(2);
	printf("wait to cancel pthread!\n");
	res = pthread_cancel(pth);
	if(res != 0)
	{
		printf("fail to cancel!\n");
		exit(1);
	}
	return 0;
}
