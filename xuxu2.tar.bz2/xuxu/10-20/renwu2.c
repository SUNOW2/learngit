#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int flag = 1;

//void start_routine()
void *start_routine()
{
	while(1)
	{
     	if(flag == 2)
    	{
	    	printf("a = 2\n");
		    flag = 1;
	    	sleep(1);
    	}
	}
	pthread_exit("exit!");
}
int main()
{
	void *pthread_result;
	pthread_t pth;
//	char *message = "hello world!";
    int res;

//	res = pthread_create(&pth,NULL,(void *)&start_routine,NULL);
	res = pthread_create(&pth,NULL,start_routine,NULL);
    if(res != 0)
	{
		printf("fail to creat pthread!\n");
		exit(EXIT_FAILURE);
	}
	else
	{
		printf("succeed to creat pthread!\n");
	}
    while(1)
	{
         if(flag == 1)
	     {
	      	printf("a = 1\n");
	    	flag = 2;
	    	sleep(1);
	     }
	}
	pthread_join(pth, &pthread_result);
	sleep(1);
	printf("pthread exit:%s\n",(char *)pthread_result);
	return 0;
}
