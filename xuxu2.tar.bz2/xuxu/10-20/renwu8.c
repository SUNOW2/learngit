#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>

pthread_attr_t attr;
int flag = 0;

void start_routine1()
{
    printf("the first!\n");
	sleep(rand()%10);
	pthread_exit("the first exit!\n");
}
void start_routine2()
{
    printf("the second!\n");
	sleep(rand()%8);
	pthread_exit("the second exit!\n");
}
void start_routine3()
{
    printf("the thrid!\n");
	sleep(rand()%5);
	pthread_exit("the thrid exit!\n");
}
int main()
{
	pthread_t pth1,pth2,pth3;
	int res;
	void *pthread_result1,*pthread_result2,*pthread_result3;

	res = pthread_create(&pth1, NULL, (void *)&start_routine1,NULL);
	if(res != 0)
	{
	    printf("fail to create!\n");
		exit(1);
	}
	res = pthread_create(&pth2, NULL, (void *)&start_routine2,NULL);
	if(res != 0)
	{
	    printf("fail to create!\n");
		exit(1);
	}
	res = pthread_create(&pth3, NULL, (void *)&start_routine3,NULL);
	if(res != 0)
	{
	    printf("fail to create!\n");
		exit(1);
	}
    pthread_join(pth1,&pthread_result1);
    pthread_join(pth2,&pthread_result2);
    pthread_join(pth3,&pthread_result3);
	printf("exit:%s",(char *)pthread_result1);
	printf("exit:%s",(char *)pthread_result2);
	printf("exit:%s",(char *)pthread_result3);
    return 0;
}
