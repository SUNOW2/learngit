#include <stdio.h>
int main()
{
	while(1)
	{
		printf("hell world");
	}
	sleep(3);
	return 0;
}
