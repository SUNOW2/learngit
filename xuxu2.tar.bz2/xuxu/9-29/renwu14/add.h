
int add(int *p1,int *p2);
