#!/bin/bash
gcc -c -Wall -fpic add.c -o add.o
gcc -shared -o libadd.so add.o
gcc -Wall mian.c -L/home/sunow1/xuxu/9-29/renwu11 -ladd -o main -ldl
./main 3 5
