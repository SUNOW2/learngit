gcc -c -Wall -fpic add.o
gcc -shared -o libadd.so add.o
