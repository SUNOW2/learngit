#!/bin/bash
gcc -I. -c add.c -o add.o 
ar -rcs libadd.a add.o
gcc main1.c -o main1 -L./ -ladd
./main1 7 8
