#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

void main(int argc, const char *argv[])
{
	printf("never printed!");
	_exit(0);
}
