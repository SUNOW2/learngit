
#include <sys/wait.h>
#include <stdio.h>
#include <sys/types.h>


int main(int argc, const char *argv[])
{
	pid_t pid;
	
	printf("before fork! \n");

	/*创建一个子进程*/
	if((pid = fork()) == -1) {
		perror("fork");
		return 1;
	} else if (pid == 0) {
		/*子进程*/
		printf("In child process. getpid = %d getppid = %d \n",
				getpid(), getppid());
		sleep(5);
		printf("child process over!\n");
		return 5;
	} else {
		/*父进程*/
		pid_t w_pid;
		int status;
		printf("parent process. child pid = %d. getpid = %d \n",
				pid, getpid());
		/*父进程等待子进程结束，收尸,  等待过程，父进程阻塞*/
	//	w_pid = waitpid(-1, NULL, 0); // 相当于wait
	//	w_pid = waitpid(pid, NULL, 0); //等待进程号为pid进程结束
		while  ((w_pid = waitpid(pid, NULL, WNOHANG)) == 0) { //非阻塞方法
			sleep(1);
			printf("nonblock\n");
		} 
		/*
		if (WIFEXITED(status)) {
			//WEXITSTATUS 此宏返回退出码
			printf("parent process :child[%d] is exit. exit status is %d \n",
					w_pid, WEXITSTATUS(status));
		}
		*/
		printf("parent process :child[%d] is exit.  \n",
					w_pid );
		sleep(20);
	
	}

	return 0;
}
