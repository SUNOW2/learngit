#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <error.h>
#include <string.h>
#include <fcntl.h>

#define NAME_SIZE 16
#define STUDENT_SIZE 32

struct student
{
	unsigned int id;
	char name[NAME_SIZE];
};
int main(int argc, char *argv[])
{
	int i;
	int fd;
	int id;
	char name[NAME_SIZE];
	struct student stu;
	struct student stu1;
    if(argc != 1)
	{
		perror("too many arguments!");
		exit(EXIT_FAILURE);
	}
	fd = open("./xuesheng",O_CREAT | O_RDWR, 0666);
//	lseek(fd, 0, SEEK_SET);
	if(fd == -1)
	{
		printf("fail to open the file!\n");
		exit(EXIT_FAILURE);
	}
	printf("please input student information!\n");
    for(i=0; i<STUDENT_SIZE; i++)
	{
		printf("id:\n");
		scanf("%d",&id);
		if(id < 0)
		{
			printf("false id\n");
			break;
		}
		else
		{
			printf("name:\n");
			scanf("%16s",name);
			stu.id = id;
			bzero(stu.name,NAME_SIZE);
			printf("*******%s\n",name);
			strcpy(stu.name, name);
			printf("*************%s\n",stu.name);
			lseek(fd, id*sizeof(stu), SEEK_SET);
			write(fd, (char *)&stu, sizeof(stu));
			read(fd, (char *)&stu1,sizeof(stu));
//			fflush(NULL);
            printf("%d\n%s\n",stu1.id,stu1.name);
//			system("cat xuesheng");
		}
	}
	printf("\n");
    close(fd);
	return 0;
}
