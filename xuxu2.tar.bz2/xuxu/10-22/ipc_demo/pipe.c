#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void)
{
	int fd[2];
	int pid;

	if (pipe(fd) < 0) {
		perror("pipe");
		exit(EXIT_FAILURE);
	}
	if ((pid = fork()) < 0) {
		perror("fork");	
		exit(EXIT_FAILURE);
	} else if (pid == 0) {
		/*child write*/
		close(fd[0]);
		write(fd[1], "hello jit", 
				sizeof ("hello jit"));
	
	} else {
		/*parent read*/
		char buf[50];
		close(fd[1]);
		read(fd[0], buf, sizeof(buf));
		printf("buf = %s \n", buf);
	}


	
	return 0;	
}

