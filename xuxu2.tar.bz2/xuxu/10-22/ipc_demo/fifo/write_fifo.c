#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#define WRITE_SIZE 256
/*
 * In block access:
 * if there is no read end, write will block in open
 */

int main(int argc, const char *argv[])
{
	int fd;
	char buf[WRITE_SIZE+1];
	int n;

	if ((mkfifo("./myfifo", 0664) && errno != EEXIST) == -1) {
		perror("mkfifo");
		exit(EXIT_FAILURE);
	}
	
	printf("write: mkfifo success! \n");
	if ((fd = open("./myfifo", O_WRONLY))== -1) {
		perror("open");			
		exit(EXIT_FAILURE);
	}

	printf("write: open success! \n");
	
	while (1) {
		printf(">");
		memset(buf, 0x00, WRITE_SIZE+1);
		fgets(buf, WRITE_SIZE, stdin);
		/*去掉换行符*/
		n = strlen(buf) - 1;
		buf[n] = '\0';
		if (write(fd, buf, n) == -1) {
			perror("write");
			break;
		} else {
			printf("Write: write %d bytes : %s \n", n, buf);
			usleep(100);
			if (strncmp(buf, "quit", 4) == 0) {
				break;
			}
		}
	}
	return 0;
}
