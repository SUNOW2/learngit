#!/bin/bash
ALL_REMOTE="1 2 3"  
for i in $ALL_REMOTE
do  
      echo "I am $i hehe"  
done  
