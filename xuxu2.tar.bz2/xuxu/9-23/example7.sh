#!/bin/bash
a=$(find . -type f -size -30k)
for file in $a
do
  cp $file /tmp
done
