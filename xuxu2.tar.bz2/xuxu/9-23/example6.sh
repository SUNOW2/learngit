#!/bin/bash
arr=(1 5 3 7 9)
echo "Before sort"
echo ${arr[@]}
for((j=0;j<${#arr[@]};j++))
do
{
		 for((j=0;j<${#arr[@]}-1;j++))
		 do
		 {
		      if [[ ${arr[j]} -gt ${arr[j+1]} ]]
			  then
              tmp=${arr[j]}
			  arr[j]=${arr[j+1]}
			  arr[j+1]=$tmp
			  fi
		 }
		 done
}
done
echo "After sort"
echo ${arr[@]}
