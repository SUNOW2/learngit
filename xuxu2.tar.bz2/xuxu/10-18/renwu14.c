#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{
	int i=0;
	int status;
	pid_t pid1,pid2;
	pid1 = fork();
	if(pid1 < 0)
	{
		printf("fail to fork 1!\n");
		exit(1);
	}
   	else if(pid1 == 0)
	{
		printf("first fork child process:pid = %d\n",getpid());
        
		pid2 = fork();
	    if(pid2 < 0)
		{
			printf("fail to fork 2!\n");
		}
		else if(pid2 == 0)
		{
			printf("second fork child process:pid = %d\n",getpid());
		}
		else
		{
//			sleep(3);
			printf("second fork father process:pid = %d\n",getpid());
		}
		exit(0);
	} 
	else 
	{
		sleep(10);
		printf("first fork parent process:pid = %d\n",getpid());
		if(waitpid(pid1,&status,0) != pid1)
		{
			printf("fail to wait the child process!\n");
			exit(1);
		}
		exit(0);
	}

	return 0;
} 
