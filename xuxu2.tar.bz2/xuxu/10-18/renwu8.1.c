#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	printf("use exit(0):\n");
	printf("hello world!");
	exit(0);
}
