#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>

int main(void)
{
    pid_t pid;
	int a;
	int status;
    int variable;
	variable = 3;
	sleep(3);
	printf("variable = %d\n",variable);
	pid = fork();
	if (pid < 0)
	{
		perror("fail to fork!");
		exit(1);
	}
	else if (pid == 0)
	{
	    printf("child process: pid = %d\n",getpid());
		exit(3);
	}
    else 
	{
		if (wait(&status) != pid)
		{
			printf("fail to wait!\n");
			exit(1);
		}
		if (WIFEXITED(status))
		{
			a = WEXITSTATUS(status);
			printf("a = %d\n",a);
		}
	}
	return 0;
}
