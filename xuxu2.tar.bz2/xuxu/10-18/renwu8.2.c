#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void)
{
	printf("use _exit(0):\n");
	printf("hello world!");
	_exit(0);
}
