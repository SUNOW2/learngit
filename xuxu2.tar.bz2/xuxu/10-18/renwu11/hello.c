#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
extern char **environ;

int main(void)
{
	char **penv = environ;
	while (*penv)
	{
		printf("%s\n",*penv);
		penv++;
	}
    return 0;
}
