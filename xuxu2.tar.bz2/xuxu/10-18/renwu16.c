#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>

int main(int argc, char *argv[])
{
	int status1,status2;
	pid_t pid1,pid2;
	pid1 = fork();
	if (pid1 < 0)
	{
		perror("fail to fork!");
		exit(1);
	}
	else if(pid1 == 0)
	{
	    printf("first fork child process!\n");
		pid2 = fork();
        if(pid2 < 0)
		{
		    printf("fail to fork!\n");
			exit(1);
		}
		else if(pid2 == 0)
		{
			sleep(5);
			printf("second fork child process!\n");
			exit(5);
		}
		else
		{
	     	while(waitpid(pid2,&status2,WNOHANG) != pid2)
	        {
		        	printf("fail to wait the second fork child process!\n");
					sleep(1);
			}
	    	if(WIFEXITED(status2))
     		{
	     		printf("second fork common exit:%d\n",WEXITSTATUS(status2));
	     	}
		}
	    exit(3);
	}
	else
	{
		sleep(3);
		if(wait(&status1) != pid1)
		{
			printf("fail to wait the first fork child process!\n");
			exit(1);
		}
		if(WIFEXITED(status1))
		{
		    printf("first fork common exit:%d\n",WEXITSTATUS(status1));
		}
	}
	return 0;
}
