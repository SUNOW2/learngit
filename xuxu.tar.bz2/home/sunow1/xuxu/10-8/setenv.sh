#!/bin/bash
export HELLO="Hello"
echo $HELLO
