#!/bin/bash
echo "son process!"
echo $$
s=`cat /proc/$$/cmdline`
echo "father process!"
echo $s
echo $PPID
a=`cat /proc/$PPID/cmdline`
echo $a
echo "please confirm! yes or no"
read b
if [[ "$b" == "yes" ]]
then 
  kill $$
else 
  echo "running"
fi
