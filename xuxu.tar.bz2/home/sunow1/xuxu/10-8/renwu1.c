#include <stdio.h>
#include <stdlib.h>
int main(void)
{
	int i=0;
	for(i=0;;i++)
	{
		printf("%4d\n",i);
		system("date");
		sleep(2);
	}
	return 0;
}
