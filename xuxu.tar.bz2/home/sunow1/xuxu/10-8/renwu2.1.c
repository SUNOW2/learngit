#include <stdio.h>
#include <stdlib.h>
int main(void)
{
    int x,y;
    char fx[8],fy[8];
    gets(fx);
	gets(fy);
	x=atoi(fx);
    y=atoi(fy);
	while(x>0&&x<100000&&y>0&&y<100000)
	{
		printf("%4d\n",x+y);
		sleep(2);
        gets(fx);
     	gets(fy);
        x=atoi(fx);
     	y=atoi(fy);
	}
	return 0;
}
