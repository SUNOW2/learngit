#!/bin/bash
echo $USER
echo $PWD
export WELCOME="Welcome,$USER,Your home is $PWD,Today is `date`" 
echo 'WELCOME="Welcome,$USER,Your home is $PWD,Today is `date`"' >> ~/.profile
source ~/.profile
echo $WELCOME
