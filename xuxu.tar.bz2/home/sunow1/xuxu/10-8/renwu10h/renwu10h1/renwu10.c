#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void main()
{
     int fp1,fp2,fp3,i;
     char s[40]="SSSSSSSSSSSSSSSSSSSS";
	 char a[40]={0};
     fp1=open("file_src",O_RDWR|O_CREAT);
	 write(fp1,s,sizeof(s));
	 read(fp1,s,40);
	 printf("file_src:%s\n",s);
     for(i=0;s[i];i++)
	 a[i]=tolower(s[i]);
	 fp2=open("file_bak",O_RDWR|O_CREAT);
	 write(fp2,a,sizeof(a));
	 read(fp2,a,40);
	 printf("file_bak:%s\n",a);
	 fp3=open("file",O_RDWR|O_CREAT);
     strcat(s,a);
	 write(fp3,s,sizeof(s));
	 read(fp3,s,40);
	 printf("file:%s\n",s);												 		 close(fp1);
	 close(fp2);
	 close(fp3);
}
