#include <stdlib.h>
#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>

int main(void)
{
	int fp1,fp2,fp3,i;
	char buf1[50] = "SSSSSSSSSSSSSSSSSSSS";
	char buf2[21];
	fp1 = open ("file_src",O_RDWR|O_CREAT,0777);
    write (fp1,buf1,sizeof(buf1)); 
	close(fp1);

    if((fp1 = open ("file_src",O_RDONLY,0777))==-1)
	{
		printf("open error!\n");
		return 0;
	}
	read(fp1,buf2,sizeof(buf2));
	close(fp1);

	if((fp2 = open ("file",O_RDWR|O_CREAT,0777))==-1)
	{
		printf("open error!\n");
		return 0;
	}
	write(fp2,buf2,sizeof(buf2));
	close(fp2);
   
    if((fp3 = open ("file_bak",O_RDWR|O_CREAT,0777))==-1)
	{
		printf("open error!\n");
		return 0;
	}
	for(i=0;i<20;i++)
		buf2[i]=buf2[i]+32;
	write(fp3,buf2,sizeof(buf2));
	close(fp3);

    if((fp2 = open ("file",O_RDWR|O_APPEND,0777))==-1)
	{
		printf("open error!\n");
		return 0;
	}
	write(fp2,buf2,sizeof(buf2));
	close(fp2);
	return 0;
}
