#!/bin/bash
echo "txt"
printf "%-5s %-5s %-5s %-5s %-5s %-5s\n" no name gender age class score
printf "%-4d %-8s %-5s %-4d %-3s %-4d\n" 1 wang f 20 linux 90
printf "%-4d %-8s %-5s %-4d %-3s %-4d\n" 1 zhang m 21 linux 98
printf "%-4d %-8s %-5s %-4d %-3s %-4d\n" 1 zhao f 23 linux 45
printf "%-4d %-8s %-5s %-4d %-3s %-4d\n" 1 chen f 23 linux 87
printf "%-4d %-8s %-5s %-4d %-3s %-4d\n" 1 zhu m 22 linux 56
