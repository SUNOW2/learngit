#i!/bin/bash

printf "%-5s %-10s %-4s\n" No Name Mark
printf "%-5s %-10s %-4.2f\n" 01 Tom 90.3456
printf "%-5s %-10s %-4.2f\n" 02 Jack 89.2345 
printf "%-5s %-10s %-4.2f\n" 03 Jeff 98.4323
