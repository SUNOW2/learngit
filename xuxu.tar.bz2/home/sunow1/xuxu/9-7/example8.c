#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
int main(void)
{
		 pid_t pid1,pid2;
		 pid1=fork();
		 if(pid1<0)
		 {
				 perror("can't creat!");
		 }
		 else if(pid1==0)
				 printf("b,pid=%d,ppid=%d\n",getpid(),getppid());
		 else if(pid1>0)
		 {
				 sleep(3);
				 printf("a,pid=%d,ppid=%d\n",getpid(),getppid());
				 pid2=fork();
                 if(pid2<0)
				 {
						  perror("can't creat!");
				 }
				 else if(pid2==0)
						 printf("c,pid=%d,ppid=%d\n",getpid(),getppid());
				 else 
						 sleep(3);
		 }
		 return 0;
}
