#!/bin/bash
read -p "please input a file:   " file
if [ -b $file -o -c $file ]
then
  echo "Yes"
  cp $file dev/
else
  echo "No block or char"
fi
