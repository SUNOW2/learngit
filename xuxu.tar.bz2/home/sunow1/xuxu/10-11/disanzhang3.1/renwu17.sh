#!/bin/bash
echo "please input a word!"
read word
echo "please input the filename you want to find!"
read filename
grep -p $word $filename
if [ $? -eq 0 ]
then
  echo "exit!"
else
  echo "no exit!"
fi
