#!/bin/bash
find . -size -10k | tee read.txt | wc -l
cat read.txt
