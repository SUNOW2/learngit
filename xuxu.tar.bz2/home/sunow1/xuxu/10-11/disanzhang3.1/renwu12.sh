#!/bin/bash
echo "please input a fileage!"
read fileage
while [ 1 ]
do
if test -d ./$fileage
then
  echo "exit!"
  break
else
  echo "no exit!"
  mkdir $fileage
  break
fi
done
