#/bin/bash
echo "please input a username!"
read username
a=$(whoami)
if [ $username == $a ]
then
  echo "running"
else
  echo "no running"
fi
