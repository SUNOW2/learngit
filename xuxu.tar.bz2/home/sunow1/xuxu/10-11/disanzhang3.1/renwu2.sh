#!/bin/bash
echo "please input the username and passwd!"
read username passwd
#read passwd
if [ $username == sunow -a $passwd == 123 ]
then 
   echo "welcome!$USER"
else 
   echo "fault password!"
fi
