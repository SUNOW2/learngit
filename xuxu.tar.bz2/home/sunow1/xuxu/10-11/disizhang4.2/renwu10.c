#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
int main()
{
	char buf1[20]="SSSSSSSSSSSSSSSSSSSS";
	char buf2[20];
    int i,fp1,fp2,fp3;

	fp1=open("file_src",O_RDWR|O_CREAT,sizeof(buf1));
	write(fp1,buf1,sizeof(buf1));

	lseek(fp1,0,SEEK_SET);
	read(fp1,buf2,sizeof(buf1));
	fp2=open("file_bak",O_RDWR|O_CREAT,0777);
	write(fp2,buf2,sizeof(buf2));

	fp3=open("file",O_RDWR|O_CREAT,0777);
    for(i=0;i<sizeof(buf2);i++)
	{
		buf2[i]=tolower(buf2[i]);
	}
	write(fp3,buf2,sizeof(buf2));
	close(fp1);
	close(fp2);
	close(fp3);
}
