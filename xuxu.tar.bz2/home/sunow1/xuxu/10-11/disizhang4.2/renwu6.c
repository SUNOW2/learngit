#include <stdio.h>
#include <stdlib.h>
int main(void)
{
	char *p;
	if((p=getenv("WELCOME"))!=0)
	{
	    printf("WELCOME=%s\n",p);
	}
	setenv("WELCOME","hello world",1);
	printf("WELCOME=%s\n",getenv("WELCOME"));
	return 0;
}
