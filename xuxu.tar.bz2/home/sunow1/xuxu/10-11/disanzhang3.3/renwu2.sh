#!/bin/bash
for file in `find . -name "*.txt"`
do
  mv $file ${file/%txt/h}
done
