#include <stdio.h>
#include <stdlib.h>
#include <mcheck.h>
#define SIZE 100
void main(void)
{
	mtrace();
	char *p = NULL;
	p = (char *)malloc(sizeof(char)*100);
    char s[SIZE] = "hello world";
	p = s;
	printf("%s\n",p);
	free(p);
}
