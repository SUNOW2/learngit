#include "my_info.h"
int main(void)
{
	printf("hello world!\n");
	my_info();
	return 0;
}
