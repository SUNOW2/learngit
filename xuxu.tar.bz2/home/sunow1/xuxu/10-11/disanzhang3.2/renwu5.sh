#1/bin/bash
IFS=$'\n'
echo "please input the file!"
read filename
for line in `cat $filename`
do 
   echo $line | tr 'a-z' 'A-Z'
   echo $line | sed 's/[a-z]/\u&/g'
done
