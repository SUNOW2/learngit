#!/bin/bash
tar -zxvf ~/xuxu/10-11/disanzhang3.2/renwu7/backup/log_back.tar.bz2 -C /tmp
rm  ~/xuxu/10-11/disanzhang3.2/renwu7/backup/log_back.tar.bz2 
