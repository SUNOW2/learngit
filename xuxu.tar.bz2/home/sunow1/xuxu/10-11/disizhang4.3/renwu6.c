#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
void fun(struct stat sta);
int main()
{
	struct stat fp1,fp2,fp3;
	chmod ("test01",0777);
	chmod ("test02",0764);
	chmod ("test03",0641);
	stat ("test01",&fp1);
	printf("the mode of test01:\n");
	fun(fp1);
	stat ("test02",&fp2);
	printf("the mode of test02:\n");
	fun(fp2);
	stat ("test03",&fp3);
	printf("the mode of test03:\n");
	fun(fp3);
}
void fun(struct stat sta)
{
	if((sta.st_mode&S_IRUSR)==S_IRUSR)
	{
		printf("r");
	}
	else
	{
		printf("-");
	}
	if((sta.st_mode&S_IWUSR)==S_IWUSR)
	{
		printf("w");
	}
	else
	{
		printf("-");
	}
	if((sta.st_mode&S_IXUSR)==S_IXUSR)
	{
		printf("x");
	}
	else
	{
		printf("-");
	}
	if((sta.st_mode&S_IRGRP)==S_IRGRP)
	{
		printf("r");
	}
	else
	{
		printf("-");
	}
	if((sta.st_mode&S_IWGRP)==S_IWGRP)
	{
		printf("w");
	}
	else
	{
		printf("-");
	}
	if((sta.st_mode&S_IXGRP)==S_IXGRP)
	{
		printf("x");
	}
	else
	{
		printf("-");
	}
	if((sta.st_mode&S_IROTH)==S_IROTH)
	{
		printf("r");
	}
	else
	{
		printf("-");
	}
	if((sta.st_mode&S_IWOTH)==S_IWOTH)
	{
		printf("w");
	}
	else
	{
		printf("-");
	}
	if((sta.st_mode&S_IXOTH)==S_IXOTH)
	{
		printf("x");
	}
	else
	{
		printf("-");
	}
	printf("\n");
}
