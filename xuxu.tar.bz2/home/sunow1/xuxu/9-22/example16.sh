
#!/bin/bash
counterl=0
counter=0
echo $PATH > example2000.sh
sed -i 's/:/ /g' example2000.sh
#echo $PATH | sed 's/:/ /g' > example1000.sh
for mulu in `cat example1000.sh`
do
   counterl=$((++counterl))
   for file in `ls $mulu`
   do
         counter=$((++counter))
   done
done    
echo $counterl
echo $counter
