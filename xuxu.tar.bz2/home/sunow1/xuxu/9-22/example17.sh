#!/bin/bash
ls -Rl | sort -rnk5 | head -10 | awk '{print $9}'
