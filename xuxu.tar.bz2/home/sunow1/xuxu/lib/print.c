#include <stdio.h>
//#include <print.h>
void print()
{
	printf("This is from print.c");
}
