#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <string.h>
sem_t sem;
char buffer[512];

void *start_routine()
{
	sem_wait(&sem);
	while(strncmp("end",buffer,3) != 0)
	{
		printf("number = %ld\n",strlen(buffer)-1);
		sem_wait(&sem);
	}
	pthread_exit("pthread_exit!");
}
int main()
{
     pthread_t pth;
	 int res;
	 void * pthread_result;

	 res = sem_init(&sem,0,0);
	 if(res != 0)
	 {
		printf("fail to init!\n");
		exit(1);
	 }

	 res = pthread_create(&pth,NULL,start_routine,NULL);
     if(res != 0)
	 {
		printf("fail to create!\n");
		exit(1);
	 }

	 printf("please input some chars!\n");
	 while(strncmp("end",buffer,3) != 0)
	 {
		 fgets(buffer,512,stdin);
	     sem_post(&sem); 
     }
	 sleep(1);
	 pthread_join(pth,&pthread_result);
	 printf("exit:%s\n",(char *)pthread_result);
	 sem_destroy(&sem);
	 return 0;
}
