#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void)
{
	pid_t fpid;
	int counter=0;
	fpid = fork();
	if (fpid < 0)
	{
		fprintf(stderr,"error!");
	}
	else if (fpid == 0)
	{
		printf("son process!pid=%d\n",getpid());
		counter++;
		printf("counter=%d\n",counter);
//		system("ps -aux | grep fork1 | awk '{print $8}");
	}
	else
	{
		sleep(50);
		printf("father process!pid=%d\n",getpid());
		counter++;
		printf("counter=%d\n",counter);
	}
	return 0;
}
