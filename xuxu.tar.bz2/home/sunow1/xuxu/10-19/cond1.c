#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>

int j;
pthread_mutex_t mutex;
pthread_cond_t cond;

void start_routine1(void)
{
		while(1)
		{
	     	pthread_mutex_lock(&mutex);
			int i;
//			int j=0;
//			printf("jjj = %d\n",j);
			for(i=0; i<3-j; i++)
			{
				j++;
				printf("j = %d\n",j);
				sleep(1);
			}
			if(j >= 3)
			{
				pthread_cond_signal(&cond);
				printf("ji huo!\n");
			}
	     	pthread_mutex_unlock(&mutex);
			sleep(1);
		}
		pthread_exit("thread exit1!\n");
}


void start_routine2(void)
{
		while(1)
		{
	        pthread_mutex_lock(&mutex);
//			int j=0;
			while(j < 3)
			{
				pthread_cond_wait(&cond,&mutex);
				printf("xiao fei!\n");
				int j=3;
			}
			while(j > 0)
			{
				j--;
				printf("j = %d\n",j);
				sleep(1);
			}
	     	pthread_mutex_unlock(&mutex);
		}
		pthread_exit("thread exit2!\n");
}

int main(void)
{
	void *pthread_result;
	pthread_t pth1,pth2;
	int res;

	res = pthread_mutex_init(&mutex,NULL);
    if(res != 0)
	{
		printf("fail to pthread_mutex_init!\n");
		exit(1);
	}
	res = pthread_cond_init(&cond,NULL);
    if(res != 0)
	{
		printf("fail to pthread_mutex_init!\n");
		exit(1);
	}
	res = pthread_create(&pth1, NULL, (void *)&start_routine1,0);
	if(res != 0)
	{
	    printf("fail to create!");
		exit(1);
	}
	res = pthread_create(&pth2, NULL, (void *)&start_routine2,0);
	if(res != 0)
	{
	    printf("fail to create!");
		exit(1);
	}

	pthread_join(pth1,&pthread_result);
	pthread_join(pth2,&pthread_result);
	sleep(abs((int)(3.0*rand()/(RAND_MAX+1.0))));
    printf("exit:%s",(char *)pthread_result);
	return 0;
}
