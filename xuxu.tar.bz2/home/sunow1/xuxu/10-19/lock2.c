#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <pthread.h>
#include <string.h>

pthread_mutex_t mutex;

void start_routine1(void *message)
{
	    pthread_mutex_lock(&mutex);
		while(strncmp("exit",buffer,4) != 0)
		{
			printf("the number you press:%d\n",5);
	     	pthread_mutex_unlock(&mutex);
		}

		pthread_exit("thread exit1!\n");
}
void start_routine2(void *message)
{
	    pthread_mutex_lock(&mutex);
		while(strncmp("exit",buffer,4) != 0)
		{
			printf("the number you press:%d\n",6);
	     	pthread_mutex_unlock(&mutex);
		}

		pthread_exit("thread exit2!\n");
}
int main()
{
	void *pthread_result;
	char *message = "hello world";
	pthread_t pth1,pth2;
	int res;

	res = pthread_mutex_init(&mutex,NULL);
    if(res != 0)
	{
		printf("fail to pthread_mutex_init!\n");
		exit(1);
	}
	res = pthread_create(&pth1, NULL, (void *)&start_routine1,(void *)message);
	if(res != 0)
	{
	    printf("fail to create!");
		exit(1);
	}
	res = pthread_create(&pth2, NULL, (void *)&start_routine2,(void *)message);
	if(res != 0)
	{
	    printf("fail to create!");
		exit(1);
	}

	pthread_join(pth1,&pthread_result);
	pthread_join(pth2,&pthread_result);
	sleep(abs((int)(3.0*rand()/(RAND_MAX+1.0))));
    printf("exit:%s",(char *)pthread_result);
    pthread_mutex_destroy(&mutex);
	return 0;
}
