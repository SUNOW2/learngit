#include <stdio.h>
#include <stdlib.h>

int main()
{
	FILE *fp;
	fp = popen("wget www.baidu.com","r");
	if(fp == NULL)
	{
		printf("perror failed!\n");
		return -1;
	}
	char buf[256];
	while(fgets(buf,255,fp) != NULL)
	{
		printf("%s\n",buf);
	}
	if(pclose(fp) == -1)
	{
		printf("pclose error!\n");
		return -2;
	}
	return 0;
}
