#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <errno.h>

void my_func(int signum)
{
	printf("If you want to quit,please input SIGQUIT!\n");
}
int main()
{
	sigset_t set,pendset;
	struct sigaction action1,action2;
	if(sigemptyset(&set) < 0)           //1. empty
	{
		perror("sigemptyset error!");
		exit(1);
	}
	if(sigaddset(&set,SIGINT) < 0)
	{
		perror("sigaddset error!\n");  //2. add signal
		exit(1);
	}
	if(sigaddset(&set,SIGQUIT) < 0)
	{
		perror("sigaddset error!\n");  //2. add signal
		exit(1);
	}
	if(sigismember(&set,SIGINT))       //3. search the signal and the way to deal
	{
		sigemptyset(&action1.sa_mask);
		action1.sa_handler = my_func;
        action1.sa_flags = 0;
		sigaction(SIGINT,&action1,0);
	}
	if(sigismember(&set,SIGQUIT))
	{
		sigemptyset(&action2.sa_mask);
		action2.sa_handler = SIG_DFL;
		action2.sa_flags = 0;
		sigaction(SIGQUIT,&action2,0);
	}
	if(sigprocmask(SIG_BLOCK,&set,NULL) < 0)
	{
		perror("sigprocmask!");
		exit(1);
	}
	else
	{
		printf("Signal set was blocked,Press any key!\n");
//		getchar();
	}
	sleep(3);
	if(sigprocmask(SIG_UNBLOCK,&set,NULL) < 0)
	{
		perror("sigprocmask!\n");
		exit(1);
	}
	else
	{
		printf("Signal set was unblocked state!\n");
	}
	while(1);
	exit(0);
}
