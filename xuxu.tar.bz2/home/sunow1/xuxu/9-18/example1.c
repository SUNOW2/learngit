#!/bin/bash
read note 
kill $note
