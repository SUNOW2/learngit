#include <stdio.h>
int main(void)
{
		 printf("hello word!");
		 return 0;
}
