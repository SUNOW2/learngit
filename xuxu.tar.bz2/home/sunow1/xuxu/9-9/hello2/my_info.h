#include <stdio.h>
int main2(void)
{
		 printf("stdio.h\n");
		 return 0;
}
