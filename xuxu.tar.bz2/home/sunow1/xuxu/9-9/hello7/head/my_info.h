#include <stdio.h>
void main2(void)
{
		 printf("stdio.h\n");
}
