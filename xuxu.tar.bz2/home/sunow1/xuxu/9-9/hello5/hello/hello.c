#include <stdio.h>
// void main1(void);
void main(void)
{
		 printf("hello world!\n");
		 main1();
}
