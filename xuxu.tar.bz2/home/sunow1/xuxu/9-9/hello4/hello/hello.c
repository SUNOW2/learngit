#include <stdio.h>
//int main1()
int main()
{
		 printf("hello world!\n");
//		 main1();
		 return 0;
}
