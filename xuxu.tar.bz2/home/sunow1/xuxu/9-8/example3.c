#include <stdio.h>
#include <stdlib.h>
#define max 5
void function(char *a);
int main()
{
		 char b[100];
		 function(b);
	     printf("%s\n",b);
		 return 0;
}
void function(char *a)
{
		char s[max];
		gets(s);
	  	strcpy(a,s);
}
