#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <error.h>
int main()
{
		// int a[10]={0,1,2,3,4,5,6,7,8,9};
		int *a;
		int b=2;
		a=&b;
		 int fd,fol,i;
		 fd = open("sort1.txt",O_WRONLY | O_CREAT,S_IRUSR | S_IWUSR);
		 printf("%4d\n",fd);
		 if(fd==-1)
		 {
				  perror("fail to open!\n");
				  exit(1);
		 }
		// for(i=0;i<10;i++)
		// {
                  fol = write(fd,a,2);
		          printf("%4d\n",fol);
		// }
		 close(fd);
		 return 0;
}
