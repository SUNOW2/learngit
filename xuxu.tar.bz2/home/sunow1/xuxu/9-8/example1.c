#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
int main()
{
		 int fol;
		 fol = open("file",O_CREAT,S_IRWXU | S_IRGRP | S_IXGRP);
		 printf("fol=%d\n",fol);
		 return 0;
}
