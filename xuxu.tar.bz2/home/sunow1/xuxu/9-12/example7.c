#include <stdio.h>
#include <stdlib.h>
#include <mcheck.h>
void main()
{
		 mtrace();
		 char *p=(char *)malloc(10);
		// p="hello";
		// printf("%s",p);
}
