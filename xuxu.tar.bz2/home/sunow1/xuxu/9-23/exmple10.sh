#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <stddef.h>
#include <unistd.h>
void print_message(char *ptr);
int main(void)
{
	 pthread_t thread1,thread2;
	 char *mag1="This is the first thread!\n";
	 char *mag2="This is eht second thread!\n";
	 pthread_create(&thread1,NULL,(void *)(&print_message),(void *)mag1);	     pthread_create(&thread2,NULL,(void *)(&print_message),(void *)mag2);
	 sleep(1);
	 return 0;
}		
void print_message(char *ptr)
{
	 int retval;
	 printf("Thread ID: %lx\n",pthread_self(1));
	 printf("%s",ptr);
	 pthread_exit(&retval);
}
