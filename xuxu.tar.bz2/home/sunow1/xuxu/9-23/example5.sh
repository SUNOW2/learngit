echo `pwd`
