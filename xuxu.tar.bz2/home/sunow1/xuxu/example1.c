#include <stdio.h>
#include "print.h"

int main(int argc, char *argv[])
{
	printf("This is from my example1.c\n");
	print();
	return 0;
}
