#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <errno.h>
#include <netinet/in.h>
#include <string.h>

#define SIZE 128
#define SERV_PORT 2360

int main(int argc, char *argv[])
{
	int sockfd;
	int res;
	int cnt;
	char buf[SIZE];
	struct sockaddr_in serveraddr;
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1)
	{
		printf("fail to socket!\n");
		exit(EXIT_FAILURE);
	}
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port = htons(SERV_PORT);
	serveraddr.sin_addr.s_addr = INADDR_ANY;
	bzero(&(serveraddr.sin_zero),8);
    res = connect(sockfd, (struct sockaddr *)&serveraddr,sizeof(struct sockaddr));
	if(res == -1)
	{
		printf("fail to connect!\n");
		exit(1);
	}
	strcpy(buf, argv[1]);
	cnt = send(sockfd, buf, SIZE, 0);
	if(cnt == -1)
	{
		printf("fail to send!\n");
		exit(1);
	}
	printf("Send: %s\n", buf);
	close(sockfd);
	return 0;
}
