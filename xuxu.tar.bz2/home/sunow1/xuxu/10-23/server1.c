#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>

#define SERV_PORT 2360
#define SIZE 128

int main(int argc, char *argv[])
{
	int sockfd;
	int addrlen;
	int cnt;
	char buf[SIZE] = "\0";
	struct sockaddr_in hostaddr;
	struct sockaddr_in clientaddr;
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if(sockfd == -1)
	{
		printf("socket error!\n");
		exit(EXIT_FAILURE);
	}

	hostaddr.sin_family = AF_INET;
	hostaddr.sin_port = htons(SERV_PORT);
    hostaddr.sin_addr.s_addr = INADDR_ANY;
	bzero(&hostaddr.sin_zero, 8);

	if(bind(sockfd,(struct sockaddr*)&hostaddr, sizeof(struct sockaddr)) == -1)
	{
		printf("bind error!\n");
		exit(EXIT_FAILURE);
	}
	while(1)
	{
		addrlen = sizeof(struct sockaddr);
		cnt=recvfrom(sockfd,buf,SIZE,0,(struct sockaddr*)&clientaddr,&addrlen);
		if(cnt == -1)
		{
			printf("recvfrom error!\n");
			continue;
		}
		printf("Client IP:%s\n",inet_ntoa(clientaddr.sin_addr));
		printf("Receive: %s\n",buf);
//		close(sockfd);
		if(buf != NULL)
		{
			break;
		}
	}
	close(sockfd);
	return 0;
}
