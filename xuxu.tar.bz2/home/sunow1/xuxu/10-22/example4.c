#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <dirent.h>
#include <errno.h>
#include <string.h>

#define SIZE 512
int main(int argc, char *argv[])
{
	char buf[SIZE];
	int a;
	getcwd(buf, sizeof(buf));
	printf("lujing: %s\n",buf);
	a = chdir("/home/sunow1");
	if(a != 0)
	{
		printf("fail to chdir!\n");
		exit(EXIT_FAILURE);
	}
	bzero(buf,512);
//    memset(buf, 0, SIZE);
	printf("*********%s\n",buf);
    getcwd(buf,sizeof(buf));
    printf("lujing: %s\n",buf);
	return 0;
}
