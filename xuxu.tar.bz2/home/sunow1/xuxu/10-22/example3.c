#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <dirent.h>

int main(int argc, char *argv[])
{
	DIR *opdir;
	struct dirent *dirp;
	if(argc != 1)
	{
		printf("too many arguments!\n");
		exit(EXIT_FAILURE);
	}
	opdir = opendir("./");
	if(opdir == NULL)
	{
		printf("fail to open!\n");
		exit(EXIT_FAILURE);
	}
	while((dirp = readdir(opdir)) !=  NULL)
	{
//		if((strcmp(dirp->d_name,".") == 0) || (strcmp(dirp->d_name ,"..") == 0))
//	    continue;
		if(dirp->d_type == DT_DIR)
		{
			printf("%s<directory>\n",dirp->d_name);
		}
		else
		{
			printf("%s\n",dirp->d_name);
		}
	}
	closedir(opdir);
	return 0;
}
