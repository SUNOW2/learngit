#include <stdio.h>
#include <stdlib.h>
#include <signal.h>


int main(int argc, const char *argv[])
{	
	/*忽略*/
	if (signal(SIGINT, SIG_IGN) == SIG_ERR) {
		perror("signal");
		exit(EXIT_FAILURE);
	}
	
	/*恢复到默认处理*/
	if (signal(SIGINT, SIG_DFL) == SIG_ERR) {
		perror("signal");
		exit(EXIT_FAILURE);
	}
	
	while (1);
	return 0;
}
