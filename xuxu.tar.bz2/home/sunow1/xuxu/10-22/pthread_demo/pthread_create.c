#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>

char message[32] = "hello thread\n";

void *pthread_routine(void *arg)
{
	/*pthread_self: 获取线程自身pthread_t*/
	printf("pthread_routine[id: %lu] started! \n", pthread_self());
	printf("arg =%s \n", (char *)arg);
	strcpy(message, "goodbye thread\n");
	return (void *)message;
}

int main(int argc, const char *argv[])
{
	pthread_t id;
	void *retval;

	/*创建一个新线程. id在进程环境中，标示一个线程ID, 由pthread_create产生*/
	if (pthread_create(&id, NULL, pthread_routine, (void *)message)!= 0) {
		perror("pthread_create");
		exit(1);
	} else {
		printf("pthread_routine created id[%lu]! \n", id);
	}
	/*等待线程id执行结束*/	
	if (pthread_join(id, &retval) != 0) {
		perror("pthread_join");
		exit(1);
	} else {
		printf("thread[%lu] have terminate!retval = %s\n", id, (char *)retval);	
	}
	return 0;
}
