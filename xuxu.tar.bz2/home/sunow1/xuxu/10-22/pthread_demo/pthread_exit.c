#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>

char message[32] = "hello thread\n";

/*pthread_routine0执行函数*/
void *pthread_routine0(void *arg)
{
	printf("pthread_routine0 started! \n");
	pthread_exit((void *)message);
}

/*pthread_routine1执行函数*/
/*注意：线程执行函数中不能返回局部变量*/
void *pthread_routine1(void *arg)
{
	static int local_var = 123;
	printf("pthread_routine1 started! \n");
	pthread_exit((void *)&local_var);
}

int main(int argc, const char *argv[])
{
	pthread_t id0, id1;
	void *retval;

	/*创建新线程pthread_routine0*/
	if (pthread_create(&id0, NULL, pthread_routine0, NULL )!= 0) {
		perror("pthread_create");
		exit(1);
	} else {
		printf("pthread_routine0 created ! \n");
	}

	/*创建新线程pthread_routine1*/
	if (pthread_create(&id1, NULL, pthread_routine1, NULL )!= 0) {
		perror("pthread_create");
		exit(1);
	} else {
		printf("pthread_routine1 created ! \n");
	}






	/*等待pthread_routine0 结束*/
	if (pthread_join(id0, &retval) != 0) {
		perror("pthread_join");
		exit(1);
	} else {
		printf("pthread_routine0 have terminated!retval = %s\n", (char *)retval);	
	}
	
	/*等待pthread_routine1 结束*/
	if (pthread_join(id1, &retval) != 0) {
		perror("pthread_join");
		exit(1);
	} else {
		printf("pthread_routine1 have terminated!retval = %d \n", *((int *)retval));	
	}

	return 0;
}
