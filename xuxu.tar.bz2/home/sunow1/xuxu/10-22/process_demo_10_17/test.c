#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main(int argc, const char *argv[])
{
	/*
	system("ls -l");
	*/
	while (1) {
		sleep(1);
		printf("get Image! getenv = %s \n",
				getenv("JIT"));
	}
	return 0;
}
