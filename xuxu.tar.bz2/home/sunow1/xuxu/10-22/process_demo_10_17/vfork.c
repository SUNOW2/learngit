#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <stdlib.h>


int g_a = 123;

int main(int argc, const char *argv[])
{
	pid_t pid;
	int l_a = 456;
	
	printf("before vfork \n");

	/*创建一个子进程vfork 子进程与父进程共享数据区*/
	if((pid = vfork()) == -1) {
		perror("fork");
		return 1;
	} else if (pid == 0) {
		printf("In child process. getpid = %d getppid = %d \n",
				getpid(), getppid());
		printf("In child process. g_a = %d  l_a = %d \n", g_a, l_a);
		g_a++;
		l_a++;
		sleep(8);
		execl("/bin/ls", "-l", NULL);
	} else {
		/*父进程会等待子进程退出后(exit,_exit),或者子进程执行exec函数才执行*/
		printf("parent process. child pid = %d. getpid = %d \n",
				pid, getpid());
		
		printf("In parent process. g_a = %d  l_a = %d \n", g_a, l_a);
		wait(NULL);
	}

	return 0;
}
