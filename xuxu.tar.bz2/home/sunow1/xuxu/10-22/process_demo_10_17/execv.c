
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>


void main(int argc, const char *argv[])
{
	pid_t pid;
	
	//char *arg[] = {"ls", "-l", NULL};
	char *arg[] = {"test", NULL};

	/*fork  a new process*/
	if((pid = fork()) == -1) {
		perror("fork");
		exit(EXIT_FAILURE);

	} else if (pid == 0) {
		/*In child process*/
		printf("In child process. getpid = %d getppid = %d \n",
				getpid(), getppid());
		if (execv("/home/linux/test",arg) == -1) {
			perror("execv");
			exit(EXIT_FAILURE);
		}
		printf("never executed!!! \n");

	} else {
		/*In parent process*/
		printf("parent process. child pid = %d. getpid = %d \n",
				pid, getpid());
	}
	exit(EXIT_SUCCESS);
}
