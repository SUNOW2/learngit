#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>


char buf[32] = "i am a daemon\n";

int main(int argc, const char *argv[])
{
	pid_t pid;
	int fd_size, fd;
	
	if ((pid = fork()) < 0) {
		perror("fork");
		exit(EXIT_FAILURE);
	} else if (pid > 0) {
		/*父进程退出，让子进程被init收养*/
		exit(EXIT_SUCCESS);
	} else {
	/*子进程*/
	
	/*创建一个新会话*/
		setsid();
	/*切换工作目录*/
		chdir("/");
		
	/*关闭已经打开的文件*/
	fd_size = getdtablesize();	
	for (fd=0; fd < fd_size; fd++) 
		close(fd);
	/*清文件掩码*/
	umask(0);
	
	while (1) {
		if ((fd = open("/temp.log", O_CREAT | O_WRONLY | O_APPEND),
					0600) < 0) {
			perror("open");
			exit(1);
		}
		write(fd, buf, strlen(buf));
		close(fd);
		sleep(10);

	}

	}
	return 0;
}
