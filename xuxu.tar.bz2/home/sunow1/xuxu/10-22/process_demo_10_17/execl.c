
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>


void main(int argc, const char *argv[])
{
	pid_t pid;
	
	printf("before fork!  \n");

	/*fork  a new process*/
	if((pid = fork()) == -1) {
		perror("fork");
		exit(EXIT_FAILURE);

	} else if (pid == 0) {
		/*In child process*/
		printf("In child process. getpid = %d getppid = %d \n",
				getpid(), getppid());
		if (execl("/bin/ls", "ls", "-l", NULL) == -1) {
			perror("execl");
			exit(EXIT_FAILURE);
		}
		printf("never executed!!! \n");

	} else {
		/*In parent process*/
		printf("parent process. child pid = %d. getpid = %d \n",
				pid, getpid());
	}
	exit(EXIT_SUCCESS);
}
