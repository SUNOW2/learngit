#!/bin/bash
#example3.c
#to test the method of case
USER=`whoami`
echo "you are $USER" 
case $USER in
      root)echo "You can do all things!"
	  ;;
	  Dave)echo "You can do some things!"
	  ;;
	  *)echo "Sorry,you can nothing!"
	  ;;
esac
