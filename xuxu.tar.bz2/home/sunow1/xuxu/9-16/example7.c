#!/bin/bash
#example7.c
#to test the method of until

COUNTER=0
until [ 5 -lt $COUNTER ]
do
  echo $COUNTER
  COUNTER=`expr $COUNTER + 1`
done
