#!/bin/bash
find . -name "* *" | while read line 
do
  echo $line | sed 's/ /*/g'
done
