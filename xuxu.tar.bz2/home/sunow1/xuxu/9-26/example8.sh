#!/bin/bash
i=1
wget -b -P ./download1 -i ./filelist.txt
cd download1
for file in `ls`
do
  mv $file doc$i.jpg
  i=$((++i))
done
