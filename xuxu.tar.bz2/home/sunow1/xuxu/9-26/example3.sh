#!bin/bash
#a=(find . -name *.txt)
for filename in `find . -name  f *.txt `
do
  a=${filename//.txt/.h}
  echo $a
done
