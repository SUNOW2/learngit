#!bin/bash
cat 1.txt | awk -F: '{print $0}'
