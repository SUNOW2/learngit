gcc -c -Wall -fpic add.c
gcc -shared -o libadd.so add.o
gcc -L. -Wall -o main1 main1.c -ladd
export LD_LIBRARY_PATH=/home/sunow1/xuxu/9-29/renwu11:$LD_LIBRARY_PATH
#unset LD_LIBRARY_PATH
#gcc -L/home/sunow1/xuxu/9-29/renwu11 -Wl,-rpath=/home/sunow1/xuxu/9-29/renwu11 -Wall -o main2 main1.c -ladd
#cp /home/sunow1/xuxu/9-29/renwu11/libadd.so  /usr/lib
#chmod 0755 /usr/lib/libadd.so
#ldconfig
#gcc -Wall -o main3 main1.c -L/home/sunow1/xuxu/9-29/renwu11 -ladd
./main2 3 5
