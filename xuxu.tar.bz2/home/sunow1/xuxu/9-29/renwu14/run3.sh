a=$(objdump -x main | grep NEEDED | awk '{print $2}')
for i in $a
do
  ldconfig -p | grep "$i"
if [ $? -eq 0 ]
then
     echo "$a exit"
else
     echo "$a on exist"
fi
done
