#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
main()
{
		 
		int i,fd1,fd2,fd3,temp1,temp2;
		char s1[20]="SSSSSSSSSSSSSSSSSSSS",s2[20],s3[20];	

		fd1=open("file_src",O_RDWR|O_CREAT,0777);
		fd2=open("file_bak",O_RDWR|O_CREAT,0777);
		fd3=open("file",O_RDWR|O_CREAT,0777);
        printf("%s\n",s1);
		write(fd1,s1,sizeof(s1));
		printf("file_src:\n");
		system("cat file_src");
		printf("\n");

		lseek(fd1,0,SEEK_SET);
		read(fd1,s2,sizeof(s1));
		write(fd2,s2,sizeof(s2));
		printf("file_bak:\n");
		system("cat file_bak");
		printf("\n");

		for(i=0;i<sizeof(s2);i++)
		{
			s2[i]=tolower(s2[i]);
		}
		strcat(s1,s2);
		write(fd3,s1,40);
		printf("file:\n");
		system("cat file");
		printf("\n");

		close(fd1);
		close(fd2);
		close(fd3);
}

