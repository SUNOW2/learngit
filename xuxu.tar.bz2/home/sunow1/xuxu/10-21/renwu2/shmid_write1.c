#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <string.h>

#define SIZE 1024
typedef struct
{
	char no[8];
	char name[8];
	double price;
}BOOK;

int main()
{
	BOOK book[2]= {{"01","book1",10}, {"02","book2",20}};
	int shmid;
	int i;
	key_t key;
	BOOK *shmaddr;
	
	key = ftok("/home/sunow1",123);
	if(key < 0)
	{
		printf("ftok error!\n");
		exit(EXIT_FAILURE);
	}

	shmid = shmget(key,SIZE,IPC_CREAT|0666);
	printf("shmid = %d\n",shmid);
    shmaddr = (BOOK *)shmat(shmid, NULL, 0);
    if (shmaddr == (BOOK *)-1)
	{
		printf("shmat error!\n");
		exit(1);
	}
	memcpy(shmaddr, book, sizeof(BOOK)*2);
	for(i=0;i<2;i++,shmaddr++)
	{
     	printf("no:%s\n",shmaddr->no);
     	printf("name:%s\n",shmaddr->name);
     	printf("price:%2.0lf\n",shmaddr->price);
	}
	shmdt((void *)shmaddr);
	return 0;
}
