#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <fcntl.h>
#define BUFSIZE 256

int main(int argc, char *argv[])
{
	int sta;
	int fd;
	char buf[BUFSIZE];
	if (argc != 2)
	{
		perror("arguments error!");
		exit(1);
	}
	sta = mkfifo(argv[1], 0777);
	if (sta < 0)
	{
		printf("fail to creat the FIFO!\n");
		exit(1);
	}
	fd = open(argv[1], O_RDWR|O_CREAT,0777);
	if (fd == -1)
	{
		perror("fail to open the FIFO!");
		exit(1);
	}
	printf("Server:\n");
	printf("Input the message:\n");
	fgets(buf, sizeof(buf), stdin);
	write(fd, buf, sizeof(buf));
    printf("SEND!\n");
	unlink(argv[1]);
	return 0;
}
