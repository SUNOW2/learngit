#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <string.h>

#define SIZE 512

struct msgbuf
{
	long mtype;
	char mtext[SIZE];
};
int main(int argc, char *argv[])
{
	key_t key;
	int msgid;
	int res;
	struct msgbuf buffer;
	key = ftok("./",123);
	if(key < 0)
	{
		printf("ftok error!\n");
		exit(EXIT_FAILURE);
	}
	msgid = msgget(key, IPC_CREAT | 0666);
	if(msgid == -1)
	{
		printf("msgget error!\n");
		exit(EXIT_FAILURE);
	}
	while(1)
	{
        printf("receive messages:\n");
		memset(&buffer, 0, sizeof(buffer));
		res = msgrcv(msgid,&buffer,SIZE,0,0);
		if(res < 0)
		{
			printf("msgcv error!\n");
			exit(1);
		}
	    printf("%s",buffer.mtext);
		if(strncmp(buffer.mtext,"end",3) == 0)
		{
	    	break;
    	}
	}
    	if(msgctl(msgid,IPC_RMID,0) == -1)
    	{
	    	printf("msgctl error!\n");
	    	exit(EXIT_FAILURE);
    	}
	return 0;
}
