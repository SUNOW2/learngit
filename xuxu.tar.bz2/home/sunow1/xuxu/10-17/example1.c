#include <stdio.h>

int a = 0x12345;

int main()
{
	while(1);
//	printf("hello!\n");
	return 0;
}
