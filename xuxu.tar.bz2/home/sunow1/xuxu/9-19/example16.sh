#!/bin/bash
echo "please input a character"
read ch
case $ch in
       [[:lower:]])echo "xiaoxie"
	   ;;
	   [[:upper:]])echo "daxie"
	   ;;
	   [0-9])echo "shuzi"
	   ;;
	   *)echo "qita"
	   ;;
esac
