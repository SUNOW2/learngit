#!/bin/bash
for file in `ls`
do 
a=$(ls -l $file | awk '{print $5}')
if [[ $a -eq 0 ]]
then
    rm $file
fi
done
