#!/bin/bash
a=1
while [ $# -gt 0 ]
do
  a=$(expr $1 \* $a)
  shift
done
echo $a
