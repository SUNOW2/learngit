#!/bin/bash
echo "please input the username and password!"
read username
read password
if [ $username = sunow -a $password -eq 123 ]
then 
echo "success"
else
echo "fail"
fi
