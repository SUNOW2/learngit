#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main()
{
	int i=0;
	pid_t pid;
	pid = fork();
	if(pid < 0)
	{
		printf("fail to fork!\n");
		exit(1);
	}
   	else if(pid == 0)
	{
		for(i=0; i<9; i++)
		{
			printf("child process:i = %d,pid = %d\n",i,getpid());
			sleep(1);
		}
	}
	else 
	{
		sleep(3);
		printf("parent process:i = %d,pid = %d\n",i,getpid());
	}
	return 0;
} 
