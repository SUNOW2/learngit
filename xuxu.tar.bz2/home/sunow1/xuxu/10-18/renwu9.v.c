#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void)
{
	int status;
	pid_t pid;
	char *arrEnv[] = {"ls","-o","./",NULL};
	pid = vfork();
	if(pid < 0)
	{
		printf("fail to fork\n");
		exit(1);
	}
	else if(pid == 0)
	{
		execv("/bin/ls",arrEnv);
	}
	else
	{
		if (wait(&status) != pid)
		{
		    printf("fail to wait!\n");
			exit(1);
		}
	}
	return 0;
}
