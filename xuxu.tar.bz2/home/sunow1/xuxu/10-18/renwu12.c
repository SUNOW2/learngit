#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void)
{
	pid_t pid;
	char a;
    pid = fork();
	if(pid < 0)
	{
	    printf("fail to fork!\n");
		exit(1);
	}
	else if(pid == 0)
	{
		printf("child process:pid = %d\n",getpid());

//	    system("ps -aux | grep renwu12 | awk '{print $8}' | sort -rk8 | head -1 | awk '{print $8}' ");
//		printf("%c\n",a);
	}
	else
	{
		sleep(30);
		printf("father process:pid = %d\n",getpid());
        system("ps -aux | grep renwu12");
	}
	return 0;
}
