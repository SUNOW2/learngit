#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int global_a = 1;
int main()
{
	int global_b = 1;
	pid_t pid;
	pid = fork();
    if (pid < 0)
	{
		printf("fail to fork!\n");
		exit(1);
	}
	else if(pid == 0)
	{
		printf("child process:pid = %d,ppid = %d\n",getpid(),getppid());
		printf("global_a = %d,global_b = %d\n",++global_a,++global_b);
	}
	else
	{
		sleep(3);
		printf("father process:pid = %d,ppid = %d\n",getpid(),getppid());
		printf("global_a = %d,global_b = %d\n",++global_a,++global_b);
	}
	return 0;
}
