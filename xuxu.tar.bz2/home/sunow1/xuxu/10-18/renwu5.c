#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <linux/sched.h>
#include <signal.h>
#define STACK 10000

int do_something();
void *stack;
int main()
{
	void *stack;
	int variable;
	variable = 9;
	stack = malloc(STACK);
	if (stack == NULL)
	{
		printf("fail to creat the stack");
		exit(1);
	}
	printf("variable = %d\n",variable);
	clone(&do_something,(int *)stack+STACK,CLONE_VM|CLONE_FILES,&variable);
	sleep(3);
	return 0;
}

int do_something(int *variable)
{
	*variable = 42;
	printf("variable = %d\n",*variable);
	free(stack);
	exit(1);
}
