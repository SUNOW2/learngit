#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(void)
{
	int status;
	char *arrEnv[]={"env = 1","env = 2",(char *)0};
	char *arrAgv[]={"main","AA","BB",(char *)0};
	pid_t pid;
	pid = vfork();
	if(pid < 0)
	{
		printf("fail to fork\n");
		exit(1);
	}
	else if(pid == 0)
	{
		execve("./main",arrAgv,arrEnv);
		exit(0);
	}
	else
	{
		if (wait(&status) != pid)
		{
		    printf("fail to wait!\n");
			exit(1);
		}
	}
	return 0;
}
