#include <stdio.h>
#include <errno.h>

int main()
{
	int rc;

	rc = chmod("/etc/passwd",0444);
	if(rc==-1)
	    printf("chmod fail,errno=%d\n",errno);
	else
		printf("chmod success!\n");
	return 0;
}
