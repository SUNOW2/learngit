#include "my_info.h"
void main1(void)
{
		 printf("141610\n");
}
