#include "my_info.h"
void main(void)
{
		 printf("hello world!\n");
		 main1();
}
