#include <stdio.h>
#include <stdlib.h>

int global_a = 20538;

int main()
{
	int *p;

	p = (int *)malloc(3*sizeof(int));
	printf("address: %p\n",p);
	return 0;
}
