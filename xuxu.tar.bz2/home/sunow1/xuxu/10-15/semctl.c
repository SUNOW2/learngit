#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <errno.h>
#include <unistd.h>

int main()
{
	int semid;
	pid_t pid;
	key_t key;
	int i;
	int res;
	int status;
	struct sembuf lock = {0,-1,SEM_UNDO};
	struct sembuf unlock = {0,1,SEM_UNDO | IPC_NOWAIT};
	key = ftok("./",'a');
	if(key < 0)
	{
		printf("fail to ftok!\n");
		exit(1);
    }
	semid = semget(key, 1, IPC_CREAT | 0666);
    if(semid < 0)
	{
		printf("fail to semget!\n");
		exit(1);
	}

	res = semctl(semid, 0, SETVAL, 1);
	if(res == -1)
	{
		printf("fail to semtcl!\n");
		exit(1);
	}
	pid = fork();
	if (pid < 0)
	{
		printf("fail to fork!\n");
		exit(1);
	}
	else if(pid == 0)
	{
		for(i=0; i<3; i++)
		{
			sleep(abs((int)(3.0*rand()/(RAND_MAX+1.0))));
            res = semop(semid,&lock,1);
			if(res == -1)
			{
				perror("lock error1");
				exit(1);
			}
			printf("Child process access the process!\n");

			sleep(abs((int)(3.0*rand()/(RAND_MAX+1.0))));
			res = semop(semid,&unlock,1);
			if(res == -1)
			{
				printf("unlock error!\n");
				exit(1);
			}
			printf("Complete!\n");
		}
	}
	else
	{
		for(i=0; i<3; i++)
		{
			sleep(abs((int)(3.0*rand()/(RAND_MAX+1.0))));
			res = semop(semid,&lock,1);
			if(res == -1)
			{
				printf("lock error!\n");
				exit(1);
			}
			printf("Parent process access the source!\n");
			sleep(abs((int)(3.0*rand()/(RAND_MAX+1.0))));
			res = semop(semid,&unlock,1);
			if(res == -1)
			{
			    printf("unlock error!\n");
				exit(1);
			}
			printf("Complete!\n");
		}
		if(wait(&status) != pid)
		{
			printf("fail to wait!\n");
			exit(1);
		}
		res = semctl(semid, 0, IPC_RMID, 0);
		if(res == -1)
		{
			perror("semctl error1");
			exit(1);
		}
	}
	return 0;
}
