#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>

int main(void)
{
	pid_t pid;
	int sta, i=1;
    pid = fork();
	if (pid < 0)
	{
		printf("error to creat son process!\n");
		exit(1);
	}
	if (pid == 0)
	{
		sleep(20);
		printf("this is a son process!\n");
	}
	else
	{
		sleep(1);
		printf("this is a father process!\n");
		printf("father process:pid = %d\n",getpid());
		printf("wait the son process!\n");
		if (pid != wait(&sta))
//       if(pid != waitpid(pid,&sta,WNOHANG))
		{
			printf("error to wait the son process!\n");
            exit(1);
		}
		printf("***************************************************\n");
		printf("sta = %d\n",sta);
		if(WIFEXITED(sta))
		{
			i = WIFEXITED(sta);
		}
		printf("son process:pid = %d\n",pid);
		printf("exit status = %d\n",i);
	}
	return 0;
}
