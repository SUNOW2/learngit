#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/ipc.h>
#include <sys/msg.h>

int main()
{
	int qid;
	key_t key;
	key = ftok("./",'a');
	if (key < 0)
	{
		perror("ftok error!");
		exit(1);
	}
	qid = msgget(key, IPC_CREAT | 0666);
	if (qid < 0)
	{
		perror("msgget error!");
		exit(1);
	}
	else
    {
		printf("Done!\n");
	}
	return 0;
}
