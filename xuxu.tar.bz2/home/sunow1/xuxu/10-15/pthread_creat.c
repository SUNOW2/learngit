#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

int main(void)
{
	pthread_t pth;
	int ret;
	ret = pthread_creat(&pth,NULL,(void *)newthread,NULL);
	if (ret != 0)
	{
		printf("fail to creat the pthread!\n");
		exit(1);
	}
}
