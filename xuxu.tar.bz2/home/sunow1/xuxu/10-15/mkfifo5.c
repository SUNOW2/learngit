#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <errno.h>
#define FIFO "FIFO2"
#define SIZEBUF 256

int main(void)
{
	pid_t cpid;
	int fd_r;
	int fd_w;
	int num_r;
	int num_w;
	char buf_r[SIZEBUF];
	char buf_w[SIZEBUF];
	if ((mkfifo(FIFO,0750) < 0) && (errno != EEXIST))
	{
		printf("fail to creat the FIFO!\n");
		exit(1);
	}
	cpid = fork();
	if (cpid == 0)
	{
		sleep(1);
		printf("pid = %d\n,to open the FIFO:\n",getpid());
        fd_r = open (FIFO,O_RDONLY);
		if (fd_r == -1)
		{
			printf("pid = %d\n,fail to open the FIFO\n",getpid());
			return 0;
		}
		printf("pid = %d\n,having open the FIFO\n",getpid());
		while (1)
		{
			num_r = read (fd_r, buf_r, sizeof(buf_r));
			printf("num_r = %d\n",num_r);
			sleep(1);
		}
	}
	else if (cpid > 0)
	{
		printf("pid = %d\n,to open the FIFO:\n",getpid());
        fd_w = open (FIFO,O_RDONLY);
		if (fd_w == -1)
		{
			printf("pid = %d\n,fail to open the FIFO\n",getpid());
			return 0;
		}
		printf("pid = %d\n,having open the FIFO\n",getpid());
		while (1)
		{
			num_w = write(fd_w, buf_w, sizeof(buf_w));
			printf("num_w = %d\n",num_w);
		}
	}
	return 0;
}
