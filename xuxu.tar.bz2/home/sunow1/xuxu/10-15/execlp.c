#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
int main(int argc,char * argv[])
{
	pid_t pid;
	pid = vfork();
	int status,i;
	if( pid < 0 )
	{
		fprintf(stderr,"fail to fork the process!\n");
		_exit(1);
	}
	else if( pid == 0 )
	{
		execlp("ps","ps","-o","ppid,pid,comm",NULL);
	}
	else
	{
		if (waitpid(pid,&status,0) != pid)
		{
			printf("fail to wait the son process!\n");
			_exit(1);
		}
		i = WIFEXITED(status);
		printf("i = %d\n",i);
	}
	return 0;
}
