#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

void sig_handler(int sig, siginfo_t *info, void *t)
{
    printf("Receive signal; %d\n",sig);
	printf("Receive message: %d\n",info->si_int);
	return;
}

int main()
{
	int sta;
	struct sigaction act;
	act.sa_sigaction = sig_handler;
	sigemptyset(&act.sa_mask);
	act.sa_flags = SA_SIGINFO;
	sta = sigaction(SIGUSR1,&act,NULL);

    if (sta < 0)
	{
		printf("sigaction error!\n");
	}
	printf("Receiver:\n");
	printf("pid = %d\n",getpid());
	for(;;);
	return 0;
}
