#include <stdio.h>
#include <sys/wait.h>
#include <unistd.h>
int main()
{
	int ret;
	pid_t pid = fork();
	ret = waitpid(pid,NULL,WNOHANG);
	printf("ret = %d\n",ret);
}
