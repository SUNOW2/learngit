#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <string.h>
#define SIZE 256

int main(int argc, char *argv[])
{
	FILE *fp;
	pid_t cpid;
    int fifod[2];
	int status;
	char buf[SIZE];
	if (pipe(fifod) < 0)
	{
		printf ("pipe error!\n");
		exit(1);
	}
	cpid = fork();
	if ( cpid < 0)
	{
		printf("fail to fork!\n");
		exit(1);
	}
	else if (cpid == 0)
	{
		printf("1.txt:\n");
		system("cat 1.txt");
		fp = fopen (argv[1],"r");
	    if (fp == NULL)
		{
		    perror("fail to open the file!");
			exit(1);
		}
		while (fgets(buf, sizeof(buf), fp) != NULL)
		{
	        close(fifod[0]);
			write(fifod[1], buf, sizeof(buf));
		}
		fclose(fp);
		strcpy(buf,"`");
		close(fifod[0]);
		write(fifod[1], buf, sizeof(buf));
	}
	else 
	{
		fp = fopen (argv[2],"w+");
	    if (fp == NULL)
		{
		    perror("fail to open the file");
			exit(1);
		}
		close(fifod[1]);
		read(fifod[0], buf, sizeof(buf));
		while ('`' != buf[0])
		{
			fputs(buf, fp);
			close(fifod[1]);
	        read(fifod[0], buf, sizeof(buf));
		}
		fclose(fp);
		printf("2.txt:\n");
		system("cat 1.txt");
		if (waitpid(cpid, &status, 0) != cpid) 
		{
			printf("fail to wait the child process!\n");
			exit(1);
		}
		printf("Having Done!\n");
	}
	return 0;
}
