#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
int i;
void child_process()
{
	printf("son process: pid = %d,i = %d\n",getpid(),i);
	i++;
	printf("son process: pid = %d,i = %d\n",getpid(),i);
}
int main(int argc,char *argv[])
{
    pid_t pid;
	int sta;
	pid = fork();
    if ( pid < 0 )
	{
		perror("fail to creat the son process!");
		exit(1);
	}
	else if (pid == 0)
	{
	   child_process();
	}
	else 
	{
		sleep(1);
        printf("father process: pid = %d,i = %d\n",getpid(),i);
		if(waitpid (pid,&sta,0) != pid)
		{
			printf("fail to wait the son!\n");
			exit(1);
		}
	}
	return 0;
}
